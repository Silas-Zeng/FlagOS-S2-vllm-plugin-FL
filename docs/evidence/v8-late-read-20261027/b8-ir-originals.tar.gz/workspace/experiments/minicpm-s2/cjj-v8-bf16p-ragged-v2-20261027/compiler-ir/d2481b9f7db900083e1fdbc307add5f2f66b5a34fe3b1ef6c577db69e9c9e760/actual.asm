	.text
	.globl	gqa_decode_v8_bf16p             ; -- Begin function gqa_decode_v8_bf16p
	.p2align	3
	.type	gqa_decode_v8_bf16p,@function
	.iluvatar_kernel gqa_decode_v8_bf16p
gqa_decode_v8_bf16p:                    ; @gqa_decode_v8_bf16p
.Lfunc_begin0:
	.file	1 "/workspace/experiments/minicpm-s2/code/cjj-v8-bf16p-ragged-v2-20261027/tools/kernels" "biv150_v8_bf16p.py"
	.loc	1 16 0                          ; biv150_v8_bf16p.py:16:0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_return_column 32
	.iluvatar_kernel_code_t
		iluvatar_code_version_major = 1
		iluvatar_code_version_minor = 3
		iluvatar_machine_kind = 1
		iluvatar_machine_version_major = 1
		iluvatar_machine_version_minor = 1
		iluvatar_machine_version_stepping = 0
		kernel_code_entry_byte_offset = 256
		kernel_code_prefetch_byte_size = 0
		granulated_workitem_vgpr_count = 35
		granulated_warp_sgpr_count = 8
		float_mode = 12
		debug_mode = 0
		has_mbar = 0
		user_sgpr_count = 6
		enable_sgpr_workgroup_id_x = 1
		enable_sgpr_workgroup_id_y = 1
		enable_sgpr_workgroup_id_z = 1
		enable_sgpr_workgroup_info = 1
		enable_vgpr_workitem_id = 3
		granulated_slb_size = 0
		enable_exception = 128
		enable_sgpr_private_segment_buffer = 1
		enable_sgpr_globalvariable_ptr = 0
		enable_sgpr_kernarg_segment_ptr = 1
		enable_sgpr_constvariable_ptr = 0
		enable_sgpr_private_segment_size = 0
		enable_sgpr_grid_workgroup_count_x = 0
		enable_sgpr_grid_workgroup_count_y = 0
		enable_sgpr_grid_workgroup_count_z = 0
		private_element_size = 1
		is_ptr64 = 1
		is_dynamic_callstack = 0
		is_debug_enabled = 0
		enable_private_swizzle = 1
		has_called_assert = 0
		has_called_printf = 0
		has_called_malloc = 0
		enable_srf_flat_shared = 0
		enable_srf_flat_scratch = 0
		has_wgmma = 0
		has_dva = 0
		enable_dynamic_smem_size = 0
		workitem_private_segment_byte_size = 0
		workgroup_group_segment_byte_size = 0
		kernarg_segment_byte_size = 152
		workgroup_fbarrier_count = 0
		warp_sgpr_count = 67
		workitem_vgpr_count = 143
		reserved_vgpr_first = 0
		reserved_vgpr_count = 0
		reserved_sgpr_first = 0
		reserved_sgpr_count = 0
		debug_warp_private_segment_offset_sgpr = 0
		debug_private_segment_buffer_sgpr = 0
		kernarg_segment_alignment = 3
		group_segment_alignment = 4
		private_segment_alignment = 4
		warp_size = 6
		call_convention = -1
		runtime_loader_kernel_symbol = 0
	.end_iluvatar_kernel_code_t
; %bb.0:
	; Func LiveIn Regs:
	;  blockIdx.x : s6  blockIdx.y : s7  blockIdx.z : s8
	ml_vrf_init_u32 v0, tcr
	sl_mov_b32 s0, s6
.Ltmp0:
	.loc	1 50 28 prologue_end            ; biv150_v8_bf16p.py:50:28
	sl_lsa_load_b32x16 s[12:27], s[4:5], noreg, #0, ca
	.loc	1 54 37                         ; biv150_v8_bf16p.py:54:37
	sl_mov_b32 s61, 0x0
	sl_mov_b32 s1, s61
	sl_shl_b64 {s[2:3], wcr}, s[0:1], 0x2
	sl_mov_b32 s31, 0xffffffff
	sl_wait smcnt(0)
	sl_add_i64 s[28:29], s[26:27], s[2:3]
	.loc	1 54 22 is_stmt 0               ; biv150_v8_bf16p.py:54:22
	ml_lsa_load_dword v1, s[28:31], noreg, noreg, #0, ca
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s6, v1, 0x0
.Ltmp1:
	.file	2 "/usr/local/lib/python3.12/site-packages/triton/language" "standard.py"
	.loc	2 65 17 is_stmt 1               ; standard.py:65:17 @[ biv150_v8_bf16p.py:55:41 ]
	sl_add_i32 s2, s6, 0xff
	.loc	2 65 30 is_stmt 0               ; standard.py:65:30 @[ biv150_v8_bf16p.py:55:41 ]
	sl_sra_b32 {s3, wcr}, s2, 0x1f
	sl_srl_b32 {s3, wcr}, s3, 0x18
	sl_add_i32 s2, s2, s3
	sl_sra_b32 {s2, wcr}, s2, 0x8
.Ltmp2:
	.loc	1 56 26 is_stmt 1               ; biv150_v8_bf16p.py:56:26
	sl_mull_u32 s9, s2, s8
	.loc	1 56 46 is_stmt 0               ; biv150_v8_bf16p.py:56:46
	sl_mull_u32 s62, s9, 0x10
	.loc	1 57 16 is_stmt 1               ; biv150_v8_bf16p.py:57:16
	sl_cmp_lt_i32 wcr, s62, s6
	sl_cbr_wcrz BB0_57, wcr
; %bb.1:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_lsa_load_b32x16 s[44:59], s[4:5], noreg, #128, ca
	.loc	1 63 29 is_stmt 1               ; biv150_v8_bf16p.py:63:29
	ml_bfe2_b32 v16, tid, 0x25
	ml_add_i32 v93, v16, 0x2
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_lsa_load_b32x16 s[28:43], s[4:5], noreg, #64, ca
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_add_i32 v91, v16, 0x4
	.loc	1 59 31 is_stmt 1               ; biv150_v8_bf16p.py:59:31
	sl_add_i32 s4, s9, s2
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_add_i32 v88, v16, 0x6
	.loc	1 75 28                         ; biv150_v8_bf16p.py:75:28
	sl_mull_u32 s60, s7, 0x800
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_add_i32 v85, v16, 0x8
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	sl_wait smcnt(0)
	sl_mov_b32 s51, 0xfff00004
	.loc	1 59 31                         ; biv150_v8_bf16p.py:59:31
	sl_mull_u32 s4, s4, 0x10
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	sl_mov_b32 s46, 0x400
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[9:10], s45, v16
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	sl_mov_b32 s47, 0x1000504
	.loc	1 59 62                         ; biv150_v8_bf16p.py:59:62
	sl_min_i32 s6, s4, s6
	.loc	1 71 20                         ; biv150_v8_bf16p.py:71:20
	sl_mull_u32 s5, s35, s0
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[78:79], s44, v16
	.loc	1 71 20                         ; biv150_v8_bf16p.py:71:20
	sl_mul_u64_u32 s[2:3], s34, s0
	sl_add_i32 s3, s3, s5
	.loc	1 75 28                         ; biv150_v8_bf16p.py:75:28
	sl_shl_b64 {s[2:3], wcr}, s[2:3], 0x1
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[10:11], s45, v93
	.loc	1 75 28                         ; biv150_v8_bf16p.py:75:28
	sl_add_i64 s[2:3], s[18:19], s[2:3]
	sl_add_i64 s[48:49], s[2:3], s[60:61]
	.loc	1 75 16 is_stmt 0               ; biv150_v8_bf16p.py:75:16
	ml_lsa_blkload_x4 v[1:4], s[48:51], noreg, noreg, #0, ca
	.loc	1 98 37 is_stmt 1               ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[76:77], s44, v93
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	sl_mov_b32 s5, 0x3020706
	.loc	1 77 50                         ; biv150_v8_bf16p.py:77:50
	sl_mull_u32 s18, s33, s0
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	ml_lsa_blkload_x4 v[5:8], s[48:51], noreg, s46, #0, ca
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[11:12], s45, v91
	.loc	1 92 37                         ; biv150_v8_bf16p.py:92:37
	sl_shl_b64 {s[26:27], wcr}, s[38:39], 0x1
	.loc	1 99 14                         ; biv150_v8_bf16p.py:99:14
	sl_mov_b32 s19, s61
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[74:75], s44, v91
	ml_mul_u64_u32 v[12:13], s45, v88
	ml_mul_u64_u32 v[70:71], s44, v88
	ml_mul_u64_u32 v[13:14], s45, v85
	ml_mul_u64_u32 v[66:67], s44, v85
	.loc	1 61 28                         ; biv150_v8_bf16p.py:61:28
	ml_and_b32 v14, tid, 0x30
	ml_and_b32 v15, tid, 0x7
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_and_b32 v17, tid, 0x20
	ml_cmp_eq_u32 tcr, v17, 0x0
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	ml_shl_b32 v14, v14, 0x5
	ml_shl_b32 v15, v15, 0x3
	ml_and_b32 v18, tid, 0x8
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	sl_mov_b64 s[2:3], tcr
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	ml_cmp_eq_u32 tcr, v18, 0x0
	ml_mov_b32 v18, 0x180
	ml_csel_b32 v18, 0, v18, tcr
	ml_anyop3_b32 v18, v18, v14, v15, 0xfffffffe
	sl_wait vmcnt(1)
	ml_byte_permute_b32 v15, v2, v1, s5
	ml_byte_permute_b32 v14, v2, v1, s47
	ml_slb_store_b32x2  v[14:15], v18, noreg, #0, null
	ml_byte_permute_b32 v2, v4, v3, s5
	ml_byte_permute_b32 v1, v4, v3, s47
	ml_xor_b32 v14, v18, 0x80
	ml_slb_store_b32x2  v[1:2], v18, noreg, #64, null
	sl_wait vmcnt(0)
	ml_byte_permute_b32 v2, v6, v5, s5
	ml_byte_permute_b32 v1, v6, v5, s47
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_add_i32 v89, v16, 0xa
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	ml_slb_store_b32x2  v[1:2], v14, noreg, #0, null
	ml_byte_permute_b32 v2, v8, v7, s5
	ml_byte_permute_b32 v1, v8, v7, s47
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[3:4], s45, v89
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	ml_slb_store_b32x2  v[1:2], v14, noreg, #64, null
	.loc	1 77 50                         ; biv150_v8_bf16p.py:77:50
	sl_mul_u64_u32 s[4:5], s32, s0
	sl_add_i32 s5, s5, s18
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[72:73], s44, v89
	.loc	1 77 40                         ; biv150_v8_bf16p.py:77:40
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x2
	sl_add_i64 s[34:35], s[28:29], s[4:5]
	.loc	1 84 35                         ; biv150_v8_bf16p.py:84:35
	sl_sub_i32 s4, s6, s62
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_add_i32 v87, v16, 0xc
	.loc	1 84 45                         ; biv150_v8_bf16p.py:84:45
	sl_sra_b32 {s5, wcr}, s4, 0x1f
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[1:2], s45, v87
	.loc	1 84 45                         ; biv150_v8_bf16p.py:84:45
	sl_srl_b32 {s5, wcr}, s5, 0x1c
	sl_add_i32 s4, s4, s5
	sl_srl_b32 {s4, wcr}, s4, 0x4
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_mul_u64_u32 v[68:69], s44, v87
	.loc	1 84 25                         ; biv150_v8_bf16p.py:84:25
	sl_add_i32 s4, s4, s9
	sl_mull_u32 s9, s4, 0x10
	.loc	1 93 28                         ; biv150_v8_bf16p.py:93:28
	sl_mull_u32 s4, s41, s7
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_add_i32 v83, v16, 0xe
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_add_i32 v98, v79, v9
	ml_add_i32 v97, v77, v10
	ml_mul_u64_u32 v[4:5], s45, v83
	.loc	1 93 28                         ; biv150_v8_bf16p.py:93:28
	sl_mul_u64_u32 s[32:33], s40, s7
	sl_add_i32 s33, s33, s4
	.loc	1 99 28                         ; biv150_v8_bf16p.py:99:28
	sl_mull_u32 s18, s7, 0x80
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_add_i32 v96, v75, v11
	ml_add_i32 v95, v71, v12
	ml_mul_u64_u32 v[64:65], s44, v83
	ml_add_i32 v94, v67, v13
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_and_b32 v2, tid, 0xf
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_add_i32 v92, v73, v3
	ml_mov_b32 v34, 0x0
	ml_add_i32 v90, v69, v1
	.loc	1 73 19                         ; biv150_v8_bf16p.py:73:19
	ml_shl_b32 v1, v0, 0x2
	ml_and_b32 v84, v1, 0x7c
	.loc	1 98 37                         ; biv150_v8_bf16p.py:98:37
	ml_add_i32 v86, v65, v4
	.loc	1 106 28                        ; biv150_v8_bf16p.py:106:28
	ml_shl_b32 v82, v2, 0x1
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	sl_wait lmcnt(0)
	sl_barrier 
	ml_shl_b32 v1, tid, 0x2
	ml_xor_b32 v69, v1, 0x80
	ml_slb_blkload_x1  v56, noreg, noreg, #0, null
	.loc	1 86 21                         ; biv150_v8_bf16p.py:86:21
	sl_cmp_lt_i32 wcr, s62, s9
	.loc	1 86 4 is_stmt 0                ; biv150_v8_bf16p.py:86:4
	ml_mov_b32 v80, 0xff800000
	ml_shl_b32 v99, v0, 0x6
	.loc	1 75 16 is_stmt 1               ; biv150_v8_bf16p.py:75:16
	ml_slb_blkload_x1  v54, noreg, noreg, #512, null
	ml_and_b32 v3, tid, 0xc
	ml_xor_b32 v35, tid, 0x8
	ml_xor_b32 v36, tid, 0x4
	ml_slb_blkload_x1  v50, noreg, s46, #0, null
	ml_xor_b32 v37, tid, 0x2
	ml_xor_b32 v38, tid, 0x1
	ml_shl_b32 v73, v0, 0x7
	ml_slb_blkload_x1  v48, noreg, s46, #512, null
	ml_shl_b32 v77, v0, 0x4
	ml_and_b32 v32, tid, 0x4
	ml_srl_b32 v75, v17, 0x4
	ml_slb_load_b32x1  v62, v69, noreg, #256, null
	ml_and_b32 v0, tid, 0x10
	ml_srl_b32 v4, v17, 0x1
	ml_shl_b32 v100, v3, 0x2
	ml_slb_load_b32x1  v60, v69, noreg, #768, null
	ml_shl_b32 v3, v3, 0x6
	ml_and_b32 v33, v77, 0x30
	ml_shl_b32 v0, v0, 0x1
	ml_slb_load_b32x1  v58, v69, s46, #256, null
	sl_mull_u32 s60, s7, 0x4
	ml_or_b32 v79, v1, v3
	ml_anyop3_b32 v71, v0, v4, v2, 0xfffffffe
	ml_slb_load_b32x1  v52, v69, s46, #768, null
	ml_mov_b32 v81, 0xff800000
	ml_mov_b32 v65, 0x0
	ml_mov_b32 v67, 0x0
	ml_mov_b32 v0, 0x0
	ml_mov_b32 v1, 0x0
	ml_mov_b32 v2, 0x0
	ml_mov_b32 v3, 0x0
	ml_mov_b32 v4, 0x0
	ml_mov_b32 v5, 0x0
	ml_mov_b32 v6, 0x0
	ml_mov_b32 v7, 0x0
	ml_mov_b32 v8, 0x0
	ml_mov_b32 v9, 0x0
	ml_mov_b32 v10, 0x0
	ml_mov_b32 v11, 0x0
	ml_mov_b32 v12, 0x0
	ml_mov_b32 v13, 0x0
	ml_mov_b32 v14, 0x0
	ml_mov_b32 v15, 0x0
	ml_mov_b32 v16, 0x0
	ml_mov_b32 v17, 0x0
	ml_mov_b32 v18, 0x0
	ml_mov_b32 v19, 0x0
	ml_mov_b32 v20, 0x0
	ml_mov_b32 v21, 0x0
	ml_mov_b32 v22, 0x0
	ml_mov_b32 v23, 0x0
	ml_mov_b32 v24, 0x0
	ml_mov_b32 v25, 0x0
	ml_mov_b32 v26, 0x0
	ml_mov_b32 v27, 0x0
	ml_mov_b32 v28, 0x0
	ml_mov_b32 v29, 0x0
	ml_mov_b32 v30, 0x0
	ml_mov_b32 v31, 0x0
	sl_cbr_wcrz BB0_4, wcr
; %bb.2:                                ; %.lr.ph
	.loc	1 0 16 is_stmt 0                ; biv150_v8_bf16p.py:0:16
	sl_mov_b32 s4, 0xcc0
	ml_anyop3_b32 v39, s4, v99, v100, 0xfffffff8
	ml_xor_b32 v40, v39, 0x10
	ml_xor_b32 v41, v39, 0x20
	ml_xor_b32 v42, v39, 0x30
	ml_xor_b32 v43, v79, 0x10
	ml_xor_b32 v44, v79, 0x20
	ml_xor_b32 v45, v79, 0x30
	sl_wait lmcnt(7)
	ml_mov_b32 v57, v56
	sl_wait lmcnt(3)
	ml_mov_b32 v63, v62
	ml_mov_b32 v55, v54
	sl_wait lmcnt(2)
	ml_mov_b32 v61, v60
	ml_mov_b32 v51, v50
	sl_wait lmcnt(1)
	ml_mov_b32 v59, v58
	ml_mov_b32 v49, v48
	sl_wait lmcnt(0)
	ml_mov_b32 v53, v52
	ml_and_b32 v0, v77, 0x30
	ml_and_b32 v1, tid, 0x4
	ml_cmp_eq_u32 tcr, v1, 0x0
	ml_mov_b32 v1, 0x280
	ml_csel_b32 v1, 0, v1, tcr
	sl_mov_b32 s40, 0xc00
	ml_anyop3_b32 v0, s40, v73, v0, 0xfffffff8
	ml_anyop3_b32 v46, v0, v75, v1, 0xfffffffe
	ml_xor_b32 v47, v46, 0x80
	ml_and_b32 v0, tid, 0x10
	ml_cmp_eq_u32 tcr, v0, 0x0
	ml_xor_b32 v101, v71, 0x10
	ml_mov_b32 v0, 0x0
	sl_mov_b32 s31, 0xffffffff
	sl_mov_b64 s[4:5], tcr
	sl_mov_b32 s41, 0x800
	ml_mov_b32 v1, 0x0
BB0_3:                                  ; =>This Inner Loop Header: Depth=1
	.loc	1 89 53 is_stmt 1               ; biv150_v8_bf16p.py:89:53
	sl_sra_b32 {s28, wcr}, s62, 0x4
	.loc	1 89 41 is_stmt 0               ; biv150_v8_bf16p.py:89:41
	sl_sra_b32 {s29, wcr}, s28, 0x1f
	sl_shl_b64 {s[28:29], wcr}, s[28:29], 0x2
	sl_add_i64 s[28:29], s[34:35], s[28:29]
	.loc	1 89 23                         ; biv150_v8_bf16p.py:89:23
	ml_lsa_load_dword v102, s[28:31], noreg, noreg, #0, ca
	.loc	1 102 36 is_stmt 1              ; biv150_v8_bf16p.py:102:36
	sl_shl_b64 {s[38:39], wcr}, s[32:33], 0x1
	.loc	1 102 20 is_stmt 0              ; biv150_v8_bf16p.py:102:20
	sl_mov_b64 s[54:55], s[50:51]
	ml_mov_b32 v118, v81
	ml_mov_b32 v119, v80
	.loc	1 89 23 is_stmt 1               ; biv150_v8_bf16p.py:89:23
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s28, v102, 0x0
	sl_sra_b32 {s29, wcr}, s28, 0x1f
	.loc	1 91 19                         ; biv150_v8_bf16p.py:91:19
	sl_mul_u64_u32 s[44:45], s36, s28
	sl_mull_u32 s48, s37, s28
	sl_mull_u32 s49, s36, s29
	sl_add_i32 s45, s45, s49
	sl_add_i32 s45, s45, s48
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_shl_b64 {s[44:45], wcr}, s[44:45], 0x1
	sl_add_i64 s[44:45], s[20:21], s[44:45]
	sl_add_i64 s[48:49], s[44:45], s[38:39]
	.loc	1 102 20 is_stmt 0              ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v102, s[48:51], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[48:49], s[26:27]
	.loc	1 97 19 is_stmt 1               ; biv150_v8_bf16p.py:97:19
	sl_mull_u32 s44, s42, s29
	sl_mul_u64_u32 s[38:39], s42, s28
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v103, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36 is_stmt 0              ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 97 19 is_stmt 1               ; biv150_v8_bf16p.py:97:19
	sl_add_i32 s39, s39, s44
	sl_mull_u32 s44, s43, s28
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v104, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36 is_stmt 0              ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 97 19 is_stmt 1               ; biv150_v8_bf16p.py:97:19
	sl_add_i32 s39, s39, s44
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v105, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36 is_stmt 0              ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v106, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v107, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v108, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v109, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v110, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v111, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v112, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v113, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v114, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v115, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v116, s[52:55], noreg, noreg, #0, ca
	.loc	1 102 36                        ; biv150_v8_bf16p.py:102:36
	sl_add_i64 s[52:53], s[52:53], s[26:27]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_lsa_blkload_x1 v117, s[52:55], noreg, noreg, #0, ca
	sl_wait vmcnt(0)
	sl_barrier 
	.loc	1 103 38 is_stmt 1              ; biv150_v8_bf16p.py:103:38
	sl_add_i64 s[38:39], s[22:23], s[38:39]
	sl_add_i64 s[38:39], s[18:19], s[38:39]
	ml_addo_u32 {v80, tcr}, s38, v78
	ml_mov_b32 v120, s39
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_store_b32x4  v[102:105], v39, noreg, #0, null
	.loc	1 105 30                        ; biv150_v8_bf16p.py:105:30
	sl_shl_b64 {s[28:29], wcr}, s[28:29], 0xe
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v81, v120, v98, tcr
	ml_addo_u32 {v80, tcr}, v84, v80
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_store_b32x4  v[106:109], v40, noreg, #256, null
	.loc	1 105 12                        ; biv150_v8_bf16p.py:105:12
	sl_add_i64 s[28:29], s[24:25], s[28:29]
	sl_add_i64 s[48:49], s[28:29], s[60:61]
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v81, 0, v81, tcr
	ml_addo_u32 {v121, tcr}, s38, v76
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_store_b32x4  v[110:113], v41, noreg, #512, null
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v103, v120, v97, tcr
	ml_addo_u32 {v102, tcr}, v84, v121
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_store_b32x4  v[114:117], v42, noreg, #768, null
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v103, 0, v103, tcr
	ml_addo_u32 {v104, tcr}, s38, v74
	.loc	1 103 20 is_stmt 0              ; biv150_v8_bf16p.py:103:20
	ml_lsa_load_a64_dword  v107, v[80:81], kop=0
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v105, v120, v96, tcr
	ml_addo_u32 {v104, tcr}, v84, v104
	.loc	1 105 12 is_stmt 1              ; biv150_v8_bf16p.py:105:12
	ml_lsa_load_dword v108, s[48:51], unsigned v82, noreg, #0, ca|mie
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v105, 0, v105, tcr
	ml_addo_u32 {v106, tcr}, s38, v70
	.loc	1 103 20 is_stmt 0              ; biv150_v8_bf16p.py:103:20
	ml_lsa_load_a64_dword  v112, v[104:105], kop=0
	sl_wait vmcnt(2)
	ml_and_b32 v109, v107, 0xff
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v81, v120, v95, tcr
	ml_addo_u32 {v80, tcr}, v84, v106
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_lsa_load_a64_dword  v106, v[102:103], kop=0
	ml_bfe2_b32 v110, v107, 0x108
	ml_bfe2_b32 v111, v107, 0x110
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v81, 0, v81, tcr
	ml_addo_u32 {v102, tcr}, s38, v66
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_bfe2_b32 v113, v107, 0x118
	ml_lsa_load_a64_dword  v107, v[80:81], kop=0
	sl_wait vmcnt(2)
	ml_and_b32 v121, v112, 0xff
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v103, v120, v94, tcr
	ml_addo_u32 {v102, tcr}, v84, v102
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_bfe2_b32 v122, v112, 0x108
	ml_bfe2_b32 v123, v112, 0x110
	sl_wait vmcnt(1)
	ml_and_b32 v114, v106, 0xff
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v103, 0, v103, tcr
	ml_addo_u32 {v104, tcr}, s38, v72
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_bfe2_b32 v115, v106, 0x108
	ml_bfe2_b32 v116, v106, 0x110
	ml_bfe2_b32 v117, v106, 0x118
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v105, v120, v92, tcr
	ml_addo_u32 {v104, tcr}, v84, v104
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_lsa_load_a64_dword  v106, v[102:103], kop=0
	ml_bfe2_b32 v112, v112, 0x118
	sl_wait vmcnt(1)
	ml_and_b32 v124, v107, 0xff
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v105, 0, v105, tcr
	ml_addo_u32 {v80, tcr}, s38, v68
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_bfe2_b32 v125, v107, 0x108
	ml_lsa_load_a64_dword  v104, v[104:105], kop=0
	ml_bfe2_b32 v126, v107, 0x110
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v81, v120, v90, tcr
	ml_addo_u32 {v80, tcr}, v84, v80
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	sl_wait vmcnt(1)
	ml_and_b32 v127, v106, 0xff
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v81, 0, v81, tcr
	ml_addo_u32 {v102, tcr}, s38, v64
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_lsa_load_a64_dword  v80, v[80:81], kop=0
	ml_bfe2_b32 v128, v106, 0x108
	ml_bfe2_b32 v129, v106, 0x110
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v103, v120, v86, tcr
	ml_addo_u32 {v102, tcr}, v84, v102
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_bfe2_b32 v120, v107, 0x118
	ml_bfe2_b32 v130, v106, 0x118
	sl_wait vmcnt(1)
	ml_and_b32 v131, v104, 0xff
	.loc	1 103 38                        ; biv150_v8_bf16p.py:103:38
	ml_addc_i32 v103, 0, v103, tcr
	.loc	1 103 20                        ; biv150_v8_bf16p.py:103:20
	ml_lsa_load_a64_dword  v81, v[102:103], kop=0
	ml_bfe2_b32 v132, v104, 0x108
	ml_bfe2_b32 v133, v104, 0x110
	ml_bfe2_b32 v134, v104, 0x118
	sl_wait vmcnt(1)
	ml_and_b32 v135, v80, 0xff
	ml_bfe2_b32 v136, v80, 0x108
	ml_bfe2_b32 v137, v80, 0x110
	ml_bfe2_b32 v138, v80, 0x118
	sl_wait vmcnt(0)
	ml_and_b32 v139, v81, 0xff
	ml_bfe2_b32 v140, v81, 0x108
	ml_bfe2_b32 v141, v81, 0x110
	ml_bfe2_b32 v142, v81, 0x118
	.loc	1 102 20 is_stmt 1              ; biv150_v8_bf16p.py:102:20
	sl_wait lmcnt(0)
	sl_barrier 
	ml_slb_load_b32x1  v80, v79, noreg, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	ml_mov_b32 v102, 0x0
	ml_mov_b32 v103, v34
	ml_mov_b32 v104, v34
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v81, v43, noreg, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	ml_mov_b32 v105, v34
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_cvt_i16_i8  v112, v112
	ml_cvt_bf16_i16  v112, v112
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v106, v44, noreg, #0, null
	ml_slb_load_b32x1  v107, v45, noreg, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[56:57], v[80:81], v[102:105]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v80, v79, s46, #0, null
	ml_slb_load_b32x1  v81, v43, s46, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[62:63], v[106:107], v[102:105]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v106, v44, s46, #0, null
	ml_slb_load_b32x1  v107, v45, s46, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[54:55], v[80:81], v[102:105]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v80, v79, s41, #0, null
	ml_slb_load_b32x1  v81, v43, s41, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[60:61], v[106:107], v[102:105]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v106, v44, s41, #0, null
	ml_slb_load_b32x1  v107, v45, s41, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[50:51], v[80:81], v[102:105]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v80, v79, s40, #0, null
	ml_slb_load_b32x1  v81, v43, s40, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[58:59], v[106:107], v[102:105]
	.loc	1 102 20                        ; biv150_v8_bf16p.py:102:20
	ml_slb_load_b32x1  v106, v44, s40, #0, null
	ml_slb_load_b32x1  v107, v45, s40, #0, null
	.loc	1 109 27                        ; biv150_v8_bf16p.py:109:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[48:49], v[80:81], v[102:105]
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[102:105], v[52:53], v[106:107], v[102:105]
	.loc	1 109 32 is_stmt 0              ; biv150_v8_bf16p.py:109:32
	ml_mul_f32 v81, s30, v102
.Ltmp3:
	.loc	2 213 40 is_stmt 1              ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v80, v81, v35
.Ltmp4:
	.loc	1 109 32                        ; biv150_v8_bf16p.py:109:32
	ml_mul_f32 v102, s30, v103
.Ltmp5:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v103, v102, v35
.Ltmp6:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v80, v81, v80
.Ltmp7:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v104, v80, v36
.Ltmp8:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v103, v102, v103
.Ltmp9:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v105, v103, v36
.Ltmp10:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v80, v80, v104
.Ltmp11:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v104, v80, v37
.Ltmp12:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v103, v103, v105
.Ltmp13:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v105, v103, v37
.Ltmp14:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v80, v80, v104
.Ltmp15:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v104, v80, v38
.Ltmp16:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v103, v103, v105
.Ltmp17:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ]
	ml_slb_shuffle_rtn_b32 v105, v103, v38
.Ltmp18:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v80, v80, v104
.Ltmp19:
	.loc	1 110 42                        ; biv150_v8_bf16p.py:110:42
	ml_max_f32 v80, v119, v80
	.loc	1 111 44                        ; biv150_v8_bf16p.py:111:44
	ml_sub_f32 v81, v81, v80
	.loc	1 112 45                        ; biv150_v8_bf16p.py:112:45
	ml_sub_f32 v119, v119, v80
	.loc	1 111 35                        ; biv150_v8_bf16p.py:111:35
	ml_exp_f32 v104, v81
.Ltmp20:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:110:57 ] ]
	sl_wait lmcnt(0)
	ml_max_f32 v81, v103, v105
.Ltmp21:
	.loc	1 110 42                        ; biv150_v8_bf16p.py:110:42
	ml_max_f32 v81, v118, v81
	.loc	1 111 44                        ; biv150_v8_bf16p.py:111:44
	ml_sub_f32 v102, v102, v81
	.loc	1 112 31                        ; biv150_v8_bf16p.py:112:31
	ml_exp_f32 v119, v119
.Ltmp22:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v103, v104, v35
.Ltmp23:
	.loc	1 111 35                        ; biv150_v8_bf16p.py:111:35
	ml_exp_f32 v102, v102
	.loc	1 114 36                        ; biv150_v8_bf16p.py:114:36
	ml_mul_f32 v0, v0, v119
	ml_mul_f32 v2, v2, v119
	ml_mul_f32 v4, v4, v119
	ml_mul_f32 v6, v6, v119
.Ltmp24:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v105, v102, v35
.Ltmp25:
	.loc	1 114 36                        ; biv150_v8_bf16p.py:114:36
	ml_mul_f32 v8, v8, v119
	ml_mul_f32 v10, v10, v119
	ml_mul_f32 v12, v12, v119
	ml_mul_f32 v14, v14, v119
	ml_mul_f32 v16, v16, v119
	ml_mul_f32 v18, v18, v119
	ml_mul_f32 v20, v20, v119
	ml_mul_f32 v22, v22, v119
	ml_mul_f32 v24, v24, v119
	ml_mul_f32 v26, v26, v119
	ml_mul_f32 v28, v28, v119
.Ltmp26:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v103, v104, v103
.Ltmp27:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v106, v103, v36
.Ltmp28:
	.loc	1 114 36                        ; biv150_v8_bf16p.py:114:36
	ml_mul_f32 v30, v30, v119
.Ltmp29:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v105, v102, v105
.Ltmp30:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v107, v105, v36
.Ltmp31:
	.loc	1 115 27                        ; biv150_v8_bf16p.py:115:27
	ml_mul_f32 v102, v108, v102
	.loc	1 115 52 is_stmt 0              ; biv150_v8_bf16p.py:115:52
	ml_cvt_bf16_f32  v102, v102
.Ltmp32:
	.loc	2 285 15 is_stmt 1              ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v103, v103, v106
.Ltmp33:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v106, v103, v37
.Ltmp34:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v105, v105, v107
.Ltmp35:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v107, v105, v37
.Ltmp36:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v103, v103, v106
.Ltmp37:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v106, v103, v38
.Ltmp38:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v105, v105, v107
.Ltmp39:
	.loc	1 112 45                        ; biv150_v8_bf16p.py:112:45
	ml_sub_f32 v107, v118, v81
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_cvt_i16_i8  v118, v126
	ml_cvt_i16_i8  v126, v133
	ml_cvt_i16_i8  v133, v140
	ml_cvt_bf16_i16  v118, v118
	ml_cvt_bf16_i16  v126, v126
	ml_cvt_bf16_i16  v133, v133
.Ltmp40:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v103, v103, v106
.Ltmp41:
	.loc	1 112 31                        ; biv150_v8_bf16p.py:112:31
	ml_exp_f32 v106, v107
	.loc	1 113 46                        ; biv150_v8_bf16p.py:113:46
	ml_fma_f32 v65, v65, v119, v103
.Ltmp42:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ]
	ml_slb_shuffle_rtn_b32 v103, v105, v38
.Ltmp43:
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_cvt_i16_i8  v107, v113
	ml_cvt_i16_i8  v113, v121
	ml_cvt_i16_i8  v119, v120
	.loc	1 114 36                        ; biv150_v8_bf16p.py:114:36
	ml_mul_f32 v1, v1, v106
	ml_mul_f32 v3, v3, v106
	ml_mul_f32 v5, v5, v106
	ml_mul_f32 v7, v7, v106
	ml_mul_f32 v9, v9, v106
	ml_mul_f32 v11, v11, v106
	ml_mul_f32 v13, v13, v106
	ml_mul_f32 v15, v15, v106
	ml_mul_f32 v17, v17, v106
	ml_mul_f32 v19, v19, v106
	ml_mul_f32 v21, v21, v106
	ml_mul_f32 v23, v23, v106
	ml_mul_f32 v25, v25, v106
	ml_mul_f32 v27, v27, v106
	ml_mul_f32 v29, v29, v106
	ml_mul_f32 v31, v31, v106
.Ltmp44:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:113:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v103, v105, v103
.Ltmp45:
	.loc	1 113 46                        ; biv150_v8_bf16p.py:113:46
	ml_fma_f32 v67, v67, v106, v103
	.loc	1 115 27                        ; biv150_v8_bf16p.py:115:27
	ml_mul_f32 v103, v108, v104
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_cvt_i16_i8  v104, v109
	ml_cvt_i16_i8  v105, v110
	ml_cvt_i16_i8  v106, v111
	ml_cvt_i16_i8  v108, v114
	ml_cvt_i16_i8  v109, v115
	ml_cvt_i16_i8  v110, v116
	ml_cvt_i16_i8  v111, v117
	ml_cvt_i16_i8  v114, v122
	ml_cvt_i16_i8  v115, v123
	ml_cvt_i16_i8  v116, v124
	ml_cvt_i16_i8  v117, v125
	ml_cvt_i16_i8  v120, v127
	ml_cvt_i16_i8  v121, v128
	ml_cvt_i16_i8  v122, v129
	ml_cvt_i16_i8  v123, v130
	ml_cvt_i16_i8  v124, v131
	ml_cvt_i16_i8  v125, v132
	ml_cvt_i16_i8  v127, v134
	ml_cvt_i16_i8  v128, v135
	ml_cvt_i16_i8  v129, v136
	ml_cvt_i16_i8  v130, v137
	ml_cvt_i16_i8  v131, v138
	ml_cvt_i16_i8  v132, v139
	ml_cvt_i16_i8  v134, v141
	ml_cvt_i16_i8  v135, v142
	ml_cvt_bf16_i16  v104, v104
	ml_cvt_bf16_i16  v105, v105
	ml_cvt_bf16_i16  v106, v106
	ml_cvt_bf16_i16  v107, v107
	ml_cvt_bf16_i16  v108, v108
	ml_cvt_bf16_i16  v109, v109
	ml_cvt_bf16_i16  v110, v110
	ml_cvt_bf16_i16  v111, v111
	ml_cvt_bf16_i16  v113, v113
	ml_cvt_bf16_i16  v114, v114
	ml_cvt_bf16_i16  v115, v115
	ml_cvt_bf16_i16  v116, v116
	ml_cvt_bf16_i16  v117, v117
	ml_cvt_bf16_i16  v119, v119
	ml_cvt_bf16_i16  v120, v120
	ml_cvt_bf16_i16  v121, v121
	ml_cvt_bf16_i16  v122, v122
	ml_cvt_bf16_i16  v123, v123
	ml_cvt_bf16_i16  v124, v124
	ml_cvt_bf16_i16  v125, v125
	ml_cvt_bf16_i16  v127, v127
	ml_cvt_bf16_i16  v128, v128
	ml_cvt_bf16_i16  v129, v129
	ml_cvt_bf16_i16  v130, v130
	ml_cvt_bf16_i16  v131, v131
	ml_cvt_bf16_i16  v132, v132
	ml_cvt_bf16_i16  v134, v134
	.loc	1 115 52                        ; biv150_v8_bf16p.py:115:52
	ml_cvt_bf16_f32  v103, v103
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_cvt_bf16_i16  v135, v135
	sl_barrier 
	.loc	1 115 52                        ; biv150_v8_bf16p.py:115:52
	sl_mov_b64 tcr, s[4:5]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_store_b16  v104, v46, noreg, #0, null
	.loc	1 115 52                        ; biv150_v8_bf16p.py:115:52
	ml_csel_b32 v104, v103, v102, tcr
	ml_cvt_i32_i16  v104, v104
	ml_csel_b32 v102, v102, v103, tcr
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_store_b16  v105, v46, noreg, #4, null
	.loc	1 115 52                        ; biv150_v8_bf16p.py:115:52
	ml_cvt_i32_i16  v102, v102
	sl_mov_b64 tcr, s[2:3]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_store_b16  v106, v46, noreg, #8, null
	ml_slb_store_b16  v107, v46, noreg, #12, null
	ml_slb_store_b16  v108, v46, noreg, #64, null
	ml_slb_store_b16  v109, v46, noreg, #68, null
	ml_slb_store_b16  v110, v46, noreg, #72, null
	ml_slb_store_b16  v111, v46, noreg, #76, null
	ml_slb_store_b16  v120, v46, noreg, #256, null
	ml_slb_store_b16  v121, v46, noreg, #260, null
	ml_slb_store_b16  v122, v46, noreg, #264, null
	ml_slb_store_b16  v123, v46, noreg, #268, null
	ml_slb_store_b16  v124, v46, noreg, #320, null
	ml_slb_store_b16  v125, v46, noreg, #324, null
	ml_slb_store_b16  v126, v46, noreg, #328, null
	ml_slb_store_b16  v127, v46, noreg, #332, null
	ml_slb_store_b16  v113, v47, noreg, #0, null
	ml_slb_store_b16  v114, v47, noreg, #4, null
	ml_slb_store_b16  v115, v47, noreg, #8, null
	ml_slb_store_b16  v112, v47, noreg, #12, null
	ml_slb_store_b16  v116, v47, noreg, #64, null
	ml_slb_store_b16  v117, v47, noreg, #68, null
	ml_slb_store_b16  v118, v47, noreg, #72, null
	ml_slb_store_b16  v119, v47, noreg, #76, null
	ml_slb_store_b16  v128, v47, noreg, #256, null
	ml_slb_store_b16  v129, v47, noreg, #260, null
	ml_slb_store_b16  v130, v47, noreg, #264, null
	ml_slb_store_b16  v131, v47, noreg, #268, null
	.loc	1 115 52                        ; biv150_v8_bf16p.py:115:52
	ml_slb_shuffle_rtn_b32 v104, v104, v71
	ml_slb_shuffle_rtn_b32 v102, v102, v101
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_store_b16  v132, v47, noreg, #320, null
	ml_slb_store_b16  v133, v47, noreg, #324, null
	ml_slb_store_b16  v134, v47, noreg, #328, null
	.loc	1 115 52                        ; biv150_v8_bf16p.py:115:52
	sl_wait lmcnt(4)
	ml_and_b32 v103, v104, 0xffff
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_store_b16  v135, v47, noreg, #332, null
	.loc	1 115 52                        ; biv150_v8_bf16p.py:115:52
	sl_wait lmcnt(4)
	ml_and_b32 v102, v102, 0xffff
	ml_csel_b32 v106, v103, v102, tcr
	ml_csel_b32 v107, v102, v103, tcr
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	sl_wait lmcnt(0)
	sl_barrier 
	ml_slb_blkload_x1  v102, noreg, noreg, #0, null
	.loc	1 116 12 is_stmt 0              ; biv150_v8_bf16p.py:116:12
	ml_byte_permute_b32 v106, v107, v106, s47
	ml_mov_b32 v107, v106
	.loc	1 119 20 is_stmt 1              ; biv150_v8_bf16p.py:119:20
	sl_add_i32 s62, s62, 0x10
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_blkload_x1  v103, noreg, noreg, #256, null
	.loc	1 86 21                         ; biv150_v8_bf16p.py:86:21
	sl_cmp_lt_i32 wcr, s62, s9
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_load_b32x1  v104, v69, noreg, #512, null
	ml_slb_load_b32x1  v105, v69, noreg, #768, null
	.loc	1 116 12 is_stmt 0              ; biv150_v8_bf16p.py:116:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[0:3], v[106:107], v[102:103], v[0:3]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_blkload_x1  v102, noreg, s46, #0, null
	ml_slb_blkload_x1  v103, noreg, s46, #256, null
	.loc	1 116 12                        ; biv150_v8_bf16p.py:116:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[4:7], v[106:107], v[104:105], v[4:7]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_load_b32x1  v104, v69, s46, #512, null
	ml_slb_load_b32x1  v105, v69, s46, #768, null
	.loc	1 116 12                        ; biv150_v8_bf16p.py:116:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[8:11], v[106:107], v[102:103], v[8:11]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_blkload_x1  v102, noreg, s41, #0, null
	ml_slb_blkload_x1  v103, noreg, s41, #256, null
	.loc	1 116 12                        ; biv150_v8_bf16p.py:116:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[12:15], v[106:107], v[104:105], v[12:15]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_load_b32x1  v104, v69, s41, #512, null
	ml_slb_load_b32x1  v105, v69, s41, #768, null
	.loc	1 116 12                        ; biv150_v8_bf16p.py:116:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[16:19], v[106:107], v[102:103], v[16:19]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_blkload_x1  v102, noreg, s40, #0, null
	ml_slb_blkload_x1  v103, noreg, s40, #256, null
	.loc	1 116 12                        ; biv150_v8_bf16p.py:116:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[20:23], v[106:107], v[104:105], v[20:23]
	.loc	1 116 17                        ; biv150_v8_bf16p.py:116:17
	ml_slb_load_b32x1  v104, v69, s40, #512, null
	ml_slb_load_b32x1  v105, v69, s40, #768, null
	.loc	1 116 12                        ; biv150_v8_bf16p.py:116:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[24:27], v[106:107], v[102:103], v[24:27]
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[28:31], v[106:107], v[104:105], v[28:31]
	sl_cbr_wcrnz BB0_3, wcr
BB0_4:                                  ; %._crit_edge
	.loc	1 121 20 is_stmt 1              ; biv150_v8_bf16p.py:121:20
	sl_cmp_lt_i32 wcr, s9, s6
	sl_cbr_wcrz BB0_54, wcr
; %bb.5:
	.loc	1 124 55                        ; biv150_v8_bf16p.py:124:55
	sl_sra_b32 {s4, wcr}, s9, 0x4
	.loc	1 124 41 is_stmt 0              ; biv150_v8_bf16p.py:124:41
	sl_sra_b32 {s5, wcr}, s4, 0x1f
	sl_mov_b32 s31, 0xffffffff
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x2
	sl_add_i64 s[28:29], s[34:35], s[4:5]
	.loc	1 124 23                        ; biv150_v8_bf16p.py:124:23
	ml_lsa_load_dword v32, s[28:31], noreg, noreg, #0, ca
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0x1
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v33, 0x0
	.loc	1 124 23                        ; biv150_v8_bf16p.py:124:23
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s34, v32, 0x0
	sl_sra_b32 {s35, wcr}, s34, 0x1f
	.loc	1 127 19                        ; biv150_v8_bf16p.py:127:19
	sl_mul_u64_u32 s[28:29], s36, s34
	sl_mull_u32 s5, s37, s34
	.loc	1 125 48                        ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	sl_sub_bi_u32 s4, s10, s10, wcr
	.loc	1 127 19                        ; biv150_v8_bf16p.py:127:19
	sl_mull_u32 s31, s36, s35
	sl_add_i32 s29, s29, s31
	.loc	1 138 36                        ; biv150_v8_bf16p.py:138:36
	sl_shl_b64 {s[32:33], wcr}, s[32:33], 0x1
	.loc	1 127 19                        ; biv150_v8_bf16p.py:127:19
	sl_add_i32 s29, s29, s5
	.loc	1 138 36                        ; biv150_v8_bf16p.py:138:36
	sl_shl_b64 {s[28:29], wcr}, s[28:29], 0x1
	sl_add_i64 s[20:21], s[20:21], s[28:29]
	sl_add_i64 s[28:29], s[20:21], s[32:33]
	.loc	1 138 20 is_stmt 0              ; biv150_v8_bf16p.py:138:20
	sl_mov_b32 s31, 0xfff00004
	ml_lsa_blkload_x1 v32, s[28:31], noreg, noreg, #0, ca
	.loc	1 138 36                        ; biv150_v8_bf16p.py:138:36
	sl_shl_b64 {s[20:21], wcr}, s[26:27], 0x1
	sl_mov_b32 s5, 0x0
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	sl_or_b32 {s4, wcr}, s4, 0x0
	sl_cbr_wcrz BB0_7, wcr
; %bb.6:
	sl_add_i64 s[36:37], s[28:29], s[26:27]
	sl_mov_b64 s[38:39], s[30:31]
	ml_lsa_blkload_x1 v33, s[36:39], noreg, noreg, #0, ca
BB0_7:
	.loc	1 0 0                           ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[20:21]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0x2
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v34, 0x0
	sl_cbr_wcrz BB0_9, wcr
; %bb.8:
	ml_lsa_blkload_x1 v34, s[28:31], noreg, noreg, #0, ca
BB0_9:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0x3
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	sl_mov_b32 s4, 0x0
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v35, 0x0
	sl_cbr_wcrz BB0_11, wcr
; %bb.10:
	ml_lsa_blkload_x1 v35, s[28:31], noreg, noreg, #0, ca
BB0_11:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s5, s9, 0x4
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s5, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v36, 0x0
	sl_cbr_wcrz BB0_13, wcr
; %bb.12:
	ml_lsa_blkload_x1 v36, s[28:31], noreg, noreg, #0, ca
BB0_13:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0x5
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	sl_mov_b32 s4, 0x0
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v37, 0x0
	sl_cbr_wcrz BB0_15, wcr
; %bb.14:
	ml_lsa_blkload_x1 v37, s[28:31], noreg, noreg, #0, ca
BB0_15:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s5, s9, 0x6
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s5, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v38, 0x0
	sl_cbr_wcrz BB0_17, wcr
; %bb.16:
	ml_lsa_blkload_x1 v38, s[28:31], noreg, noreg, #0, ca
BB0_17:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0x7
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	sl_mov_b32 s4, 0x0
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v39, 0x0
	sl_cbr_wcrz BB0_19, wcr
; %bb.18:
	ml_lsa_blkload_x1 v39, s[28:31], noreg, noreg, #0, ca
BB0_19:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s5, s9, 0x8
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s5, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v40, 0x0
	sl_cbr_wcrz BB0_21, wcr
; %bb.20:
	ml_lsa_blkload_x1 v40, s[28:31], noreg, noreg, #0, ca
BB0_21:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0x9
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	sl_mov_b32 s4, 0x0
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v41, 0x0
	sl_cbr_wcrz BB0_23, wcr
; %bb.22:
	ml_lsa_blkload_x1 v41, s[28:31], noreg, noreg, #0, ca
BB0_23:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s5, s9, 0xa
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s5, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v42, 0x0
	sl_cbr_wcrz BB0_25, wcr
; %bb.24:
	ml_lsa_blkload_x1 v42, s[28:31], noreg, noreg, #0, ca
BB0_25:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0xb
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	sl_mov_b32 s4, 0x0
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v43, 0x0
	sl_cbr_wcrz BB0_27, wcr
; %bb.26:
	ml_lsa_blkload_x1 v43, s[28:31], noreg, noreg, #0, ca
BB0_27:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s5, s9, 0xc
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s5, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v44, 0x0
	sl_cbr_wcrz BB0_29, wcr
; %bb.28:
	ml_lsa_blkload_x1 v44, s[28:31], noreg, noreg, #0, ca
BB0_29:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0xd
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	sl_mov_b32 s4, 0x0
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v45, 0x0
	sl_cbr_wcrz BB0_31, wcr
; %bb.30:
	ml_lsa_blkload_x1 v45, s[28:31], noreg, noreg, #0, ca
BB0_31:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s5, s9, 0xe
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s5, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v46, 0x0
	sl_cbr_wcrz BB0_33, wcr
; %bb.32:
	ml_lsa_blkload_x1 v46, s[28:31], noreg, noreg, #0, ca
BB0_33:
	.loc	1 125 36                        ; biv150_v8_bf16p.py:125:36
	sl_add_i32 s4, s9, 0xf
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	sl_cmp_lt_i32 wcr, s4, s6
	.loc	1 138 20 is_stmt 1              ; biv150_v8_bf16p.py:138:20
	ml_mov_b32 v47, 0x0
	sl_cbr_wcrz BB0_35, wcr
; %bb.34:
	.loc	1 0 0 is_stmt 0                 ; biv150_v8_bf16p.py:0
	sl_add_i64 s[28:29], s[28:29], s[26:27]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_lsa_blkload_x1 v47, s[28:31], noreg, noreg, #0, ca
                                        ; implicit-def: $vgpr49
BB0_35:
	.loc	1 63 29 is_stmt 1               ; biv150_v8_bf16p.py:63:29
	ml_bfe2_b32 v49, tid, 0x25
	.loc	1 125 36                        ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v49, s9, v49
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v49
	.loc	1 133 19 is_stmt 1              ; biv150_v8_bf16p.py:133:19
	sl_mull_u32 s20, s42, s35
	sl_mul_u64_u32 s[4:5], s42, s34
	sl_add_i32 s5, s5, s20
	sl_mull_u32 s20, s43, s34
	sl_add_i32 s5, s5, s20
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	sl_mov_b32 s20, 0xcc0
	ml_anyop3_b32 v49, s20, v99, v100, 0xfffffff8
	ml_slb_store_b32x4  v[32:35], v49, noreg, #0, null
	.loc	1 139 38                        ; biv150_v8_bf16p.py:139:38
	sl_add_i64 s[4:5], s[22:23], s[4:5]
	ml_xor_b32 v32, v49, 0x10
	ml_xor_b32 v35, v49, 0x30
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_store_b32x4  v[36:39], v32, noreg, #256, null
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_mov_b32 v34, 0x0
	ml_xor_b32 v32, v49, 0x20
	sl_add_i64 s[4:5], s[18:19], s[4:5]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_store_b32x4  v[40:43], v32, noreg, #512, null
	ml_mov_b32 v33, 0x0
	ml_slb_store_b32x4  v[44:47], v35, noreg, #768, null
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_37
BB0_36:
	.loc	1 0 20 is_stmt 0                ; biv150_v8_bf16p.py:0:20
	ml_addo_u32 {v32, tcr}, s4, v78
	ml_mov_b32 v33, s5
	ml_addc_i32 v33, v33, v98, tcr
	ml_addo_u32 {v32, tcr}, v84, v32
	ml_addc_i32 v33, 0, v33, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v33, v[32:33], kop=0
BB0_37:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v93
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_39
BB0_38:
	.loc	1 139 38 is_stmt 0              ; biv150_v8_bf16p.py:139:38
	ml_addo_u32 {v32, tcr}, s4, v76
	ml_mov_b32 v34, s5
	ml_addc_i32 v35, v34, v97, tcr
	ml_addo_u32 {v34, tcr}, v84, v32
	ml_addc_i32 v35, 0, v35, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v34, v[34:35], kop=0
BB0_39:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v91
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	ml_mov_b32 v37, 0x0
	ml_mov_b32 v35, 0x0
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_41
BB0_40:
	.loc	1 139 38 is_stmt 0              ; biv150_v8_bf16p.py:139:38
	ml_addo_u32 {v32, tcr}, s4, v74
	ml_mov_b32 v35, s5
	ml_addc_i32 v36, v35, v96, tcr
	ml_addo_u32 {v35, tcr}, v84, v32
	ml_addc_i32 v36, 0, v36, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v35, v[35:36], kop=0
BB0_41:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v88
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_43
BB0_42:
	.loc	1 139 38 is_stmt 0              ; biv150_v8_bf16p.py:139:38
	ml_addo_u32 {v32, tcr}, s4, v70
	ml_mov_b32 v36, s5
	ml_addc_i32 v37, v36, v95, tcr
	ml_addo_u32 {v36, tcr}, v84, v32
	ml_addc_i32 v37, 0, v37, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v37, v[36:37], kop=0
BB0_43:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v85
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	ml_mov_b32 v39, 0x0
	ml_mov_b32 v38, 0x0
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_45
BB0_44:
	.loc	1 139 38 is_stmt 0              ; biv150_v8_bf16p.py:139:38
	ml_addo_u32 {v32, tcr}, s4, v66
	ml_mov_b32 v36, s5
	ml_addc_i32 v36, v36, v94, tcr
	ml_addo_u32 {v40, tcr}, v84, v32
	ml_addc_i32 v41, 0, v36, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v38, v[40:41], kop=0
BB0_45:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v89
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_47
BB0_46:
	.loc	1 139 38 is_stmt 0              ; biv150_v8_bf16p.py:139:38
	ml_addo_u32 {v32, tcr}, s4, v72
	ml_mov_b32 v36, s5
	ml_addc_i32 v36, v36, v92, tcr
	ml_addo_u32 {v39, tcr}, v84, v32
	ml_addc_i32 v40, 0, v36, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v39, v[39:40], kop=0
BB0_47:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v87
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	ml_mov_b32 v41, 0x0
	ml_mov_b32 v40, 0x0
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_49
BB0_48:
	.loc	1 139 38 is_stmt 0              ; biv150_v8_bf16p.py:139:38
	ml_addo_u32 {v32, tcr}, s4, v68
	ml_mov_b32 v36, s5
	ml_addc_i32 v36, v36, v90, tcr
	ml_addo_u32 {v42, tcr}, v84, v32
	ml_addc_i32 v43, 0, v36, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v40, v[42:43], kop=0
BB0_49:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 125 36 is_stmt 1              ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v83
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_51
BB0_50:
	.loc	1 139 38 is_stmt 0              ; biv150_v8_bf16p.py:139:38
	ml_addo_u32 {v32, tcr}, s4, v64
	ml_mov_b32 v36, s5
	ml_addc_i32 v36, v36, v86, tcr
	ml_addo_u32 {v41, tcr}, v84, v32
	ml_addc_i32 v42, 0, v36, tcr
	.loc	1 139 20                        ; biv150_v8_bf16p.py:139:20
	ml_lsa_load_a64_dword  v41, v[41:42], kop=0
BB0_51:
	.loc	1 0 20                          ; biv150_v8_bf16p.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 63 29 is_stmt 1               ; biv150_v8_bf16p.py:63:29
	ml_and_b32 v32, tid, 0xf
	.loc	1 125 36                        ; biv150_v8_bf16p.py:125:36
	ml_add_i32 v32, s9, v32
	.loc	1 125 48 is_stmt 0              ; biv150_v8_bf16p.py:125:48
	ml_cmp_gt_i32 tcr, s6, v32
	.loc	1 141 12 is_stmt 1              ; biv150_v8_bf16p.py:141:12
	ml_mov_b32 v32, 0x0
	ml_mov_b32 v36, 0x0
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_53
BB0_52:
	.loc	1 141 30 is_stmt 0              ; biv150_v8_bf16p.py:141:30
	sl_shl_b64 {s[18:19], wcr}, s[34:35], 0xe
	sl_add_i64 s[18:19], s[24:25], s[18:19]
	.loc	1 142 48 is_stmt 1              ; biv150_v8_bf16p.py:142:48
	sl_mov_b32 s61, 0x0
	.loc	1 141 12                        ; biv150_v8_bf16p.py:141:12
	sl_add_i64 s[20:21], s[18:19], s[60:61]
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_load_dword v36, s[20:23], unsigned v82, noreg, #0, ca|mie
BB0_53:
	.loc	1 0 12 is_stmt 0                ; biv150_v8_bf16p.py:0:12
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 139 20 is_stmt 1              ; biv150_v8_bf16p.py:139:20
	sl_wait vmcnt(1)
	ml_and_b32 v42, v41, 0xff
	ml_bfe2_b32 v43, v41, 0x108
	ml_bfe2_b32 v44, v41, 0x110
	ml_bfe2_b32 v41, v41, 0x118
	ml_and_b32 v45, v40, 0xff
	ml_bfe2_b32 v46, v40, 0x108
	ml_bfe2_b32 v47, v40, 0x110
	ml_bfe2_b32 v64, v40, 0x118
	ml_and_b32 v66, v39, 0xff
	ml_bfe2_b32 v68, v39, 0x108
	ml_bfe2_b32 v70, v39, 0x110
	ml_bfe2_b32 v72, v39, 0x118
	ml_and_b32 v74, v38, 0xff
	ml_bfe2_b32 v76, v38, 0x108
	ml_bfe2_b32 v78, v38, 0x110
	ml_bfe2_b32 v82, v38, 0x118
	ml_and_b32 v83, v37, 0xff
	ml_bfe2_b32 v84, v37, 0x108
	ml_bfe2_b32 v85, v37, 0x110
	ml_bfe2_b32 v86, v37, 0x118
	ml_and_b32 v87, v35, 0xff
	ml_bfe2_b32 v88, v35, 0x108
	ml_bfe2_b32 v89, v35, 0x110
	ml_bfe2_b32 v90, v35, 0x118
	ml_and_b32 v91, v34, 0xff
	ml_bfe2_b32 v92, v34, 0x108
	ml_bfe2_b32 v93, v34, 0x110
	ml_bfe2_b32 v94, v34, 0x118
	ml_and_b32 v95, v33, 0xff
	ml_bfe2_b32 v96, v33, 0x108
	ml_bfe2_b32 v97, v33, 0x110
	ml_bfe2_b32 v98, v33, 0x118
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	ml_slb_load_b32x1  v37, v79, noreg, #0, null
	ml_xor_b32 v49, v79, 0x10
	ml_xor_b32 v53, v79, 0x20
	ml_xor_b32 v99, v79, 0x30
	ml_slb_load_b32x1  v38, v49, noreg, #0, null
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v57, v56
	ml_mov_b32 v33, v32
	ml_mov_b32 v34, v32
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v39, v53, noreg, #0, null
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v35, v32
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	sl_mov_b32 s6, 0x400
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v63, v62
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v40, v99, noreg, #0, null
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v55, v54
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	sl_mov_b32 s5, 0x800
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v61, v60
	ml_mov_b32 v51, v50
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	sl_mov_b32 s4, 0xc00
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v59, v58
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v45, v45
	ml_cvt_i16_i8  v46, v46
	ml_cvt_i16_i8  v47, v47
	ml_cvt_i16_i8  v64, v64
	ml_cvt_i16_i8  v42, v42
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[56:57], v[37:38], v[32:35]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v37, v79, s6, #0, null
	ml_slb_load_b32x1  v38, v49, s6, #0, null
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v56, v84
	ml_cvt_i16_i8  v57, v85
	ml_cvt_i16_i8  v43, v43
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[62:63], v[39:40], v[32:35]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v39, v53, s6, #0, null
	ml_slb_load_b32x1  v40, v99, s6, #0, null
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v62, v82
	ml_cvt_i16_i8  v63, v66
	ml_cvt_i16_i8  v66, v68
	ml_cvt_i16_i8  v68, v70
	ml_cvt_i16_i8  v70, v72
	ml_cvt_i16_i8  v44, v44
	ml_cvt_i16_i8  v41, v41
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[54:55], v[37:38], v[32:35]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v37, v79, s5, #0, null
	ml_slb_load_b32x1  v38, v49, s5, #0, null
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v54, v90
	ml_cvt_i16_i8  v55, v83
	ml_cvt_bf16_i16  v54, v54
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[60:61], v[39:40], v[32:35]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v39, v53, s5, #0, null
	ml_slb_load_b32x1  v40, v99, s5, #0, null
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v60, v76
	ml_cvt_i16_i8  v61, v78
	ml_cvt_bf16_i16  v55, v55
	ml_cvt_bf16_i16  v56, v56
	ml_cvt_bf16_i16  v57, v57
	ml_cvt_bf16_i16  v60, v60
	ml_cvt_bf16_i16  v61, v61
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[50:51], v[37:38], v[32:35]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v37, v79, s4, #0, null
	ml_slb_load_b32x1  v38, v49, s4, #0, null
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v49, v48
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v51, v87
	ml_cvt_bf16_i16  v51, v51
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[58:59], v[39:40], v[32:35]
	.loc	1 138 20                        ; biv150_v8_bf16p.py:138:20
	ml_slb_load_b32x1  v39, v53, s4, #0, null
	ml_slb_load_b32x1  v40, v99, s4, #0, null
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	ml_mov_b32 v53, v52
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v58, v86
	ml_cvt_i16_i8  v59, v74
	ml_cvt_bf16_i16  v58, v58
	ml_cvt_bf16_i16  v59, v59
	ml_cvt_bf16_i16  v62, v62
	ml_cvt_bf16_i16  v63, v63
	.loc	1 146 27                        ; biv150_v8_bf16p.py:146:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[48:49], v[37:38], v[32:35]
	ml_xor_b32 v38, tid, 0x4
	ml_xor_b32 v48, tid, 0x2
	ml_xor_b32 v49, tid, 0x1
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[52:53], v[39:40], v[32:35]
	ml_mov_b32 v34, 0xff800000
	ml_xor_b32 v35, tid, 0x8
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v52, v88
	.loc	1 146 32                        ; biv150_v8_bf16p.py:146:32
	ml_mul_f32 v32, s30, v32
	.loc	1 147 57                        ; biv150_v8_bf16p.py:147:57
	ml_csel_b32 v32, v32, v34, tcr
.Ltmp46:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v37, v32, v35
.Ltmp47:
	.loc	1 146 32                        ; biv150_v8_bf16p.py:146:32
	ml_mul_f32 v33, s30, v33
	.loc	1 147 57                        ; biv150_v8_bf16p.py:147:57
	ml_csel_b32 v33, v33, v34, tcr
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v53, v89
.Ltmp48:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v34, v33, v35
.Ltmp49:
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_bf16_i16  v52, v52
	ml_cvt_bf16_i16  v53, v53
	ml_cvt_bf16_i16  v66, v66
	ml_cvt_bf16_i16  v68, v68
	ml_cvt_bf16_i16  v70, v70
	ml_cvt_bf16_i16  v45, v45
	ml_cvt_bf16_i16  v46, v46
	ml_cvt_bf16_i16  v47, v47
	ml_cvt_bf16_i16  v64, v64
	ml_cvt_bf16_i16  v42, v42
	ml_cvt_bf16_i16  v43, v43
	ml_cvt_bf16_i16  v44, v44
	ml_cvt_bf16_i16  v41, v41
.Ltmp50:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v37, v32, v37
.Ltmp51:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v39, v37, v38
.Ltmp52:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v34, v33, v34
.Ltmp53:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v40, v34, v38
.Ltmp54:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v37, v37, v39
.Ltmp55:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v39, v37, v48
.Ltmp56:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v34, v34, v40
.Ltmp57:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v40, v34, v48
.Ltmp58:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v37, v37, v39
.Ltmp59:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v39, v37, v49
.Ltmp60:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v34, v34, v40
.Ltmp61:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ]
	ml_slb_shuffle_rtn_b32 v40, v34, v49
.Ltmp62:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v37, v37, v39
.Ltmp63:
	.loc	1 148 42                        ; biv150_v8_bf16p.py:148:42
	ml_max_f32 v50, v80, v37
	.loc	1 149 44                        ; biv150_v8_bf16p.py:149:44
	ml_sub_f32 v32, v32, v50
	.loc	1 150 45                        ; biv150_v8_bf16p.py:150:45
	ml_sub_f32 v39, v80, v50
	.loc	1 149 35                        ; biv150_v8_bf16p.py:149:35
	ml_exp_f32 v32, v32
.Ltmp64:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_v8_bf16p.py:148:57 ] ]
	sl_wait lmcnt(0)
	ml_max_f32 v34, v34, v40
.Ltmp65:
	.loc	1 148 42                        ; biv150_v8_bf16p.py:148:42
	ml_max_f32 v40, v81, v34
	.loc	1 149 44                        ; biv150_v8_bf16p.py:149:44
	ml_sub_f32 v33, v33, v40
	.loc	1 150 31                        ; biv150_v8_bf16p.py:150:31
	ml_exp_f32 v39, v39
.Ltmp66:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v34, v32, v35
.Ltmp67:
	.loc	1 149 35                        ; biv150_v8_bf16p.py:149:35
	ml_exp_f32 v33, v33
	.loc	1 152 36                        ; biv150_v8_bf16p.py:152:36
	ml_mul_f32 v0, v0, v39
	ml_mul_f32 v2, v2, v39
	ml_mul_f32 v4, v4, v39
	ml_mul_f32 v6, v6, v39
.Ltmp68:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v35, v33, v35
.Ltmp69:
	.loc	1 152 36                        ; biv150_v8_bf16p.py:152:36
	ml_mul_f32 v8, v8, v39
	ml_mul_f32 v10, v10, v39
	ml_mul_f32 v12, v12, v39
	ml_mul_f32 v14, v14, v39
	ml_mul_f32 v16, v16, v39
	ml_mul_f32 v18, v18, v39
	ml_mul_f32 v20, v20, v39
	ml_mul_f32 v22, v22, v39
	ml_mul_f32 v24, v24, v39
	ml_mul_f32 v26, v26, v39
	ml_mul_f32 v28, v28, v39
.Ltmp70:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v34, v32, v34
.Ltmp71:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v37, v34, v38
.Ltmp72:
	.loc	1 152 36                        ; biv150_v8_bf16p.py:152:36
	ml_mul_f32 v30, v30, v39
	.loc	1 153 27                        ; biv150_v8_bf16p.py:153:27
	ml_mul_f32 v32, v36, v32
	.loc	1 153 52 is_stmt 0              ; biv150_v8_bf16p.py:153:52
	ml_cvt_bf16_f32  v72, v32
.Ltmp73:
	.loc	2 285 15 is_stmt 1              ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v35, v33, v35
.Ltmp74:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v38, v35, v38
.Ltmp75:
	.loc	1 153 27                        ; biv150_v8_bf16p.py:153:27
	ml_mul_f32 v33, v36, v33
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v36, v97
	ml_cvt_bf16_i16  v36, v36
	.loc	1 153 52                        ; biv150_v8_bf16p.py:153:52
	ml_cvt_bf16_f32  v74, v33
.Ltmp76:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v34, v34, v37
.Ltmp77:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v37, v34, v48
.Ltmp78:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v35, v35, v38
.Ltmp79:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v38, v35, v48
.Ltmp80:
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v48, v93
	ml_cvt_bf16_i16  v48, v48
.Ltmp81:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v34, v34, v37
.Ltmp82:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v37, v34, v49
.Ltmp83:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v35, v35, v38
.Ltmp84:
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v38, v91
	ml_cvt_bf16_i16  v38, v38
.Ltmp85:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v34, v34, v37
.Ltmp86:
	.loc	1 150 45                        ; biv150_v8_bf16p.py:150:45
	ml_sub_f32 v37, v81, v40
	.loc	1 151 46                        ; biv150_v8_bf16p.py:151:46
	ml_fma_f32 v65, v65, v39, v34
	.loc	1 150 31                        ; biv150_v8_bf16p.py:150:31
	ml_exp_f32 v34, v37
.Ltmp87:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ]
	ml_slb_shuffle_rtn_b32 v37, v35, v49
.Ltmp88:
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v39, v92
	ml_cvt_i16_i8  v49, v94
	ml_cvt_bf16_i16  v39, v39
	ml_cvt_bf16_i16  v49, v49
	.loc	1 152 36                        ; biv150_v8_bf16p.py:152:36
	ml_mul_f32 v1, v1, v34
	ml_mul_f32 v3, v3, v34
	ml_mul_f32 v5, v5, v34
	ml_mul_f32 v7, v7, v34
	ml_mul_f32 v9, v9, v34
	ml_mul_f32 v11, v11, v34
	ml_mul_f32 v13, v13, v34
	ml_mul_f32 v15, v15, v34
	ml_mul_f32 v17, v17, v34
	ml_mul_f32 v19, v19, v34
	ml_mul_f32 v21, v21, v34
	ml_mul_f32 v23, v23, v34
	ml_mul_f32 v25, v25, v34
	ml_mul_f32 v27, v27, v34
	ml_mul_f32 v29, v29, v34
.Ltmp89:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_v8_bf16p.py:151:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v35, v35, v37
.Ltmp90:
	.loc	1 151 46                        ; biv150_v8_bf16p.py:151:46
	ml_fma_f32 v67, v67, v34, v35
	.loc	1 152 36                        ; biv150_v8_bf16p.py:152:36
	ml_mul_f32 v31, v31, v34
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_cvt_i16_i8  v34, v95
	ml_cvt_i16_i8  v35, v96
	ml_cvt_i16_i8  v37, v98
	ml_cvt_bf16_i16  v34, v34
	ml_cvt_bf16_i16  v35, v35
	ml_cvt_bf16_i16  v37, v37
	sl_barrier 
	ml_and_b32 v33, v77, 0x30
	ml_and_b32 v32, tid, 0x4
	ml_cmp_eq_u32 tcr, v32, 0x0
	ml_anyop3_b32 v73, s4, v73, v75, 0xfffffff8
	ml_mov_b32 v75, 0x280
	ml_csel_b32 v75, 0, v75, tcr
	ml_anyop3_b32 v73, v73, v75, v33, 0xfffffffe
	ml_slb_store_b16  v34, v73, noreg, #0, null
	ml_xor_b32 v34, v73, 0x80
	ml_slb_store_b16  v35, v73, noreg, #4, null
	ml_and_b32 v35, tid, 0x10
	.loc	1 153 52                        ; biv150_v8_bf16p.py:153:52
	ml_cmp_eq_u32 tcr, v35, 0x0
	ml_csel_b32 v35, v72, v74, tcr
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_store_b16  v36, v73, noreg, #8, null
	.loc	1 153 52                        ; biv150_v8_bf16p.py:153:52
	ml_cvt_i32_i16  v35, v35
	ml_csel_b32 v36, v74, v72, tcr
	ml_cvt_i32_i16  v36, v36
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_store_b16  v37, v73, noreg, #12, null
	.loc	1 153 52                        ; biv150_v8_bf16p.py:153:52
	ml_xor_b32 v37, v71, 0x10
	sl_mov_b64 tcr, s[2:3]
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_store_b16  v38, v73, noreg, #64, null
	ml_slb_store_b16  v39, v73, noreg, #68, null
	ml_slb_store_b16  v48, v73, noreg, #72, null
	ml_slb_store_b16  v49, v73, noreg, #76, null
	ml_slb_store_b16  v59, v73, noreg, #256, null
	ml_slb_store_b16  v60, v73, noreg, #260, null
	ml_slb_store_b16  v61, v73, noreg, #264, null
	ml_slb_store_b16  v62, v73, noreg, #268, null
	ml_slb_store_b16  v63, v73, noreg, #320, null
	ml_slb_store_b16  v66, v73, noreg, #324, null
	ml_slb_store_b16  v68, v73, noreg, #328, null
	ml_slb_store_b16  v70, v73, noreg, #332, null
	ml_slb_store_b16  v51, v34, noreg, #0, null
	ml_slb_store_b16  v52, v34, noreg, #4, null
	ml_slb_store_b16  v53, v34, noreg, #8, null
	ml_slb_store_b16  v54, v34, noreg, #12, null
	ml_slb_store_b16  v55, v34, noreg, #64, null
	ml_slb_store_b16  v56, v34, noreg, #68, null
	ml_slb_store_b16  v57, v34, noreg, #72, null
	ml_slb_store_b16  v58, v34, noreg, #76, null
	ml_slb_store_b16  v45, v34, noreg, #256, null
	ml_slb_store_b16  v46, v34, noreg, #260, null
	ml_slb_store_b16  v47, v34, noreg, #264, null
	ml_slb_store_b16  v64, v34, noreg, #268, null
	ml_slb_store_b16  v42, v34, noreg, #320, null
	.loc	1 153 52                        ; biv150_v8_bf16p.py:153:52
	ml_slb_shuffle_rtn_b32 v35, v35, v71
	ml_slb_shuffle_rtn_b32 v36, v36, v37
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_store_b16  v43, v34, noreg, #324, null
	ml_slb_store_b16  v44, v34, noreg, #328, null
	ml_slb_store_b16  v41, v34, noreg, #332, null
	.loc	1 153 52                        ; biv150_v8_bf16p.py:153:52
	sl_wait lmcnt(4)
	ml_and_b32 v34, v35, 0xffff
	sl_wait lmcnt(3)
	ml_and_b32 v35, v36, 0xffff
	ml_csel_b32 v38, v34, v35, tcr
	ml_csel_b32 v39, v35, v34, tcr
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	sl_wait lmcnt(0)
	sl_barrier 
	ml_slb_blkload_x1  v34, noreg, noreg, #0, null
	.loc	1 154 12 is_stmt 0              ; biv150_v8_bf16p.py:154:12
	sl_mov_b32 s2, 0x1000504
	ml_byte_permute_b32 v38, v39, v38, s2
	ml_mov_b32 v39, v38
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_blkload_x1  v35, noreg, noreg, #256, null
	ml_mov_b32 v80, v50
	ml_mov_b32 v81, v40
	ml_slb_load_b32x1  v36, v69, noreg, #512, null
	ml_slb_load_b32x1  v37, v69, noreg, #768, null
	.loc	1 154 12                        ; biv150_v8_bf16p.py:154:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[0:3], v[38:39], v[34:35], v[0:3]
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_blkload_x1  v0, noreg, s6, #0, null
	ml_slb_blkload_x1  v1, noreg, s6, #256, null
	.loc	1 154 12                        ; biv150_v8_bf16p.py:154:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[4:7], v[38:39], v[36:37], v[4:7]
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_load_b32x1  v4, v69, s6, #512, null
	ml_slb_load_b32x1  v5, v69, s6, #768, null
	.loc	1 154 12                        ; biv150_v8_bf16p.py:154:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[8:11], v[38:39], v[0:1], v[8:11]
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_blkload_x1  v0, noreg, s5, #0, null
	ml_slb_blkload_x1  v1, noreg, s5, #256, null
	.loc	1 154 12                        ; biv150_v8_bf16p.py:154:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[12:15], v[38:39], v[4:5], v[12:15]
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_load_b32x1  v4, v69, s5, #512, null
	ml_slb_load_b32x1  v5, v69, s5, #768, null
	.loc	1 154 12                        ; biv150_v8_bf16p.py:154:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[16:19], v[38:39], v[0:1], v[16:19]
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_blkload_x1  v0, noreg, s4, #0, null
	ml_slb_blkload_x1  v1, noreg, s4, #256, null
	.loc	1 154 12                        ; biv150_v8_bf16p.py:154:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[20:23], v[38:39], v[4:5], v[20:23]
	.loc	1 154 17                        ; biv150_v8_bf16p.py:154:17
	ml_slb_load_b32x1  v4, v69, s4, #512, null
	ml_slb_load_b32x1  v5, v69, s4, #768, null
	.loc	1 154 12                        ; biv150_v8_bf16p.py:154:12
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[24:27], v[38:39], v[0:1], v[24:27]
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[28:31], v[38:39], v[4:5], v[28:31]
BB0_54:
	.loc	1 61 28 is_stmt 1               ; biv150_v8_bf16p.py:61:28
	ml_and_b32 v24, tid, 0x30
	ml_srl_b32 v0, v24, 0x4
	.loc	1 69 29                         ; biv150_v8_bf16p.py:69:29
	sl_mull_u32 s2, s7, 0x8
	.loc	1 69 46 is_stmt 0               ; biv150_v8_bf16p.py:69:46
	ml_add_i32 v0, s2, v0
	.loc	1 164 31 is_stmt 1              ; biv150_v8_bf16p.py:164:31
	sl_shl_b64 {s[2:3], wcr}, s[0:1], 0x11
	sl_add_i64 s[2:3], s[12:13], s[2:3]
	ml_shl_b32 v0, v0, 0xd
	sl_mov_b32 s13, 0x0
	sl_mull_u32 s12, s8, 0x200
	sl_add_i64 s[2:3], s[12:13], s[2:3]
	ml_addo_u32 {v0, tcr}, s2, v0
	ml_mov_b32 v1, s3
	.loc	1 63 29                         ; biv150_v8_bf16p.py:63:29
	ml_and_b32 v4, tid, 0xf
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_shl_b32 v4, v4, 0x2
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v0, tcr}, v4, v0
	sl_mov_b32 s2, 0x8000
	.loc	1 166 20                        ; biv150_v8_bf16p.py:166:20
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x8
	.loc	1 166 68 is_stmt 0              ; biv150_v8_bf16p.py:166:68
	sl_mov_b32 s9, s13
	.loc	1 164 31 is_stmt 1              ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s2, v0
	sl_mov_b32 s2, 0x40
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[0:1], v2, kop=0
	.loc	1 166 39 is_stmt 1              ; biv150_v8_bf16p.py:166:39
	sl_add_i64 s[0:1], s[0:1], s[8:9]
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v8, tcr}, s2, v0
	sl_mov_b32 s2, 0x8040
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[4:5], v3, kop=0
	.loc	1 172 44 is_stmt 1              ; biv150_v8_bf16p.py:172:44
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v9, 0, v1, tcr
	ml_addo_u32 {v12, tcr}, s2, v0
	sl_mov_b32 s2, 0x80
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[8:9], v6, kop=0
	.loc	1 172 44 is_stmt 1              ; biv150_v8_bf16p.py:172:44
	sl_add_i64 s[12:13], s[14:15], s[0:1]
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v13, 0, v1, tcr
	ml_addo_u32 {v16, tcr}, s2, v0
	sl_mov_b32 s2, 0x8080
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[12:13], v7, kop=0
	.loc	1 172 44 is_stmt 1              ; biv150_v8_bf16p.py:172:44
	sl_mov_b32 s15, 0xffffffff
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v17, 0, v1, tcr
	ml_addo_u32 {v20, tcr}, s2, v0
	sl_mov_b32 s2, 0xc0
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[16:17], v10, kop=0
	.loc	1 172 44 is_stmt 1              ; biv150_v8_bf16p.py:172:44
	sl_mull_u32 s6, s7, 0x200
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v21, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s2, v0
	sl_mov_b32 s2, 0x80c0
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[20:21], v11, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s2, v0
	sl_mov_b32 s2, 0x100
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[2:3], v14, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v6, tcr}, s2, v0
	sl_mov_b32 s2, 0x8100
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[4:5], v15, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v7, 0, v1, tcr
	ml_addo_u32 {v8, tcr}, s2, v0
	sl_mov_b32 s2, 0x140
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[6:7], v18, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v9, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s2, v0
	sl_mov_b32 s2, 0x8140
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[8:9], v19, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s2, v0
	sl_mov_b32 s2, 0x180
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[2:3], v22, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v6, tcr}, s2, v0
	sl_mov_b32 s2, 0x8180
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[4:5], v23, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v7, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s2, v0
	sl_mov_b32 s2, 0x1c0
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[6:7], v26, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s2, v0
	.loc	1 164 47                        ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[2:3], v27, kop=0
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	sl_mov_b32 s2, 0x81c0
	.loc	1 172 44 is_stmt 1              ; biv150_v8_bf16p.py:172:44
	ml_and_b32 v2, tid, 0x1
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v0, tcr}, s2, v0
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[4:5], v30, kop=0
	.loc	1 172 44 is_stmt 1              ; biv150_v8_bf16p.py:172:44
	ml_srl_b32 v3, v32, 0x2
	.loc	1 75 16                         ; biv150_v8_bf16p.py:75:16
	ml_and_b32 v4, tid, 0x8
	.loc	1 164 31                        ; biv150_v8_bf16p.py:164:31
	ml_addc_i32 v1, 0, v1, tcr
	.loc	1 164 47 is_stmt 0              ; biv150_v8_bf16p.py:164:47
	ml_lsa_store_a64_dword  v[0:1], v31, kop=0
	.loc	1 172 58 is_stmt 1              ; biv150_v8_bf16p.py:172:58
	ml_mul_f32 v0, v80, 0x3f317218
	ml_mul_f32 v1, v81, 0x3f317218
	.loc	1 172 44 is_stmt 0              ; biv150_v8_bf16p.py:172:44
	ml_cmp_eq_u32 tcr, v2, 0x0
	ml_srl_b32 v2, v24, 0x3
	ml_or_b32 v2, v2, v33
	ml_anyop3_b32 v2, v2, v3, v4, 0xfffffffe
	ml_csel_b32 v3, v0, v1, tcr
	ml_slb_shuffle_rtn_b32 v3, v3, v2
	ml_csel_b32 v0, v1, v0, tcr
	ml_xor_b32 v1, v2, 0x1
	.loc	1 173 47 is_stmt 1              ; biv150_v8_bf16p.py:173:47
	ml_csel_b32 v5, v67, v65, tcr
	.loc	1 172 44                        ; biv150_v8_bf16p.py:172:44
	ml_slb_shuffle_rtn_b32 v4, v0, v1
	.loc	1 173 47                        ; biv150_v8_bf16p.py:173:47
	ml_csel_b32 v0, v65, v67, tcr
	.loc	1 172 44                        ; biv150_v8_bf16p.py:172:44
	ml_cmp_eq_u32 tcr, v32, 0x0
	.loc	1 173 47                        ; biv150_v8_bf16p.py:173:47
	ml_slb_shuffle_rtn_b32 v0, v0, v2
	.loc	1 172 44                        ; biv150_v8_bf16p.py:172:44
	ml_and_b32 v2, tid, 0x38
	sl_mov_b64 s[2:3], tcr
	ml_cmp_eq_u32 tcr, v2, 0x0
	.loc	1 173 47                        ; biv150_v8_bf16p.py:173:47
	ml_slb_shuffle_rtn_b32 v1, v5, v1
	.loc	1 61 28                         ; biv150_v8_bf16p.py:61:28
	ml_and_b32 v2, tid, 0x7
	ml_shl_b32 v2, v2, 0x6
	.loc	1 172 44                        ; biv150_v8_bf16p.py:172:44
	sl_mov_b64 s[4:5], tcr
	sl_mov_b64 tcr, s[2:3]
	ml_add_i32 v2, s6, v2
	sl_wait lmcnt(2)
	ml_csel_b32 v3, v3, v4, tcr
	sl_and_savetmsk_b64 {s[10:11], wcr}, s[4:5], tmsk
	ml_lsa_store_dword v3, s[12:15], signed v2, noreg, #0, wb
	sl_or_b64 {tmsk, wcr}, tmsk, s[10:11]
	.loc	1 173 47                        ; biv150_v8_bf16p.py:173:47
	sl_and_savetmsk_b64 {s[6:7], wcr}, s[4:5], tmsk
	sl_xor_b64 {s[4:5], wcr}, tmsk, s[6:7]
	; mask branch BB0_56
BB0_55:
	.loc	1 0 47 is_stmt 0                ; biv150_v8_bf16p.py:0:47
	sl_mov_b64 tcr, s[2:3]
	sl_wait lmcnt(0)
	ml_csel_b32 v0, v0, v1, tcr
	.loc	1 173 47                        ; biv150_v8_bf16p.py:173:47
	sl_add_i64 s[12:13], s[16:17], s[0:1]
	ml_lsa_store_dword v0, s[12:15], signed v2, noreg, #0, wb
BB0_56:                                 ; %Flow
	.loc	1 0 47                          ; biv150_v8_bf16p.py:0:47
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
BB0_57:                                 ; %common.ret
	sl_eop 
.Ltmp91:
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.globl	gqa_decode_v8_bf16p.kd
	.type	gqa_decode_v8_bf16p.kd,@object
	.size	gqa_decode_v8_bf16p.kd, 64
gqa_decode_v8_bf16p.kd:
	.asciz	"\000\000\000"
	.long	0
	.asciz	"\000\000\000\000\000\000\000"
	.quad	gqa_decode_v8_bf16p@rel64-gqa_decode_v8_bf16p.kd
	.asciz	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.long	537123
	.asciz	"\003\000\364\006\211\000\000\000\000\000\000"
	.text
.Lfunc_end0:
	.size	gqa_decode_v8_bf16p, .Lfunc_end0-gqa_decode_v8_bf16p
	.cfi_endproc
                                        ; -- End function
	.section	.Iluvatar.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 11056
; NumSgprs: 67
; NumVgprs: 143
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 12
; IeeeMode: 1
; SLBByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 8
; VGPRBlocks: 35
; NumSGPRsForWarpsPerNU: 63
; NumVGPRsForWarpsPerNR: 143
; ReqNTIDx: 0
; MaxNTIDx: 0
; MinCTASm: 0
; ActiveWarp: 1
; WarpLimiterHint : 0
	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	8                               ; DW_FORM_string
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	16                              ; DW_AT_stmt_list
	.byte	6                               ; DW_FORM_data4
	.byte	27                              ; DW_AT_comp_dir
	.byte	8                               ; DW_FORM_string
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	32                              ; DW_AT_inline
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	1                               ; DW_CHILDREN_yes
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	6                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	7                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	5                               ; DW_FORM_data2
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
	.long	312                             ; Length of Unit
	.short	2                               ; DWARF version number
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	8                               ; Address Size (in bytes)
	.byte	1                               ; Abbrev [1] 0xb:0x131 DW_TAG_compile_unit
	.ascii	"triton"                        ; DW_AT_producer
	.byte	0
	.short	2                               ; DW_AT_language
	.ascii	"biv150_v8_bf16p.py"            ; DW_AT_name
	.byte	0
	.long	.debug_line                     ; DW_AT_stmt_list
	.ascii	"/workspace/experiments/minicpm-s2/code/cjj-v8-bf16p-ragged-v2-20261027/tools/kernels" ; DW_AT_comp_dir
	.byte	0
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.byte	2                               ; Abbrev [2] 0x91:0x16 DW_TAG_subprogram
	.ascii	"gqa_decode_v8_bf16p"           ; DW_AT_name
	.byte	0
	.byte	1                               ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0xa7:0x94 DW_TAG_subprogram
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.long	145                             ; DW_AT_abstract_origin
	.byte	4                               ; Abbrev [4] 0xbc:0x18 DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.quad	.Ltmp1                          ; DW_AT_low_pc
	.quad	.Ltmp2                          ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	55                              ; DW_AT_call_line
	.byte	41                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xd4:0x19 DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges0                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	110                             ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0xe0:0xc DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges1                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0xed:0x1a DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges2                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	113                             ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0xf9:0xd DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges3                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x107:0x19 DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges4                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	148                             ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x113:0xc DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges5                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x120:0x1a DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges6                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	151                             ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0x12c:0xd DW_TAG_inlined_subroutine
	.long	145                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges7                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp19-.Lfunc_begin0
	.quad	.Ltmp20-.Lfunc_begin0
	.quad	.Ltmp21-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	.Ltmp17-.Lfunc_begin0
	.quad	.Ltmp18-.Lfunc_begin0
	.quad	.Ltmp19-.Lfunc_begin0
	.quad	.Ltmp20-.Lfunc_begin0
	.quad	.Ltmp21-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp22-.Lfunc_begin0
	.quad	.Ltmp23-.Lfunc_begin0
	.quad	.Ltmp24-.Lfunc_begin0
	.quad	.Ltmp25-.Lfunc_begin0
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	.Ltmp28-.Lfunc_begin0
	.quad	.Ltmp29-.Lfunc_begin0
	.quad	.Ltmp31-.Lfunc_begin0
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp39-.Lfunc_begin0
	.quad	.Ltmp40-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp42-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp44-.Lfunc_begin0
	.quad	.Ltmp45-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges3:
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	.Ltmp27-.Lfunc_begin0
	.quad	.Ltmp29-.Lfunc_begin0
	.quad	.Ltmp30-.Lfunc_begin0
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp33-.Lfunc_begin0
	.quad	.Ltmp34-.Lfunc_begin0
	.quad	.Ltmp35-.Lfunc_begin0
	.quad	.Ltmp36-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp38-.Lfunc_begin0
	.quad	.Ltmp39-.Lfunc_begin0
	.quad	.Ltmp40-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp44-.Lfunc_begin0
	.quad	.Ltmp45-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges4:
	.quad	.Ltmp46-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp48-.Lfunc_begin0
	.quad	.Ltmp49-.Lfunc_begin0
	.quad	.Ltmp50-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp64-.Lfunc_begin0
	.quad	.Ltmp65-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges5:
	.quad	.Ltmp50-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp52-.Lfunc_begin0
	.quad	.Ltmp53-.Lfunc_begin0
	.quad	.Ltmp54-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp56-.Lfunc_begin0
	.quad	.Ltmp57-.Lfunc_begin0
	.quad	.Ltmp58-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp60-.Lfunc_begin0
	.quad	.Ltmp61-.Lfunc_begin0
	.quad	.Ltmp62-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp64-.Lfunc_begin0
	.quad	.Ltmp65-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges6:
	.quad	.Ltmp66-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp68-.Lfunc_begin0
	.quad	.Ltmp69-.Lfunc_begin0
	.quad	.Ltmp70-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	.Ltmp73-.Lfunc_begin0
	.quad	.Ltmp75-.Lfunc_begin0
	.quad	.Ltmp76-.Lfunc_begin0
	.quad	.Ltmp80-.Lfunc_begin0
	.quad	.Ltmp81-.Lfunc_begin0
	.quad	.Ltmp84-.Lfunc_begin0
	.quad	.Ltmp85-.Lfunc_begin0
	.quad	.Ltmp86-.Lfunc_begin0
	.quad	.Ltmp87-.Lfunc_begin0
	.quad	.Ltmp88-.Lfunc_begin0
	.quad	.Ltmp89-.Lfunc_begin0
	.quad	.Ltmp90-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges7:
	.quad	.Ltmp70-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp73-.Lfunc_begin0
	.quad	.Ltmp74-.Lfunc_begin0
	.quad	.Ltmp76-.Lfunc_begin0
	.quad	.Ltmp77-.Lfunc_begin0
	.quad	.Ltmp78-.Lfunc_begin0
	.quad	.Ltmp79-.Lfunc_begin0
	.quad	.Ltmp81-.Lfunc_begin0
	.quad	.Ltmp82-.Lfunc_begin0
	.quad	.Ltmp83-.Lfunc_begin0
	.quad	.Ltmp84-.Lfunc_begin0
	.quad	.Ltmp85-.Lfunc_begin0
	.quad	.Ltmp86-.Lfunc_begin0
	.quad	.Ltmp89-.Lfunc_begin0
	.quad	.Ltmp90-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	".note.GNU-stack","",@progbits
	.iluvatar_isa "bi-iluvatar-ilurt--ivcore-1-1-0"
	.iluvatar_hsa_metadata
---
iluvatar.kernels:
  - .args:
      - .address_space:  global
        .name:           KArg_0
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_1
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_2
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_3
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_4
        .offset:         32
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_5
        .offset:         40
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_6
        .offset:         48
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_7
        .offset:         56
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_8
        .offset:         64
        .size:           8
        .value_kind:     global_buffer
      - .name:           KArg_9
        .offset:         72
        .size:           4
        .value_kind:     by_value
      - .name:           KArg_10
        .offset:         80
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_11
        .offset:         88
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_12
        .offset:         96
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_13
        .offset:         104
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_14
        .offset:         112
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_15
        .offset:         120
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_16
        .offset:         128
        .size:           8
        .value_kind:     by_value
      - .address_space:  global
        .name:           KArg_17
        .offset:         136
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_18
        .offset:         144
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 152
    .max_flat_workgroup_size: 0
    .name:           gqa_decode_v8_bf16p
    .private_segment_fixed_size: 0
    .sgpr_count:     67
    .sgpr_spill_count: 0
    .symbol:         gqa_decode_v8_bf16p.kd
    .vgpr_count:     143
    .vgpr_spill_count: 0
    .warp_size:      64
iluvatar.version:
  - 1
  - 0
...

	.end_iluvatar_hsa_metadata
