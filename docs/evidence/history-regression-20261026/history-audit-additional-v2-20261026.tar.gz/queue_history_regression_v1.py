"""Wait for the exact owned PR53 queue, then replay the historical source privately."""
from pathlib import Path
import datetime,hashlib,json,os,socket,subprocess,time,traceback
R=Path('/workspace/experiments/minicpm-s2');E=R/'exports';TOOL=R/'code/history-regression-tool-v1-20261026';SOURCE=R/'code/gqa-wave-coverage-v3-20261024';OUT=R/'historical-pr28-currentconditions-4k-v1-20261026';STATE=E/'history-regression-queue-v1-state.json'
state={'phase':'starting','queue_pid':os.getpid(),'queue_start_ticks':int(Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]),'previous_owner':{'pid':419113,'start_ticks':329923968},'tool_commit':'5dc2b1a95d934ae1df360db42aba779c21b4972f','runtime_commit':'84c1be5fa5ae3d1f0b0485c5d430798913eb78f5','snapshot':str(E/'small-bf16-fullwarm-tuning-snapshot-v6-20261025'),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'acceptance_passed':False}
def save(phase,**kw):
 state.update(phase=phase,updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw);p=STATE.with_suffix('.tmp');p.write_text(json.dumps(state,indent=2));p.replace(STATE)
def identity(pid):
 try:
  x=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'state':x[0],'sid':int(x[3]),'start_ticks':int(x[19])}
 except FileNotFoundError:return None
def live(pid,ticks):
 v=identity(pid);return bool(v and v['state']!='Z' and v['start_ticks']==ticks)
def idle():
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',9031))!=0,'Port in use; never stop unowned services'
 assert 'No running processes found' in subprocess.check_output(['ixsmi'],text=True),'GPU busy; no concurrent test'
try:
 save('waiting_exact_pr53_v5')
 while live(419113,329923968):time.sleep(10)
 prior=json.loads((E/'small-mm-route-queue-v5-state.json').read_text());assert prior['phase'] in ('completed','failed');state['prior_phase']=prior['phase'];state['prior_error']=prior.get('error');idle()
 for source,commit in [(TOOL,state['tool_commit']),(SOURCE,state['runtime_commit'])]:
  assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==commit
  assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
 command=['/usr/local/bin/python','-u',str(TOOL/'tools/run_biv150_history_regression.py'),'--source',str(SOURCE),'--commit',state['runtime_commit'],'--out',str(OUT),'--gate-library',str(R/'code/baseline-profiler-v2-20261025/build-native-w8a8/biv150_native_w8a8.so'),'--native-mode','on','--stable-small-o','0','--legacy-no-small-o','--fixtures',str(E/'native-mixed-fixtures-20261025'),'--tuning-snapshot',state['snapshot'],'--run-throughput','--full-workload-warmup','--length','4096','--diagnostic-after-semantic-failure']
 with (E/'history-regression-pr28-v1.log').open('w') as f:p=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 owner=identity(p.pid);owner['command']=command;(E/'history-regression-pr28-v1-owner.json').write_text(json.dumps(owner,indent=2));save('historical_pr28_4k',child=owner)
 while p.poll() is None:time.sleep(3)
 assert p.returncode==0,p.returncode
 result=json.loads((OUT/'state.json').read_text());assert result['complete'] and result['cleanup_complete'] and result['diagnostic_scores_only'] and not result['qualifies_historical_baseline'];idle()
 scores=json.loads((OUT/'scores.json').read_text());state['scores']=scores;state['semantic_passed']=result['semantic_passed'];save('completed',child=None,diagnostic_only=True)
except BaseException as error:save('failed',error=repr(error),traceback=traceback.format_exc());raise
