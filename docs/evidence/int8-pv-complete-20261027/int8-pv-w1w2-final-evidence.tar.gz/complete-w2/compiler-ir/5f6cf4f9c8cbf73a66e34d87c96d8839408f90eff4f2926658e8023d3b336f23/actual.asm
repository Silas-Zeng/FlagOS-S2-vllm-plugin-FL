	.text
	.globl	gqa_decode_int8_pv              ; -- Begin function gqa_decode_int8_pv
	.p2align	3
	.type	gqa_decode_int8_pv,@function
	.iluvatar_kernel gqa_decode_int8_pv
gqa_decode_int8_pv:                     ; @gqa_decode_int8_pv
.Lfunc_begin0:
	.file	1 "/workspace/experiments/minicpm-s2/code/owned55-int8-pv-20261027/tools/kernels" "biv150_int8_pv.py"
	.loc	1 35 0                          ; biv150_int8_pv.py:35:0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_return_column 32
	.iluvatar_kernel_code_t
		iluvatar_code_version_major = 1
		iluvatar_code_version_minor = 3
		iluvatar_machine_kind = 1
		iluvatar_machine_version_major = 1
		iluvatar_machine_version_minor = 1
		iluvatar_machine_version_stepping = 0
		kernel_code_entry_byte_offset = 256
		kernel_code_prefetch_byte_size = 0
		granulated_workitem_vgpr_count = 38
		granulated_warp_sgpr_count = 12
		float_mode = 12
		debug_mode = 0
		has_mbar = 0
		user_sgpr_count = 6
		enable_sgpr_workgroup_id_x = 1
		enable_sgpr_workgroup_id_y = 1
		enable_sgpr_workgroup_id_z = 1
		enable_sgpr_workgroup_info = 1
		enable_vgpr_workitem_id = 3
		granulated_slb_size = 0
		enable_exception = 128
		enable_sgpr_private_segment_buffer = 1
		enable_sgpr_globalvariable_ptr = 0
		enable_sgpr_kernarg_segment_ptr = 1
		enable_sgpr_constvariable_ptr = 0
		enable_sgpr_private_segment_size = 0
		enable_sgpr_grid_workgroup_count_x = 0
		enable_sgpr_grid_workgroup_count_y = 0
		enable_sgpr_grid_workgroup_count_z = 0
		private_element_size = 1
		is_ptr64 = 1
		is_dynamic_callstack = 0
		is_debug_enabled = 0
		enable_private_swizzle = 1
		has_called_assert = 0
		has_called_printf = 0
		has_called_malloc = 0
		enable_srf_flat_shared = 0
		enable_srf_flat_scratch = 0
		has_wgmma = 0
		has_dva = 0
		enable_dynamic_smem_size = 0
		workitem_private_segment_byte_size = 0
		workgroup_group_segment_byte_size = 0
		kernarg_segment_byte_size = 152
		workgroup_fbarrier_count = 0
		warp_sgpr_count = 99
		workitem_vgpr_count = 153
		reserved_vgpr_first = 0
		reserved_vgpr_count = 0
		reserved_sgpr_first = 0
		reserved_sgpr_count = 0
		debug_warp_private_segment_offset_sgpr = 0
		debug_private_segment_buffer_sgpr = 0
		kernarg_segment_alignment = 3
		group_segment_alignment = 4
		private_segment_alignment = 4
		warp_size = 6
		call_convention = -1
		runtime_loader_kernel_symbol = 0
	.end_iluvatar_kernel_code_t
; %bb.0:
	; Func LiveIn Regs:
	;  blockIdx.x : s6  blockIdx.y : s7  blockIdx.z : s8
	ml_vrf_init_u32 v28, tcr
	sl_mov_b32 s60, s6
.Ltmp0:
	.loc	1 71 28 prologue_end            ; biv150_int8_pv.py:71:28
	sl_lsa_load_b32x16 s[12:27], s[4:5], noreg, #0, ca
	.loc	1 75 37                         ; biv150_int8_pv.py:75:37
	sl_mov_b32 s63, 0x0
	sl_mov_b32 s61, s63
	sl_shl_b64 {s[2:3], wcr}, s[60:61], 0x2
	sl_mov_b32 s31, 0xffffffff
	sl_wait smcnt(0)
	sl_add_i64 s[28:29], s[26:27], s[2:3]
	.loc	1 75 22 is_stmt 0               ; biv150_int8_pv.py:75:22
	ml_lsa_load_dword v0, s[28:31], noreg, noreg, #0, ca
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s0, v0, 0x0
.Ltmp1:
	.file	2 "/usr/local/lib/python3.12/site-packages/triton/language" "standard.py"
	.loc	2 65 17 is_stmt 1               ; standard.py:65:17 @[ biv150_int8_pv.py:76:41 ]
	sl_add_i32 s2, s0, 0x3f
	.loc	2 65 30 is_stmt 0               ; standard.py:65:30 @[ biv150_int8_pv.py:76:41 ]
	sl_sra_b32 {s3, wcr}, s2, 0x1f
	sl_srl_b32 {s3, wcr}, s3, 0x1a
	sl_add_i32 s2, s2, s3
	sl_sra_b32 {s2, wcr}, s2, 0x6
.Ltmp2:
	.loc	1 77 26 is_stmt 1               ; biv150_int8_pv.py:77:26
	sl_mull_u32 s3, s2, s8
	.loc	1 77 46 is_stmt 0               ; biv150_int8_pv.py:77:46
	sl_mull_u32 s72, s3, 0x10
	.loc	1 78 16 is_stmt 1               ; biv150_int8_pv.py:78:16
	sl_cmp_lt_i32 wcr, s72, s0
	sl_cbr_wcrz BB0_65, wcr
; %bb.1:
	.loc	1 0 0 is_stmt 0                 ; biv150_int8_pv.py:0
	ml_mov_s2v_b32 v152, s8, 0x0
	sl_lsa_load_b32x16 s[44:59], s[4:5], noreg, #128, ca
	sl_lsa_load_b32x16 s[28:43], s[4:5], noreg, #64, ca
	.loc	1 80 31 is_stmt 1               ; biv150_int8_pv.py:80:31
	sl_add_i32 s2, s3, s2
	sl_mull_u32 s4, s2, 0x10
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	sl_and_b32 {s27, wcr}, tcr_lo, 0x40
	sl_sub_bi_u32 s11, tcr_lo, tcr_lo, wcr
	ml_mov_s2v_b32 v152, s11, 0x2
	sl_bfe2_b32 s94, tcr_lo, 0x26
	sl_add_i32 s6, s94, 0x2
	sl_wait smcnt(0)
	sl_add_i32 s54, s94, 0x4
	sl_add_i32 s31, s94, 0x6
	.loc	1 90 29                         ; biv150_int8_pv.py:90:29
	sl_mull_u32 s26, s7, 0x8
	.loc	1 90 46 is_stmt 0               ; biv150_int8_pv.py:90:46
	sl_add_i32 s1, s6, s26
	sl_add_i32 s5, s54, s26
	sl_add_i32 s8, s31, s26
	.loc	1 92 20 is_stmt 1               ; biv150_int8_pv.py:92:20
	sl_mull_u32 s9, s35, s60
	sl_mul_u64_u32 s[2:3], s34, s60
	sl_add_i32 s3, s3, s9
	.loc	1 96 28                         ; biv150_int8_pv.py:96:28
	sl_shl_b64 {s[2:3], wcr}, s[2:3], 0x1
	sl_add_i64 s[2:3], s[18:19], s[2:3]
	sl_mull_u32 s62, s1, 0x100
	sl_add_i64 s[48:49], s[2:3], s[62:63]
	sl_mull_u32 s62, s5, 0x100
	sl_add_i64 s[56:57], s[2:3], s[62:63]
	sl_mull_u32 s62, s8, 0x100
	sl_add_i64 s[64:65], s[2:3], s[62:63]
	ml_mov_s2v_b32 v152, s26, 0x3
	.loc	1 90 46                         ; biv150_int8_pv.py:90:46
	sl_add_i32 s1, s94, s26
	.loc	1 96 28                         ; biv150_int8_pv.py:96:28
	sl_mull_u32 s62, s1, 0x100
	sl_add_i64 s[52:53], s[2:3], s[62:63]
	.loc	1 96 16 is_stmt 0               ; biv150_int8_pv.py:96:16
	sl_mov_b32 s55, 0xfff00004
	ml_lsa_blkload_x1 v0, s[52:55], noreg, noreg, #0, ca
	.loc	1 80 62 is_stmt 1               ; biv150_int8_pv.py:80:62
	sl_min_i32 s90, s4, s0
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	ml_and_b32 v5, tid, 0x30
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_mov_b64 s[50:51], s[54:55]
	ml_lsa_blkload_x1 v1, s[48:51], noreg, noreg, #0, ca
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	ml_and_b32 v2, tid, 0x7
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	sl_add_i32 s47, s94, 0x8
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_mov_b64 s[58:59], s[54:55]
	ml_lsa_blkload_x1 v3, s[56:59], noreg, noreg, #0, ca
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	sl_add_i32 s46, s94, 0xa
	sl_add_i32 s34, s94, 0xc
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_mov_b64 s[66:67], s[54:55]
	ml_lsa_blkload_x1 v4, s[64:67], noreg, noreg, #0, ca
	ml_shl_b32 v6, v5, 0x5
	ml_shl_b32 v2, v2, 0x3
	ml_and_b32 v7, tid, 0x8
	ml_cmp_eq_u32 tcr, v7, 0x0
	ml_mov_b32 v7, 0x180
	ml_csel_b32 v7, 0, v7, tcr
	ml_mov_s2v_b32 v152, s27, 0x4
	sl_srl_b32 {s0, wcr}, s27, 0x5
	ml_or_b32 v2, v6, v2
	ml_anyop3_b32 v2, s0, v7, v2, 0xfffffffe
	sl_wait vmcnt(3)
	ml_slb_store_b16  v0, v2, noreg, #0, null
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	sl_add_i32 s35, s94, 0xe
	sl_add_i32 s26, s94, 0x12
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_srl_b32 v0, v0, 0x10
	ml_slb_store_b16  v0, v2, noreg, #4, null
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	sl_add_i32 s19, s94, 0x14
	sl_add_i32 s8, s94, 0x16
	sl_add_i32 s9, s94, 0x18
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_wait vmcnt(2)
	ml_slb_store_b16  v1, v2, noreg, #64, null
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	sl_add_i32 s18, s94, 0x1a
	sl_add_i32 s5, s94, 0x1c
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_srl_b32 v0, v1, 0x10
	ml_slb_store_b16  v0, v2, noreg, #68, null
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	sl_add_i32 s4, s94, 0x1e
	ml_and_b32 v6, tid, 0xf
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_xor_b32 v0, v2, 0x80
	sl_wait vmcnt(1)
	ml_slb_store_b16  v3, v0, noreg, #0, null
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_bfe2_b32 v50, v28, 0x45
	ml_add_i32 v55, v50, 0x4
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_srl_b32 v1, v3, 0x10
	ml_slb_store_b16  v1, v0, noreg, #4, null
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v54, v50, 0x8
	ml_add_i32 v53, v50, 0xc
	.loc	1 94 19                         ; biv150_int8_pv.py:94:19
	ml_shl_b32 v1, v28, 0x2
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_wait vmcnt(0)
	ml_slb_store_b16  v4, v0, noreg, #64, null
	.loc	1 94 19                         ; biv150_int8_pv.py:94:19
	ml_and_b32 v49, v1, 0x7c
	ml_mov_b32 v64, 0x0
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_srl_b32 v1, v4, 0x10
	ml_slb_store_b16  v1, v0, noreg, #68, null
	.loc	1 98 50                         ; biv150_int8_pv.py:98:50
	sl_mull_u32 s2, s33, s60
	ml_mov_s2v_b32 v152, s60, 0x5
	ml_mov_s2v_b32 v152, s61, 0x6
	sl_mul_u64_u32 s[0:1], s32, s60
	sl_add_i32 s1, s1, s2
	.loc	1 98 40 is_stmt 0               ; biv150_int8_pv.py:98:40
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	sl_add_i64 s[2:3], s[28:29], s[0:1]
	ml_mov_s2v_b32 v152, s26, 0x7
	.loc	1 99 30 is_stmt 1               ; biv150_int8_pv.py:99:30
	sl_and_b32 {s0, wcr}, s26, 0x3
	ml_mov_s2v_b32 v152, s19, 0x8
	sl_and_b32 {s1, wcr}, s19, 0x5
	ml_mov_s2v_b32 v152, s8, 0x9
	sl_and_b32 {s8, wcr}, s8, 0x7
	ml_mov_s2v_b32 v152, s9, 0xa
	sl_and_b32 {s9, wcr}, s9, 0x9
	ml_mov_s2v_b32 v152, s18, 0xb
	sl_and_b32 {s18, wcr}, s18, 0xb
	ml_mov_s2v_b32 v152, s5, 0xc
	sl_and_b32 {s19, wcr}, s5, 0xd
	ml_mov_s2v_b32 v152, s4, 0xd
	sl_and_b32 {s28, wcr}, s4, 0xf
	.loc	1 105 35                        ; biv150_int8_pv.py:105:35
	sl_sub_i32 s4, s90, s72
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[0:1], s45, v50
	.loc	1 105 45                        ; biv150_int8_pv.py:105:45
	sl_sra_b32 {s5, wcr}, s4, 0x1f
	sl_srl_b32 {s5, wcr}, s5, 0x1b
	sl_add_i32 s4, s4, s5
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[26:27], s44, v50
	.loc	1 105 59                        ; biv150_int8_pv.py:105:59
	sl_and_b32 {s4, wcr}, s4, 0xffffffe0
	.loc	1 105 25 is_stmt 0              ; biv150_int8_pv.py:105:25
	sl_add_i32 s86, s4, s72
	.loc	1 114 37 is_stmt 1              ; biv150_int8_pv.py:114:37
	sl_mull_u32 s26, s39, s94
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[1:2], s45, v55
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mul_u64_u32 s[4:5], s38, s94
	sl_add_i32 s5, s5, s26
	sl_mull_u32 s29, s39, s6
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[24:25], s44, v55
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mul_u64_u32 s[26:27], s38, s6
	sl_add_i32 s27, s27, s29
	sl_mull_u32 s29, s39, s54
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[2:3], s45, v54
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mul_u64_u32 s[32:33], s38, s54
	sl_add_i32 s33, s33, s29
	sl_mull_u32 s29, s39, s31
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[22:23], s44, v54
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mul_u64_u32 s[82:83], s38, s31
	sl_add_i32 s83, s83, s29
	sl_mull_u32 s29, s39, s47
	ml_mov_s2v_b32 v152, s31, 0xe
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[3:4], s45, v53
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mul_u64_u32 s[56:57], s38, s47
	sl_add_i32 s57, s57, s29
	sl_mull_u32 s29, s39, s46
	ml_mov_s2v_b32 v152, s47, 0xf
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[20:21], s44, v53
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mul_u64_u32 s[60:61], s38, s46
	sl_add_i32 s61, s61, s29
	sl_mull_u32 s29, s39, s34
	ml_mov_s2v_b32 v152, s46, 0x10
	ml_mov_s2v_b32 v152, s34, 0x11
	sl_mul_u64_u32 s[64:65], s38, s34
	sl_add_i32 s65, s65, s29
	sl_mull_u32 s29, s39, s35
	ml_mov_s2v_b32 v152, s35, 0x12
	sl_mul_u64_u32 s[70:71], s38, s35
	sl_add_i32 s71, s71, s29
	sl_mull_u32 s29, s39, s0
	sl_mul_u64_u32 s[34:35], s38, s0
	sl_add_i32 s35, s35, s29
	sl_mull_u32 s0, s39, s1
	sl_mul_u64_u32 s[44:45], s38, s1
	sl_add_i32 s45, s45, s0
	sl_mull_u32 s0, s39, s8
	sl_mul_u64_u32 s[46:47], s38, s8
	sl_add_i32 s47, s47, s0
	sl_mull_u32 s0, s39, s9
	sl_mul_u64_u32 s[74:75], s38, s9
	sl_add_i32 s75, s75, s0
	sl_mull_u32 s0, s39, s18
	sl_mul_u64_u32 s[58:59], s38, s18
	sl_add_i32 s59, s59, s0
	sl_mull_u32 s0, s39, s19
	sl_mul_u64_u32 s[66:67], s38, s19
	sl_add_i32 s67, s67, s0
	sl_mull_u32 s0, s39, s28
	sl_mul_u64_u32 s[38:39], s38, s28
	sl_add_i32 s39, s39, s0
	.loc	1 115 28                        ; biv150_int8_pv.py:115:28
	sl_mull_u32 s0, s41, s7
	sl_mul_u64_u32 s[40:41], s40, s7
	sl_add_i32 s41, s41, s0
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v61, v27, v0
	ml_add_i32 v60, v25, v1
	ml_add_i32 v59, v23, v2
	ml_add_i32 v57, v21, v3
	.loc	1 121 28                        ; biv150_int8_pv.py:121:28
	sl_mull_u32 s18, s7, 0x80
	.loc	1 121 14 is_stmt 0              ; biv150_int8_pv.py:121:14
	sl_mov_b32 s19, s63
	.loc	1 127 44 is_stmt 1              ; biv150_int8_pv.py:127:44
	ml_shl_b32 v52, v6, 0x1
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_wait lmcnt(0)
	sl_barrier 
	ml_shl_b32 v0, tid, 0x2
	sl_mov_b32 s73, 0x400
	ml_slb_blkload_x1  v14, noreg, noreg, #0, null
	ml_xor_b32 v1, v0, 0x80
	.loc	1 107 21                        ; biv150_int8_pv.py:107:21
	sl_cmp_lt_i32 wcr, s72, s86
	.loc	1 107 4 is_stmt 0               ; biv150_int8_pv.py:107:4
	ml_mov_b32 v48, 0xff800000
	.loc	1 96 16 is_stmt 1               ; biv150_int8_pv.py:96:16
	ml_slb_blkload_x1  v12, noreg, noreg, #512, null
	ml_shl_b32 v56, v28, 0x6
	ml_and_b32 v2, tid, 0xc
	ml_and_b32 v3, tid, 0x3
	ml_slb_blkload_x1  v8, noreg, s73, #0, null
	ml_and_b32 v6, tid, 0x20
	ml_xor_b32 v65, tid, 0x8
	ml_xor_b32 v66, tid, 0x4
	ml_slb_blkload_x1  v4, noreg, s73, #512, null
	ml_xor_b32 v67, tid, 0x2
	ml_xor_b32 v68, tid, 0x1
	ml_shl_b32 v5, v5, 0x2
	ml_slb_load_b32x1  v18, v1, noreg, #256, null
	ml_and_b32 v62, v56, 0xcc0
	ml_shl_b32 v63, v2, 0x2
	ml_shl_b32 v58, v3, 0x3
	ml_slb_load_b32x1  v16, v1, noreg, #768, null
	ml_shl_b32 v7, v2, 0x6
	ml_shl_b32 v2, v2, 0x3
	ml_shl_b32 v3, v3, 0x1
	ml_slb_load_b32x1  v10, v1, s73, #256, null
	ml_srl_b32 v46, v6, 0x2
	ml_or_b32 v44, v5, v52
	sl_mull_u32 s62, s7, 0x4
	ml_slb_load_b32x1  v6, v1, s73, #768, null
	ml_or_b32 v47, v0, v7
	ml_or_b32 v45, v2, v3
	ml_xor_b32 v43, v44, 0x40
	ml_mov_b32 v51, 0xff800000
	ml_mov_b32 v23, 0x0
	ml_mov_b32 v25, 0x0
	ml_mov_b32 v21, 0x0
	ml_mov_b32 v27, 0x0
	ml_mov_b32 v29, 0x0
	ml_mov_b32 v30, 0x0
	ml_mov_b32 v31, 0x0
	ml_mov_b32 v32, 0x0
	ml_mov_b32 v33, 0x0
	ml_mov_b32 v34, 0x0
	ml_mov_b32 v35, 0x0
	ml_mov_b32 v36, 0x0
	ml_mov_b32 v37, 0x0
	ml_mov_b32 v38, 0x0
	ml_mov_b32 v39, 0x0
	ml_mov_b32 v40, 0x0
	ml_mov_b32 v41, 0x0
	ml_mov_b32 v42, 0x0
	sl_cbr_wcrz BB0_4, wcr
; %bb.2:                                ; %.lr.ph
	.loc	1 0 16 is_stmt 0                ; biv150_int8_pv.py:0:16
	ml_mov_v2s_b32 s1, v152, 0x4
	ml_and_b32 v0, tid, 0x4
	ml_cmp_eq_u32 tcr, v0, 0x0
	ml_mov_b32 v0, 0x140
	sl_srl_b32 {s0, wcr}, s1, 0x4
	ml_anyop3_b32 v69, v62, v63, s0, 0xfffffffe
	ml_xor_b32 v70, v69, 0x10
	ml_xor_b32 v71, v69, 0x20
	ml_xor_b32 v72, v69, 0x30
	ml_csel_b32 v0, 0, v0, tcr
	sl_srl_b32 {s0, wcr}, s1, 0x1
	ml_bfe2_b32 v1, tid, 0x25
	ml_add_i32 v1, s0, v1
	sl_mov_b32 s0, 0x600
	ml_anyop3_b32 v2, s0, v56, v58, 0xfffffff8
	ml_anyop3_b32 v73, v1, v0, v2, 0xfffffffe
	ml_xor_b32 v74, v73, 0x40
	ml_xor_b32 v75, v47, 0x10
	ml_xor_b32 v76, v47, 0x20
	ml_xor_b32 v77, v47, 0x30
	sl_wait lmcnt(7)
	ml_mov_b32 v15, v14
	sl_wait lmcnt(3)
	ml_mov_b32 v19, v18
	ml_mov_b32 v13, v12
	sl_wait lmcnt(2)
	ml_mov_b32 v17, v16
	ml_mov_b32 v9, v8
	sl_wait lmcnt(1)
	ml_mov_b32 v11, v10
	ml_mov_b32 v5, v4
	sl_wait lmcnt(0)
	ml_mov_b32 v7, v6
	sl_mov_b32 s31, 0xffffffff
	ml_mov_b32 v78, 0x99
	ml_bfe2_b32 v0, tid, 0x24
	ml_anyop3_b32 v79, v45, v46, v0, 0xfffffffe
	ml_and_b32 v0, tid, 0x10
	ml_or_b32 v80, v45, v0
	sl_mov_b32 s76, 0x504
	sl_mov_b32 s77, 0x60504
	sl_mov_b32 s80, 0x1000
	sl_mov_b32 s81, 0x2000
	sl_mov_b32 s84, 0x2800
	sl_mov_b32 s85, 0x800
	sl_mov_b32 s87, 0xc00
	sl_mov_b32 s88, 0x1400
	sl_mov_b32 s89, 0x1800
	sl_mov_b32 s91, 0x1c00
	sl_mov_b32 s92, 0x2c00
	sl_mov_b32 s93, 0x2400
	ml_mov_b32 v81, 0x0
	ml_mov_b32 v82, 0x0
	ml_mov_b32 v83, 0x0
	ml_mov_b32 v84, 0x0
	ml_mov_b32 v85, 0x0
	ml_mov_b32 v86, 0x0
	ml_mov_b32 v87, 0x0
	ml_mov_b32 v88, 0x0
	ml_mov_b32 v89, 0x0
	ml_mov_b32 v90, 0x0
	ml_mov_b32 v91, 0x0
	ml_mov_b32 v92, 0x0
	ml_mov_b32 v93, 0x0
	ml_mov_b32 v94, 0x0
	ml_mov_b32 v95, 0x0
	ml_mov_b32 v96, 0x0
BB0_3:                                  ; =>This Inner Loop Header: Depth=1
	.loc	1 109 54 is_stmt 1              ; biv150_int8_pv.py:109:54
	sl_sra_b32 {s0, wcr}, s72, 0x4
	.loc	1 109 42 is_stmt 0              ; biv150_int8_pv.py:109:42
	sl_sra_b32 {s1, wcr}, s0, 0x1f
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	sl_add_i64 s[28:29], s[2:3], s[0:1]
	.loc	1 109 24                        ; biv150_int8_pv.py:109:24
	ml_lsa_load_dwordx2 v[0:1], s[28:31], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 1              ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[52:53], wcr}, s[4:5], 0x1
	sl_shl_b64 {s[68:69], wcr}, s[40:41], 0x1
	sl_shl_b64 {s[48:49], wcr}, s[26:27], 0x1
	sl_shl_b64 {tcr, wcr}, s[32:33], 0x1
	.loc	1 124 20 is_stmt 0              ; biv150_int8_pv.py:124:20
	sl_mov_b64 s[50:51], s[54:55]
	ml_mov_b32 v109, v51
	ml_mov_b32 v110, v48
	.loc	1 109 24 is_stmt 1              ; biv150_int8_pv.py:109:24
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s28, v0, 0x0
	.loc	1 110 24                        ; biv150_int8_pv.py:110:24
	ml_mov_v2s_b32 s0, v1, 0x0
	.loc	1 109 24                        ; biv150_int8_pv.py:109:24
	sl_sra_b32 {s29, wcr}, s28, 0x1f
	.loc	1 110 24                        ; biv150_int8_pv.py:110:24
	sl_sra_b32 {s1, wcr}, s0, 0x1f
	.loc	1 113 28                        ; biv150_int8_pv.py:113:28
	sl_mul_u64_u32 s[8:9], s36, s28
	sl_mull_u32 s78, s37, s28
	sl_mull_u32 s79, s36, s29
	sl_add_i32 s9, s9, s79
	sl_add_i32 s9, s9, s78
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[8:9], wcr}, s[8:9], 0x1
	sl_add_i64 s[8:9], s[20:21], s[8:9]
	sl_add_i64 s[48:49], s[8:9], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20 is_stmt 0              ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v0, s[48:51], noreg, noreg, #0, ca
	.loc	1 113 28 is_stmt 1              ; biv150_int8_pv.py:113:28
	sl_mul_u64_u32 s[78:79], s36, s0
	sl_mull_u32 s48, s37, s0
	sl_mull_u32 s49, s36, s1
	sl_add_i32 s49, s79, s49
	sl_add_i32 s79, s49, s48
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[48:49], s[8:9], tcr
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20 is_stmt 0              ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v1, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[82:83], 0x1
	sl_add_i64 s[48:49], s[8:9], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v2, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[56:57], 0x1
	sl_add_i64 s[48:49], s[8:9], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v3, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[60:61], 0x1
	sl_add_i64 s[48:49], s[8:9], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v97, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[64:65], 0x1
	sl_add_i64 s[48:49], s[8:9], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v99, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[70:71], 0x1
	sl_add_i64 s[48:49], s[8:9], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	sl_shl_b64 {s[50:51], wcr}, s[78:79], 0x1
	sl_add_i64 s[78:79], s[20:21], s[50:51]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	sl_mov_b64 s[50:51], s[54:55]
	ml_lsa_blkload_x1 v100, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[48:49], s[78:79], s[52:53]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	sl_add_i64 s[8:9], s[8:9], s[52:53]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v98, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[34:35], 0x1
	sl_add_i64 s[48:49], s[78:79], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v101, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[44:45], 0x1
	sl_add_i64 s[48:49], s[78:79], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v102, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[46:47], 0x1
	sl_add_i64 s[48:49], s[78:79], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v103, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[74:75], 0x1
	sl_add_i64 s[48:49], s[78:79], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v104, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[58:59], 0x1
	sl_add_i64 s[48:49], s[78:79], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v105, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[48:49], wcr}, s[66:67], 0x1
	sl_add_i64 s[48:49], s[78:79], s[48:49]
	sl_add_i64 s[48:49], s[48:49], s[68:69]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v106, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[52:53], s[8:9], s[68:69]
	sl_shl_b64 {s[8:9], wcr}, s[38:39], 0x1
	sl_add_i64 s[8:9], s[78:79], s[8:9]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v51, s[52:55], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[48:49], s[8:9], s[68:69]
	.loc	1 119 28 is_stmt 1              ; biv150_int8_pv.py:119:28
	sl_mul_u64_u32 s[8:9], s42, s28
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v107, s[48:51], noreg, noreg, #0, ca
	.loc	1 119 28                        ; biv150_int8_pv.py:119:28
	sl_mull_u32 s48, s42, s29
	sl_add_i32 s9, s9, s48
	sl_mull_u32 s48, s43, s28
	sl_add_i32 s9, s9, s48
	sl_mull_u32 s50, s42, s1
	sl_mul_u64_u32 s[48:49], s42, s0
	sl_add_i32 s49, s49, s50
	sl_mull_u32 s50, s43, s0
	sl_add_i32 s49, s49, s50
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	sl_wait vmcnt(0)
	sl_barrier 
	ml_slb_store_b32x1  v51, v69, noreg, #0, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	sl_add_i64 s[8:9], s[22:23], s[8:9]
	sl_add_i64 s[8:9], s[18:19], s[8:9]
	ml_mov_b32 v48, s9
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v0, v69, noreg, #8, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addo_u32 {v0, tcr}, s8, v26
	.loc	1 126 48                        ; biv150_int8_pv.py:126:48
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0xe
	.loc	1 126 30 is_stmt 0              ; biv150_int8_pv.py:126:30
	sl_add_i64 s[0:1], s[24:25], s[0:1]
	.loc	1 124 20 is_stmt 1              ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v98, v69, s80, #0, null
	ml_slb_store_b32x1  v101, v69, s80, #8, null
	ml_slb_store_b32x1  v1, v70, noreg, #256, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, v48, v61, tcr
	ml_addo_u32 {v0, tcr}, v49, v0
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v2, v70, noreg, #264, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s8, v24
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v102, v70, s80, #256, null
	ml_slb_store_b32x1  v103, v70, s80, #264, null
	ml_slb_store_b32x1  v3, v71, noreg, #512, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, v48, v60, tcr
	ml_addo_u32 {v2, tcr}, v49, v2
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v97, v71, noreg, #520, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, 0, v3, tcr
	ml_addo_u32 {v51, tcr}, s8, v22
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v104, v71, s80, #512, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v98, v48, v59, tcr
	ml_addo_u32 {v97, tcr}, v49, v51
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v105, v71, s80, #520, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v98, 0, v98, tcr
	ml_addo_u32 {v51, tcr}, s8, v20
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v99, v72, noreg, #768, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	sl_add_i64 s[8:9], s[22:23], s[48:49]
	sl_add_i64 s[8:9], s[18:19], s[8:9]
	ml_addc_i32 v48, v48, v57, tcr
	ml_addo_u32 {v99, tcr}, v49, v51
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v100, v72, noreg, #776, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_mov_b32 v51, s9
	ml_addc_i32 v100, 0, v48, tcr
	ml_addo_u32 {v48, tcr}, s8, v26
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v106, v72, s80, #768, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v102, v51, v61, tcr
	ml_addo_u32 {v101, tcr}, v49, v48
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x1  v107, v72, s80, #776, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v102, 0, v102, tcr
	ml_addo_u32 {v48, tcr}, s8, v24
	.loc	1 125 20 is_stmt 0              ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v103, v[0:1], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, v51, v60, tcr
	ml_addo_u32 {v0, tcr}, v49, v48
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v48, v[2:3], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s8, v22
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v97, v[97:98], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, v51, v59, tcr
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v98, v[99:100], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addo_u32 {v2, tcr}, v49, v2
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v99, v[101:102], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, 0, v3, tcr
	ml_addo_u32 {v100, tcr}, s8, v20
	.loc	1 126 48 is_stmt 1              ; biv150_int8_pv.py:126:48
	sl_shl_b64 {s[8:9], wcr}, s[28:29], 0xe
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v101, v[0:1], kop=0
	.loc	1 126 30                        ; biv150_int8_pv.py:126:30
	sl_add_i64 s[8:9], s[24:25], s[8:9]
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, v51, v57, tcr
	ml_addo_u32 {v0, tcr}, v49, v100
	.loc	1 125 20 is_stmt 0              ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v2, v[2:3], kop=0
	.loc	1 126 30 is_stmt 1              ; biv150_int8_pv.py:126:30
	sl_add_i64 s[52:53], s[8:9], s[62:63]
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, 0, v1, tcr
	.loc	1 125 20 is_stmt 0              ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v0, v[0:1], kop=0
	sl_wait vmcnt(7)
	ml_srl_b32 v1, v103, 0x8
	ml_slb_store_b8  v103, v73, s81, #0, null
	ml_slb_store_b8  v1, v73, s81, #2, null
	ml_srl_b32 v1, v103, 0x10
	ml_slb_store_b8  v1, v73, s81, #4, null
	ml_srl_b32 v1, v103, 0x18
	ml_slb_store_b8  v1, v73, s81, #6, null
	sl_wait vmcnt(5)
	ml_srl_b32 v1, v97, 0x8
	ml_slb_store_b8  v97, v73, s81, #128, null
	ml_slb_store_b8  v1, v73, s81, #130, null
	ml_srl_b32 v1, v97, 0x10
	ml_slb_store_b8  v1, v73, s81, #132, null
	ml_srl_b32 v1, v97, 0x18
	ml_slb_store_b8  v1, v73, s81, #134, null
	sl_wait vmcnt(3)
	ml_srl_b32 v1, v99, 0x8
	ml_slb_store_b8  v99, v73, s84, #0, null
	ml_slb_store_b8  v1, v73, s84, #2, null
	ml_srl_b32 v1, v99, 0x10
	ml_slb_store_b8  v1, v73, s84, #4, null
	ml_srl_b32 v1, v99, 0x18
	ml_slb_store_b8  v1, v73, s84, #6, null
	sl_wait vmcnt(1)
	ml_srl_b32 v1, v2, 0x8
	ml_slb_store_b8  v2, v73, s84, #128, null
	ml_slb_store_b8  v1, v73, s84, #130, null
	ml_srl_b32 v1, v2, 0x10
	ml_slb_store_b8  v1, v73, s84, #132, null
	ml_srl_b32 v1, v2, 0x18
	ml_slb_store_b8  v1, v73, s84, #134, null
	ml_srl_b32 v1, v48, 0x8
	ml_slb_store_b8  v48, v74, s81, #0, null
	ml_slb_store_b8  v1, v74, s81, #2, null
	ml_srl_b32 v1, v48, 0x10
	ml_slb_store_b8  v1, v74, s81, #4, null
	ml_srl_b32 v1, v48, 0x18
	ml_slb_store_b8  v1, v74, s81, #6, null
	ml_srl_b32 v1, v98, 0x8
	ml_slb_store_b8  v98, v74, s81, #128, null
	ml_slb_store_b8  v1, v74, s81, #130, null
	ml_srl_b32 v1, v98, 0x10
	ml_slb_store_b8  v1, v74, s81, #132, null
	ml_srl_b32 v1, v98, 0x18
	ml_slb_store_b8  v1, v74, s81, #134, null
	ml_srl_b32 v1, v101, 0x8
	ml_slb_store_b8  v101, v74, s84, #0, null
	ml_slb_store_b8  v1, v74, s84, #2, null
	ml_srl_b32 v1, v101, 0x10
	ml_slb_store_b8  v1, v74, s84, #4, null
	ml_srl_b32 v1, v101, 0x18
	ml_slb_store_b8  v1, v74, s84, #6, null
	sl_wait vmcnt(0)
	ml_srl_b32 v1, v0, 0x8
	ml_slb_store_b8  v0, v74, s84, #128, null
	.loc	1 126 30 is_stmt 1              ; biv150_int8_pv.py:126:30
	ml_lsa_load_dword v111, s[52:55], unsigned v52, noreg, #0, ca|mie
	sl_add_i64 s[52:53], s[0:1], s[62:63]
	ml_lsa_load_dword v112, s[52:55], unsigned v52, noreg, #0, ca|mie
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_slb_store_b8  v1, v74, s84, #130, null
	ml_srl_b32 v1, v0, 0x10
	ml_srl_b32 v0, v0, 0x18
	ml_slb_store_b8  v1, v74, s84, #132, null
	ml_slb_store_b8  v0, v74, s84, #134, null
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	ml_slb_load_b32x1  v101, v47, noreg, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	ml_mov_b32 v0, 0x0
	ml_mov_b32 v1, v64
	ml_mov_b32 v2, v64
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v102, v75, noreg, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	ml_mov_b32 v3, v64
.Ltmp3:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:134:81 ]
	sl_reg_read s0, hwreg(HW_REG_MODE)
.Ltmp4:
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v47, s80, #0, null
.Ltmp5:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:134:81 ]
	sl_or_b32 {s1, wcr}, s0, 0x3
.Ltmp6:
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v106, v75, s80, #0, null
	ml_slb_load_b32x1  v107, v76, noreg, #0, null
	ml_slb_load_b32x1  v108, v77, noreg, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(4)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[14:15], v[101:102], v[0:3]
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[14:15], v[105:106], v[0:3]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v76, s80, #0, null
	ml_slb_load_b32x1  v106, v77, s80, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[18:19], v[107:108], v[97:100]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v107, v47, s73, #0, null
	ml_slb_load_b32x1  v108, v75, s73, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[18:19], v[105:106], v[101:104]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v47, s88, #0, null
	ml_slb_load_b32x1  v106, v75, s88, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[12:13], v[107:108], v[97:100]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v107, v76, s73, #0, null
	ml_slb_load_b32x1  v108, v77, s73, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[12:13], v[105:106], v[101:104]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v76, s88, #0, null
	ml_slb_load_b32x1  v106, v77, s88, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[16:17], v[107:108], v[97:100]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v107, v47, s85, #0, null
	ml_slb_load_b32x1  v108, v75, s85, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[16:17], v[105:106], v[101:104]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v47, s89, #0, null
	ml_slb_load_b32x1  v106, v75, s89, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[8:9], v[107:108], v[97:100]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v107, v76, s85, #0, null
	ml_slb_load_b32x1  v108, v77, s85, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[8:9], v[105:106], v[101:104]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v76, s89, #0, null
	ml_slb_load_b32x1  v106, v77, s89, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[10:11], v[107:108], v[97:100]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v107, v47, s87, #0, null
	ml_slb_load_b32x1  v108, v75, s87, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[10:11], v[105:106], v[101:104]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v47, s91, #0, null
	ml_slb_load_b32x1  v106, v75, s91, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[4:5], v[107:108], v[97:100]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v107, v76, s87, #0, null
	ml_slb_load_b32x1  v108, v77, s87, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[4:5], v[105:106], v[101:104]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v105, v76, s91, #0, null
	ml_slb_load_b32x1  v106, v77, s91, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[97:100], v[6:7], v[107:108], v[97:100]
	.loc	1 129 32 is_stmt 0              ; biv150_int8_pv.py:129:32
	ml_mul_f32 v51, s30, v97
	ml_mul_f32 v98, s30, v98
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[101:104], v[6:7], v[105:106], v[101:104]
	.loc	1 129 32                        ; biv150_int8_pv.py:129:32
	ml_mul_f32 v97, s30, v101
.Ltmp7:
	.loc	2 192 27 is_stmt 1              ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	ml_max_f32 v48, v51, v97
.Ltmp8:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v99, v48, v65
.Ltmp9:
	.loc	1 129 32                        ; biv150_int8_pv.py:129:32
	ml_mul_f32 v100, s30, v102
.Ltmp10:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	ml_max_f32 v101, v98, v100
.Ltmp11:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v102, v101, v65
.Ltmp12:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v48, v48, v99
.Ltmp13:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v99, v48, v66
.Ltmp14:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v101, v101, v102
.Ltmp15:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v102, v101, v66
.Ltmp16:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v48, v48, v99
.Ltmp17:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v99, v48, v67
.Ltmp18:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v101, v101, v102
.Ltmp19:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v102, v101, v67
.Ltmp20:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v48, v48, v99
.Ltmp21:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v99, v48, v68
.Ltmp22:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v101, v101, v102
.Ltmp23:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v102, v101, v68
.Ltmp24:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v48, v48, v99
.Ltmp25:
	.loc	1 130 42                        ; biv150_int8_pv.py:130:42
	ml_max_f32 v48, v110, v48
	.loc	1 131 44                        ; biv150_int8_pv.py:131:44
	ml_sub_f32 v51, v51, v48
	.loc	1 132 45                        ; biv150_int8_pv.py:132:45
	ml_sub_f32 v110, v110, v48
	.loc	1 131 35                        ; biv150_int8_pv.py:131:35
	ml_exp_f32 v99, v51
	.loc	1 131 44 is_stmt 0              ; biv150_int8_pv.py:131:44
	ml_sub_f32 v51, v97, v48
.Ltmp26:
	.loc	2 192 27 is_stmt 1              ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(0)
	ml_max_f32 v97, v101, v102
.Ltmp27:
	.loc	1 131 35                        ; biv150_int8_pv.py:131:35
	ml_exp_f32 v101, v51
	.loc	1 130 42                        ; biv150_int8_pv.py:130:42
	ml_max_f32 v51, v109, v97
	.loc	1 131 44                        ; biv150_int8_pv.py:131:44
	ml_sub_f32 v97, v98, v51
	ml_sub_f32 v98, v100, v51
	.loc	1 131 35 is_stmt 0              ; biv150_int8_pv.py:131:35
	ml_exp_f32 v97, v97
	.loc	1 132 45 is_stmt 1              ; biv150_int8_pv.py:132:45
	ml_sub_f32 v109, v109, v51
.Ltmp28:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	ml_add_f32 v100, v99, v101
.Ltmp29:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v102, v100, v65
.Ltmp30:
	.loc	1 131 35                        ; biv150_int8_pv.py:131:35
	ml_exp_f32 v98, v98
.Ltmp31:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v99, v111, v99
	ml_mul_f32 v101, v112, v101
.Ltmp32:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	ml_max_f32 v103, v99, v101
.Ltmp33:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v104, v103, v65
.Ltmp34:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v105, v111, v97
	ml_mul_f32 v106, v112, v98
.Ltmp35:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	ml_max_f32 v107, v105, v106
.Ltmp36:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v108, v107, v65
.Ltmp37:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	ml_add_f32 v97, v97, v98
.Ltmp38:
	.loc	1 132 31                        ; biv150_int8_pv.py:132:31
	ml_exp_f32 v129, v110
.Ltmp39:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v98, v97, v65
.Ltmp40:
	.loc	1 132 31                        ; biv150_int8_pv.py:132:31
	ml_exp_f32 v130, v109
.Ltmp41:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v100, v100, v102
.Ltmp42:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v102, v100, v66
.Ltmp43:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v103, v103, v104
.Ltmp44:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v104, v103, v66
.Ltmp45:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v107, v107, v108
.Ltmp46:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v108, v107, v66
.Ltmp47:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v97, v97, v98
.Ltmp48:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v98, v97, v66
.Ltmp49:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v100, v100, v102
.Ltmp50:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v102, v100, v67
.Ltmp51:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v103, v103, v104
.Ltmp52:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v104, v103, v67
.Ltmp53:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v107, v107, v108
.Ltmp54:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v108, v107, v67
.Ltmp55:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v97, v97, v98
.Ltmp56:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v98, v97, v67
.Ltmp57:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v100, v100, v102
.Ltmp58:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v102, v100, v68
.Ltmp59:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v103, v103, v104
.Ltmp60:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v104, v103, v68
.Ltmp61:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v107, v107, v108
.Ltmp62:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v108, v107, v68
.Ltmp63:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v97, v97, v98
.Ltmp64:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v98, v97, v68
.Ltmp65:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v100, v100, v102
.Ltmp66:
	.loc	1 133 46                        ; biv150_int8_pv.py:133:46
	ml_fma_f32 v23, v23, v129, v100
.Ltmp67:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(2)
	ml_max_f32 v102, v103, v104
.Ltmp68:
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v102, v102, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v131, v102, 0x3c010204
.Ltmp69:
	.loc	2 192 27 is_stmt 1              ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v102, v107, v108
.Ltmp70:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_rcp_f32 v103, v131
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v102, v102, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v132, v102, 0x3c010204
.Ltmp71:
	.loc	2 285 15 is_stmt 1              ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v97, v97, v98
.Ltmp72:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_rcp_f32 v98, v132
.Ltmp73:
	.loc	1 133 46                        ; biv150_int8_pv.py:133:46
	ml_fma_f32 v25, v25, v130, v97
.Ltmp74:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_xor_b32 v97, v131, 0x80000000
	ml_xor_b32 v100, v132, 0x80000000
	ml_mul_f32 v102, v99, v103
	ml_mul_f32 v107, v101, v103
	ml_mul_f32 v104, v105, v98
	ml_fma_f32 v99, v97, v102, v99
	ml_fma_f32 v97, v97, v107, v101
	ml_mul_f32 v101, v106, v98
	ml_fma_f32 v105, v100, v104, v105
	ml_fma_f32 v100, v100, v101, v106
	ml_fma_f32 v99, v99, v103, v102
	ml_fma_f32 v97, v97, v103, v107
	ml_fma_f32 v103, v105, v98, v104
	ml_fma_f32 v98, v100, v98, v101
	ml_cmp_class_f32 tcr, v102, v78
	ml_csel_b32 v99, v102, v99, tcr
	.loc	1 17 72 is_stmt 0               ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v99, v99, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_cmp_class_f32 tcr, v104, v78
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v99, v99
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_csel_b32 v100, v104, v103, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v100, v100, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_cmp_class_f32 tcr, v107, v78
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v100, v100
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_csel_b32 v97, v107, v97, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v97, v97, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_cmp_class_f32 tcr, v101, v78
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v97, v97
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_csel_b32 v98, v101, v98, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v98, v98, 0x3f000000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v99, v99, 0x0
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v98, v98
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v100, v100, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:134:81 ]
	ml_min_f32 v99, v99, 0x42fe0000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v97, v97, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:134:81 ]
	ml_min_f32 v100, v100, 0x42fe0000
	ml_min_f32 v97, v97, 0x42fe0000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v98, v98, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:134:81 ]
	ml_min_f32 v98, v98, 0x42fe0000
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:134:81 ]
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v99, v99
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v100, v100
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v97, v97
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v98, v98
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_barrier 
	ml_slb_store_b8  v99, v79, noreg, #0, null
	ml_slb_store_b8  v100, v79, noreg, #16, null
	ml_slb_store_b8  v97, v79, noreg, #128, null
	ml_slb_store_b8  v98, v79, noreg, #144, null
	sl_wait lmcnt(0)
	sl_barrier 
	.loc	1 19 25 is_stmt 1               ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v97, v80, noreg, #128, null
.Ltmp75:
	.loc	1 136 20                        ; biv150_int8_pv.py:136:20
	sl_add_i32 s72, s72, 0x20
	.loc	1 107 21                        ; biv150_int8_pv.py:107:21
	sl_cmp_lt_i32 wcr, s72, s86
.Ltmp76:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v98, v80, noreg, #129, null
	ml_slb_load_b8  v99, v80, noreg, #136, null
	ml_slb_load_b8  v100, v80, noreg, #137, null
	ml_slb_load_b8  v101, v80, noreg, #0, null
	ml_slb_load_b8  v102, v80, noreg, #1, null
	ml_slb_load_b8  v103, v80, noreg, #8, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v98, v97, 4
	ml_slb_load_b8  v104, v80, noreg, #9, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v99, v97, s76
	ml_slb_load_b8  v105, v44, s84, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v126, v100, v97, s77
	ml_slb_load_b8  v106, v44, s84, #1, null
	ml_slb_load_b8  v107, v44, s84, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v102, v101, 4
	ml_slb_load_b8  v108, v44, s84, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v103, v97, s76
	ml_slb_load_b8  v109, v44, s81, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v125, v104, v97, s77
	ml_slb_load_b8  v110, v44, s81, #1, null
	ml_slb_load_b8  v111, v44, s81, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v106, v105, 4
	ml_slb_load_b8  v112, v44, s81, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v107, v97, s76
	ml_slb_load_b8  v113, v43, s84, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v102, v108, v97, s77
	ml_slb_load_b8  v114, v43, s84, #257, null
	ml_slb_load_b8  v115, v43, s84, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v110, v109, 4
	ml_slb_load_b8  v116, v43, s84, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v111, v97, s76
	ml_slb_load_b8  v117, v43, s81, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v101, v112, v97, s77
	ml_slb_load_b8  v118, v43, s81, #257, null
	ml_slb_load_b8  v119, v43, s81, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v114, v113, 4
	ml_slb_load_b8  v120, v43, s81, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v115, v97, s76
	ml_slb_load_b8  v121, v44, s84, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v106, v116, v97, s77
	ml_slb_load_b8  v122, v44, s84, #513, null
	ml_slb_load_b8  v123, v44, s84, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v118, v117, 4
	ml_slb_load_b8  v124, v44, s84, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v119, v97, s76
	ml_slb_load_b8  v127, v44, s81, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v105, v120, v97, s77
	ml_slb_load_b8  v128, v44, s81, #513, null
	ml_slb_load_b8  v133, v44, s81, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v122, v121, 4
	ml_slb_load_b8  v134, v44, s81, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v97, v123, v97, s76
	ml_slb_load_b8  v135, v43, s84, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v110, v124, v97, s77
	ml_matrix_mad_i32_i8_m16n16k32 v[97:100], v[125:126], v[101:102], v[0:3]
	ml_slb_load_b8  v136, v43, s84, #769, null
	ml_slb_load_b8  v137, v43, s84, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v101, v128, v127, 4
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v97, v97
	ml_cvt_f32_i32  v98, v98
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v138, v43, s84, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v101, v133, v101, s76
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v99, v99
	ml_cvt_f32_i32  v100, v100
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v139, v43, s81, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v109, v134, v101, s77
	ml_matrix_mad_i32_i8_m16n16k32 v[101:104], v[125:126], v[105:106], v[0:3]
	ml_slb_load_b8  v140, v43, s81, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[105:108], v[125:126], v[109:110], v[0:3]
	ml_slb_load_b8  v141, v43, s81, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v109, v136, v135, 4
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v101, v101
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v142, v43, s81, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v109, v137, v109, s76
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v102, v102
	ml_cvt_f32_i32  v103, v103
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v143, v44, s92, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v114, v138, v109, s77
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v104, v104
	ml_cvt_f32_i32  v105, v105
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v144, v44, s92, #1, null
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v106, v106
	ml_cvt_f32_i32  v107, v107
	ml_cvt_f32_i32  v108, v108
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v145, v44, s92, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v109, v140, v139, 4
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v97, v131, v97
	ml_mul_f32 v99, v131, v99
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v146, v44, s92, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v109, v141, v109, s76
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v101, v131, v101
	ml_mul_f32 v103, v131, v103
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v115, v44, s93, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v113, v142, v109, s77
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v105, v131, v105
	ml_mul_f32 v107, v131, v107
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v116, v44, s93, #1, null
	ml_matrix_mad_i32_i8_m16n16k32 v[109:112], v[125:126], v[113:114], v[0:3]
	ml_slb_load_b8  v147, v44, s93, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v113, v144, v143, 4
.Ltmp77:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v81, v81, v129, v97
	ml_fma_f32 v21, v21, v129, v99
.Ltmp78:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v148, v44, s93, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v113, v145, v113, s76
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v109, v109
	ml_cvt_f32_i32  v110, v110
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v119, v43, s92, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v118, v146, v113, s77
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v111, v111
	ml_cvt_f32_i32  v112, v112
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v120, v43, s92, #257, null
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v109, v131, v109
	ml_mul_f32 v111, v131, v111
.Ltmp79:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v83, v83, v129, v101
.Ltmp80:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v149, v43, s92, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v113, v116, v115, 4
.Ltmp81:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v29, v29, v129, v103
	ml_fma_f32 v85, v85, v129, v105
.Ltmp82:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v150, v43, s92, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v113, v147, v113, s76
.Ltmp83:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v31, v31, v129, v107
	ml_fma_f32 v87, v87, v129, v109
.Ltmp84:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v121, v43, s93, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v117, v148, v113, s77
.Ltmp85:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v33, v33, v129, v111
.Ltmp86:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v97, v132, v102
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v123, v43, s93, #257, null
	ml_matrix_mad_i32_i8_m16n16k32 v[113:116], v[125:126], v[117:118], v[0:3]
	ml_slb_load_b8  v124, v43, s93, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v117, v120, v119, 4
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v99, v132, v106
	ml_mul_f32 v101, v132, v110
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v151, v43, s93, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v117, v149, v117, s76
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v113, v113
	ml_cvt_f32_i32  v114, v114
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v127, v44, s92, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v122, v150, v117, s77
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v115, v115
	ml_cvt_f32_i32  v116, v116
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v128, v44, s92, #513, null
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v113, v131, v113
	ml_mul_f32 v115, v131, v115
.Ltmp87:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v89, v89, v129, v113
.Ltmp88:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v133, v44, s92, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v117, v123, v121, 4
.Ltmp89:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v35, v35, v129, v115
.Ltmp90:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v102, v132, v112
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v134, v44, s92, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v117, v124, v117, s76
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v103, v132, v114
.Ltmp91:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v84, v84, v130, v97
.Ltmp92:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v135, v44, s93, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v121, v151, v117, s77
.Ltmp93:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v86, v86, v130, v99
	ml_fma_f32 v88, v88, v130, v101
.Ltmp94:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v136, v44, s93, #513, null
	ml_matrix_mad_i32_i8_m16n16k32 v[117:120], v[125:126], v[121:122], v[0:3]
	ml_slb_load_b8  v137, v44, s93, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v121, v128, v127, 4
.Ltmp95:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v34, v34, v130, v102
	ml_fma_f32 v90, v90, v130, v103
.Ltmp96:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v138, v44, s93, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v121, v133, v121, s76
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v117, v117
	ml_cvt_f32_i32  v118, v118
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v139, v43, s92, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v128, v134, v121, s77
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v119, v119
	ml_cvt_f32_i32  v120, v120
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v140, v43, s92, #769, null
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v117, v131, v117
	ml_mul_f32 v119, v131, v119
.Ltmp97:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v91, v91, v129, v117
.Ltmp98:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v141, v43, s92, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v122, v136, v135, 4
.Ltmp99:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v37, v37, v129, v119
.Ltmp100:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v105, v132, v118
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v142, v43, s92, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v121, v137, v122, s76
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v106, v132, v120
.Ltmp101:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v92, v92, v130, v105
.Ltmp102:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v143, v43, s93, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v127, v138, v121, s77
.Ltmp103:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v38, v38, v130, v106
.Ltmp104:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v144, v43, s93, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[121:124], v[125:126], v[127:128], v[0:3]
	ml_slb_load_b8  v133, v43, s93, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v127, v140, v139, 4
	ml_slb_load_b8  v134, v43, s93, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v127, v141, v127, s76
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v121, v121
	ml_cvt_f32_i32  v122, v122
	ml_cvt_f32_i32  v123, v123
	ml_cvt_f32_i32  v124, v124
	.loc	1 20 34 is_stmt 0               ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v121, v131, v121
	ml_mul_f32 v123, v131, v123
.Ltmp105:
	.loc	1 134 55 is_stmt 1              ; biv150_int8_pv.py:134:55
	ml_fma_f32 v93, v93, v129, v121
	ml_fma_f32 v39, v39, v129, v123
.Ltmp106:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v107, v132, v122
.Ltmp107:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v94, v94, v130, v107
.Ltmp108:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	sl_wait lmcnt(2)
	ml_byte_permute_b32 v128, v144, v143, 4
	sl_wait lmcnt(1)
	ml_byte_permute_b32 v133, v133, v128, s76
	ml_byte_permute_b32 v128, v142, v127, s77
	sl_wait lmcnt(0)
	ml_byte_permute_b32 v127, v134, v133, s77
	ml_matrix_mad_i32_i8_m16n16k32 v[0:3], v[125:126], v[127:128], v[0:3]
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v0, v0
	ml_cvt_f32_i32  v1, v1
	ml_cvt_f32_i32  v2, v2
	ml_cvt_f32_i32  v3, v3
	.loc	1 20 34 is_stmt 0               ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v0, v131, v0
	ml_mul_f32 v2, v131, v2
.Ltmp109:
	.loc	1 134 55 is_stmt 1              ; biv150_int8_pv.py:134:55
	ml_fma_f32 v95, v95, v129, v0
	ml_fma_f32 v41, v41, v129, v2
.Ltmp110:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v0, v132, v98
	ml_mul_f32 v2, v132, v100
	ml_mul_f32 v98, v132, v104
	ml_mul_f32 v100, v132, v108
	ml_mul_f32 v104, v132, v116
	ml_mul_f32 v108, v132, v124
	ml_mul_f32 v1, v132, v1
	ml_mul_f32 v3, v132, v3
.Ltmp111:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v82, v82, v130, v0
	ml_fma_f32 v27, v27, v130, v2
	ml_fma_f32 v30, v30, v130, v98
	ml_fma_f32 v32, v32, v130, v100
	ml_fma_f32 v36, v36, v130, v104
	ml_fma_f32 v40, v40, v130, v108
	ml_fma_f32 v96, v96, v130, v1
	ml_fma_f32 v42, v42, v130, v3
	sl_cbr_wcrnz BB0_3, wcr
BB0_4:                                  ; %._crit_edge
	.loc	1 138 20                        ; biv150_int8_pv.py:138:20
	sl_cmp_lt_i32 wcr, s86, s90
	sl_cbr_wcrz BB0_60, wcr
; %bb.5:
	.loc	1 140 56                        ; biv150_int8_pv.py:140:56
	sl_sra_b32 {s0, wcr}, s86, 0x4
	.loc	1 140 42 is_stmt 0              ; biv150_int8_pv.py:140:42
	sl_sra_b32 {s1, wcr}, s0, 0x1f
	sl_mov_b32 s31, 0xffffffff
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	sl_add_i64 s[28:29], s[2:3], s[0:1]
	.loc	1 140 24                        ; biv150_int8_pv.py:140:24
	ml_lsa_load_dword v0, s[28:31], noreg, noreg, #0, ca
	.loc	1 142 40 is_stmt 1              ; biv150_int8_pv.py:142:40
	sl_add_i32 s0, s86, 0x10
	.loc	1 142 52 is_stmt 0              ; biv150_int8_pv.py:142:52
	sl_cmp_lt_i32 wcr, s0, s90
	sl_mov_b32 s0, 0x0
	.loc	1 140 24 is_stmt 1              ; biv150_int8_pv.py:140:24
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s92, v0, 0x0
	sl_cbr_wcrz BB0_7, wcr
; %bb.6:
	.loc	1 141 24                        ; biv150_int8_pv.py:141:24
	ml_lsa_load_dword v0, s[28:31], noreg, noreg, #4, ca
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s0, v0, 0x0
BB0_7:
	.loc	1 140 70                        ; biv150_int8_pv.py:140:70
	sl_sra_b32 {s93, wcr}, s92, 0x1f
	.loc	1 142 70                        ; biv150_int8_pv.py:142:70
	sl_sra_b32 {s1, wcr}, s0, 0x1f
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s94
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_sub_bi_u32 s2, s10, s10, wcr
	.loc	1 146 28 is_stmt 1              ; biv150_int8_pv.py:146:28
	sl_mull_u32 s3, s36, s93
	sl_mul_u64_u32 s[8:9], s36, s92
	sl_add_i32 s3, s9, s3
	sl_mull_u32 s9, s37, s92
	sl_add_i32 s9, s3, s9
	sl_mull_u32 s3, s36, s1
	sl_mul_u64_u32 s[28:29], s36, s0
	sl_add_i32 s3, s29, s3
	sl_mull_u32 s29, s37, s0
	sl_add_i32 s29, s3, s29
	.loc	1 157 36                        ; biv150_int8_pv.py:157:36
	sl_shl_b64 {s[8:9], wcr}, s[8:9], 0x1
	sl_add_i64 s[8:9], s[20:21], s[8:9]
	sl_shl_b64 {s[26:27], wcr}, s[26:27], 0x1
	sl_add_i64 s[26:27], s[8:9], s[26:27]
	sl_shl_b64 {s[40:41], wcr}, s[40:41], 0x1
	sl_add_i64 s[88:89], s[26:27], s[40:41]
	sl_shl_b64 {s[26:27], wcr}, s[32:33], 0x1
	sl_add_i64 s[26:27], s[8:9], s[26:27]
	sl_add_i64 s[84:85], s[26:27], s[40:41]
	sl_shl_b64 {s[26:27], wcr}, s[82:83], 0x1
	sl_add_i64 s[26:27], s[8:9], s[26:27]
	sl_add_i64 s[80:81], s[26:27], s[40:41]
	sl_shl_b64 {s[26:27], wcr}, s[56:57], 0x1
	sl_add_i64 s[26:27], s[8:9], s[26:27]
	sl_add_i64 s[76:77], s[26:27], s[40:41]
	sl_shl_b64 {s[26:27], wcr}, s[60:61], 0x1
	sl_add_i64 s[26:27], s[8:9], s[26:27]
	sl_add_i64 s[72:73], s[26:27], s[40:41]
	sl_shl_b64 {s[26:27], wcr}, s[64:65], 0x1
	sl_add_i64 s[26:27], s[8:9], s[26:27]
	sl_add_i64 s[68:69], s[26:27], s[40:41]
	sl_shl_b64 {s[26:27], wcr}, s[70:71], 0x1
	sl_add_i64 s[26:27], s[8:9], s[26:27]
	sl_add_i64 s[64:65], s[26:27], s[40:41]
	sl_shl_b64 {s[26:27], wcr}, s[28:29], 0x1
	sl_add_i64 s[20:21], s[20:21], s[26:27]
	sl_shl_b64 {s[26:27], wcr}, s[4:5], 0x1
	sl_add_i64 s[4:5], s[20:21], s[26:27]
	sl_add_i64 s[60:61], s[4:5], s[40:41]
	sl_shl_b64 {s[4:5], wcr}, s[34:35], 0x1
	sl_add_i64 s[4:5], s[20:21], s[4:5]
	sl_add_i64 s[56:57], s[4:5], s[40:41]
	sl_shl_b64 {s[4:5], wcr}, s[44:45], 0x1
	sl_add_i64 s[4:5], s[20:21], s[4:5]
	sl_add_i64 s[52:53], s[4:5], s[40:41]
	sl_shl_b64 {s[4:5], wcr}, s[46:47], 0x1
	sl_add_i64 s[4:5], s[20:21], s[4:5]
	sl_add_i64 s[48:49], s[4:5], s[40:41]
	sl_shl_b64 {s[4:5], wcr}, s[74:75], 0x1
	sl_add_i64 s[4:5], s[20:21], s[4:5]
	sl_add_i64 s[44:45], s[4:5], s[40:41]
	sl_shl_b64 {s[4:5], wcr}, s[58:59], 0x1
	sl_add_i64 s[4:5], s[20:21], s[4:5]
	sl_add_i64 s[36:37], s[4:5], s[40:41]
	sl_shl_b64 {s[4:5], wcr}, s[66:67], 0x1
	sl_add_i64 s[4:5], s[20:21], s[4:5]
	sl_shl_b64 {s[28:29], wcr}, s[38:39], 0x1
	sl_add_i64 s[20:21], s[20:21], s[28:29]
	sl_add_i64 s[4:5], s[4:5], s[40:41]
	sl_add_i64 s[8:9], s[8:9], s[26:27]
	sl_add_i64 s[28:29], s[20:21], s[40:41]
	sl_add_i64 s[32:33], s[8:9], s[40:41]
	.loc	1 157 20 is_stmt 0              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v0, 0x0
	sl_or_b32 {s2, wcr}, s2, 0x0
	ml_mov_b32 v1, 0x0
	sl_cbr_wcrz BB0_9, wcr
; %bb.8:
	sl_mov_b32 s35, 0xfff00004
	ml_lsa_blkload_x1 v1, s[32:35], noreg, noreg, #0, ca
BB0_9:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s6
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_11, wcr
; %bb.10:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s91, 0xfff00004
	ml_lsa_blkload_x1 v0, s[88:91], noreg, noreg, #0, ca
BB0_11:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s54
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v2, 0x0
	ml_mov_b32 v3, 0x0
	sl_cbr_wcrz BB0_13, wcr
; %bb.12:
	sl_mov_b32 s87, 0xfff00004
	ml_lsa_blkload_x1 v3, s[84:87], noreg, noreg, #0, ca
BB0_13:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0xe
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_15, wcr
; %bb.14:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s83, 0xfff00004
	ml_lsa_blkload_x1 v2, s[80:83], noreg, noreg, #0, ca
BB0_15:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0xf
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_mov_b32 v5, 0x0
	ml_mov_b32 v7, 0x0
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_17, wcr
; %bb.16:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s79, 0xfff00004
	ml_lsa_blkload_x1 v7, s[76:79], noreg, noreg, #0, ca
BB0_17:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0x10
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_19, wcr
; %bb.18:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s75, 0xfff00004
	ml_lsa_blkload_x1 v5, s[72:75], noreg, noreg, #0, ca
BB0_19:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0x11
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_mov_b32 v9, 0x0
	ml_mov_b32 v11, 0x0
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_21, wcr
; %bb.20:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s71, 0xfff00004
	ml_lsa_blkload_x1 v11, s[68:71], noreg, noreg, #0, ca
BB0_21:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0x12
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_23, wcr
; %bb.22:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s67, 0xfff00004
	ml_lsa_blkload_x1 v9, s[64:67], noreg, noreg, #0, ca
BB0_23:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s94
	sl_add_i32 s2, s2, 0x10
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v13, 0x0
	ml_mov_b32 v15, 0x0
	sl_cbr_wcrz BB0_25, wcr
; %bb.24:
	sl_mov_b32 s63, 0xfff00004
	ml_lsa_blkload_x1 v15, s[60:63], noreg, noreg, #0, ca
BB0_25:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0x7
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_27, wcr
; %bb.26:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s59, 0xfff00004
	ml_lsa_blkload_x1 v13, s[56:59], noreg, noreg, #0, ca
BB0_27:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0x8
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_mov_b32 v17, 0x0
	ml_mov_b32 v19, 0x0
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_29, wcr
; %bb.28:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s55, 0xfff00004
	ml_lsa_blkload_x1 v19, s[52:55], noreg, noreg, #0, ca
BB0_29:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0x9
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_31, wcr
; %bb.30:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s51, 0xfff00004
	ml_lsa_blkload_x1 v17, s[48:51], noreg, noreg, #0, ca
BB0_31:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0xa
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_mov_b32 v64, 0x0
	ml_mov_b32 v65, 0x0
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_33, wcr
; %bb.32:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s47, 0xfff00004
	ml_lsa_blkload_x1 v65, s[44:47], noreg, noreg, #0, ca
BB0_33:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0xb
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_35, wcr
; %bb.34:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s39, 0xfff00004
	ml_lsa_blkload_x1 v64, s[36:39], noreg, noreg, #0, ca
BB0_35:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0xc
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_mov_b32 v66, 0x0
	ml_mov_b32 v67, 0x0
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_37, wcr
; %bb.36:
	.loc	1 0 48                          ; biv150_int8_pv.py:0:48
	sl_mov_b32 s2, s7
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s7, 0xfff00004
	ml_lsa_blkload_x1 v67, s[4:7], noreg, noreg, #0, ca
	sl_mov_b32 s7, s2
BB0_37:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_mov_v2s_b32 s2, v152, 0xd
	sl_add_i32 s2, s86, s2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s90
	sl_cbr_wcrz BB0_39, wcr
; %bb.38:
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s31, 0xfff00004
	ml_lsa_blkload_x1 v66, s[28:31], noreg, noreg, #0, ca
BB0_39:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v68, s86, v50
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v68
	.loc	1 152 28 is_stmt 1              ; biv150_int8_pv.py:152:28
	sl_mull_u32 s4, s42, s93
	sl_mul_u64_u32 s[2:3], s42, s92
	sl_add_i32 s3, s3, s4
	sl_mull_u32 s4, s43, s92
	sl_add_i32 s3, s3, s4
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	ml_mov_v2s_b32 s4, v152, 0x4
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	sl_add_i64 s[2:3], s[22:23], s[2:3]
	sl_add_i64 s[20:21], s[18:19], s[2:3]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_srl_b32 {s4, wcr}, s4, 0x4
	ml_anyop3_b32 v62, v62, v63, s4, 0xfffffffe
	ml_slb_store_b32x1  v1, v62, noreg, #0, null
	sl_mov_b32 s4, 0x1000
	ml_mov_b32 v1, 0x0
	ml_slb_store_b32x1  v0, v62, noreg, #8, null
	ml_xor_b32 v0, v62, 0x10
	ml_slb_store_b32x1  v15, v62, s4, #0, null
	ml_slb_store_b32x1  v13, v62, s4, #8, null
	ml_slb_store_b32x1  v3, v0, noreg, #256, null
	ml_slb_store_b32x1  v2, v0, noreg, #264, null
	ml_xor_b32 v2, v62, 0x30
	ml_slb_store_b32x1  v19, v0, s4, #256, null
	ml_slb_store_b32x1  v17, v0, s4, #264, null
	ml_xor_b32 v0, v62, 0x20
	ml_slb_store_b32x1  v7, v0, noreg, #512, null
	ml_slb_store_b32x1  v5, v0, noreg, #520, null
	ml_slb_store_b32x1  v65, v0, s4, #512, null
	ml_slb_store_b32x1  v64, v0, s4, #520, null
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_mov_b32 v0, 0x0
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x1  v11, v2, noreg, #768, null
	ml_slb_store_b32x1  v9, v2, noreg, #776, null
	ml_slb_store_b32x1  v67, v2, s4, #768, null
	ml_slb_store_b32x1  v66, v2, s4, #776, null
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_41
BB0_40:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_addo_u32 {v1, tcr}, s20, v26
	ml_mov_b32 v2, s21
	ml_addc_i32 v2, v2, v61, tcr
	ml_addo_u32 {v1, tcr}, v49, v1
	ml_addc_i32 v2, 0, v2, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v1, v[1:2], kop=0
BB0_41:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v2, s86, v55
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v2
	sl_add_i64 s[20:21], s[18:19], s[2:3]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_43
BB0_42:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v0, tcr}, s20, v24
	ml_mov_b32 v2, s21
	ml_addc_i32 v3, v2, v60, tcr
	ml_addo_u32 {v2, tcr}, v49, v0
	ml_addc_i32 v3, 0, v3, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v0, v[2:3], kop=0
BB0_43:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v2, s86, v54
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v2
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v2, 0x0
	sl_add_i64 s[20:21], s[18:19], s[2:3]
	ml_mov_b32 v3, 0x0
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_45
BB0_44:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v3, tcr}, s20, v22
	ml_mov_b32 v5, s21
	ml_addc_i32 v5, v5, v59, tcr
	ml_addo_u32 {v54, tcr}, v49, v3
	ml_addc_i32 v55, 0, v5, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v3, v[54:55], kop=0
BB0_45:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v5, s86, v53
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v5
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_47
BB0_46:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	sl_add_i64 s[2:3], s[18:19], s[2:3]
	ml_addo_u32 {v2, tcr}, s2, v20
	ml_mov_b32 v5, s3
	ml_addc_i32 v5, v5, v57, tcr
	ml_addo_u32 {v53, tcr}, v49, v2
	ml_addc_i32 v54, 0, v5, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v2, v[53:54], kop=0
BB0_47:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 152 28 is_stmt 1              ; biv150_int8_pv.py:152:28
	sl_mull_u32 s4, s42, s1
	sl_mul_u64_u32 s[2:3], s42, s0
	sl_add_i32 s3, s3, s4
	sl_mull_u32 s4, s43, s0
	sl_add_i32 s3, s3, s4
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	sl_add_i64 s[2:3], s[22:23], s[2:3]
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v5, s86, v50
	ml_add_i32 v5, v5, 0x10
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v5
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v5, 0x0
	sl_add_i64 s[20:21], s[18:19], s[2:3]
	ml_mov_b32 v7, 0x0
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_49
BB0_48:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v7, tcr}, s20, v26
	ml_mov_b32 v9, s21
	ml_addc_i32 v9, v9, v61, tcr
	ml_addo_u32 {v53, tcr}, v49, v7
	ml_addc_i32 v54, 0, v9, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v7, v[53:54], kop=0
BB0_49:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v9, s86, v50
	ml_add_i32 v9, v9, 0x14
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v9
	sl_add_i64 s[20:21], s[18:19], s[2:3]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_51
BB0_50:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v5, tcr}, s20, v24
	ml_mov_b32 v9, s21
	ml_addc_i32 v9, v9, v60, tcr
	ml_addo_u32 {v53, tcr}, v49, v5
	ml_addc_i32 v54, 0, v9, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v5, v[53:54], kop=0
BB0_51:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v9, s86, v50
	ml_add_i32 v9, v9, 0x18
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v9
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v9, 0x0
	sl_add_i64 s[20:21], s[18:19], s[2:3]
	ml_mov_b32 v11, 0x0
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_53
BB0_52:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v11, tcr}, s20, v22
	ml_mov_b32 v13, s21
	ml_addc_i32 v13, v13, v59, tcr
	ml_addo_u32 {v53, tcr}, v49, v11
	ml_addc_i32 v54, 0, v13, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v11, v[53:54], kop=0
BB0_53:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v13, s86, v50
	ml_add_i32 v13, v13, 0x1c
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v13
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[4:5], wcr}, tcr, tmsk
	; mask branch BB0_55
BB0_54:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	sl_add_i64 s[2:3], s[18:19], s[2:3]
	ml_addo_u32 {v9, tcr}, s2, v20
	ml_mov_b32 v13, s3
	ml_addc_i32 v13, v13, v57, tcr
	ml_addo_u32 {v19, tcr}, v49, v9
	ml_addc_i32 v20, 0, v13, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v9, v[19:20], kop=0
BB0_55:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
	.loc	1 84 29 is_stmt 1               ; biv150_int8_pv.py:84:29
	ml_and_b32 v13, tid, 0xf
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v13, s86, v13
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v13
	ml_and_b32 v13, tid, 0x4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_v2s_b32 s2, v152, 0x4
	ml_bfe2_b32 v15, tid, 0x25
	.loc	1 144 48                        ; biv150_int8_pv.py:144:48
	sl_mov_b64 s[4:5], tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_cmp_eq_u32 tcr, v13, 0x0
	ml_mov_b32 v13, 0x140
	ml_csel_b32 v13, 0, v13, tcr
	sl_srl_b32 {s2, wcr}, s2, 0x1
	ml_add_i32 v15, s2, v15
	sl_mov_b32 s2, 0x600
	ml_anyop3_b32 v17, s2, v56, v58, 0xfffffff8
	ml_anyop3_b32 v13, v15, v13, v17, 0xfffffffe
	sl_mov_b32 s2, 0x2000
	sl_wait vmcnt(7)
	ml_slb_store_b8  v1, v13, s2, #0, null
	ml_srl_b32 v15, v1, 0x8
	sl_mov_b32 s3, 0x2800
	ml_mov_b32 v20, 0x0
	ml_slb_store_b8  v15, v13, s2, #2, null
	ml_srl_b32 v15, v1, 0x10
	ml_srl_b32 v1, v1, 0x18
	sl_mov_b32 s63, 0x0
	ml_slb_store_b8  v15, v13, s2, #4, null
	.loc	1 159 48                        ; biv150_int8_pv.py:159:48
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0xe
	sl_add_i64 s[0:1], s[24:25], s[0:1]
	ml_mov_b32 v22, 0x0
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_slb_store_b8  v1, v13, s2, #6, null
	sl_wait vmcnt(5)
	ml_srl_b32 v1, v3, 0x8
	ml_slb_store_b8  v3, v13, s2, #128, null
	ml_slb_store_b8  v1, v13, s2, #130, null
	ml_srl_b32 v1, v3, 0x10
	ml_slb_store_b8  v1, v13, s2, #132, null
	ml_srl_b32 v1, v3, 0x18
	ml_srl_b32 v3, v0, 0x8
	ml_slb_store_b8  v1, v13, s2, #134, null
	sl_wait vmcnt(3)
	ml_srl_b32 v1, v7, 0x8
	ml_slb_store_b8  v7, v13, s3, #0, null
	ml_slb_store_b8  v1, v13, s3, #2, null
	ml_srl_b32 v1, v7, 0x10
	ml_slb_store_b8  v1, v13, s3, #4, null
	ml_srl_b32 v1, v7, 0x18
	ml_slb_store_b8  v1, v13, s3, #6, null
	sl_wait vmcnt(1)
	ml_srl_b32 v1, v11, 0x8
	ml_slb_store_b8  v11, v13, s3, #128, null
	ml_slb_store_b8  v1, v13, s3, #130, null
	ml_srl_b32 v1, v11, 0x10
	ml_slb_store_b8  v1, v13, s3, #132, null
	ml_srl_b32 v1, v11, 0x18
	ml_slb_store_b8  v1, v13, s3, #134, null
	ml_xor_b32 v1, v13, 0x40
	ml_slb_store_b8  v0, v1, s2, #0, null
	ml_slb_store_b8  v3, v1, s2, #2, null
	ml_srl_b32 v3, v0, 0x10
	ml_srl_b32 v0, v0, 0x18
	ml_slb_store_b8  v3, v1, s2, #4, null
	ml_slb_store_b8  v0, v1, s2, #6, null
	ml_srl_b32 v0, v2, 0x8
	ml_slb_store_b8  v2, v1, s2, #128, null
	ml_slb_store_b8  v0, v1, s2, #130, null
	ml_srl_b32 v0, v2, 0x10
	ml_slb_store_b8  v0, v1, s2, #132, null
	ml_srl_b32 v0, v2, 0x18
	ml_slb_store_b8  v0, v1, s2, #134, null
	ml_srl_b32 v0, v5, 0x8
	ml_slb_store_b8  v5, v1, s3, #0, null
	ml_slb_store_b8  v0, v1, s3, #2, null
	ml_srl_b32 v0, v5, 0x10
	ml_slb_store_b8  v0, v1, s3, #4, null
	ml_srl_b32 v0, v5, 0x18
	ml_slb_store_b8  v0, v1, s3, #6, null
	sl_wait vmcnt(0)
	ml_srl_b32 v0, v9, 0x8
	ml_slb_store_b8  v9, v1, s3, #128, null
	ml_slb_store_b8  v0, v1, s3, #130, null
	ml_srl_b32 v0, v9, 0x10
	ml_slb_store_b8  v0, v1, s3, #132, null
	ml_srl_b32 v0, v9, 0x18
	ml_slb_store_b8  v0, v1, s3, #134, null
	.loc	1 159 30                        ; biv150_int8_pv.py:159:30
	sl_and_savetmsk_b64 {s[2:3], wcr}, s[4:5], tmsk
	; mask branch BB0_57
BB0_56:
	.loc	1 159 48 is_stmt 0              ; biv150_int8_pv.py:159:48
	sl_shl_b64 {s[8:9], wcr}, s[92:93], 0xe
	sl_add_i64 s[8:9], s[24:25], s[8:9]
	.loc	1 159 30                        ; biv150_int8_pv.py:159:30
	sl_add_i64 s[20:21], s[8:9], s[62:63]
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_load_dword v22, s[20:23], unsigned v52, noreg, #0, ca|mie
BB0_57:
	.loc	1 0 30                          ; biv150_int8_pv.py:0:30
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 84 29 is_stmt 1               ; biv150_int8_pv.py:84:29
	ml_and_b32 v0, tid, 0xf
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v0, s86, v0
	ml_add_i32 v0, v0, 0x10
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s90, v0
	sl_mov_b64 s[2:3], tcr
	.loc	1 159 30 is_stmt 1              ; biv150_int8_pv.py:159:30
	sl_and_savetmsk_b64 {s[18:19], wcr}, tcr, tmsk
	; mask branch BB0_59
BB0_58:
	sl_add_i64 s[20:21], s[0:1], s[62:63]
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_load_dword v20, s[20:23], unsigned v52, noreg, #0, ca|mie
BB0_59:
	.loc	1 0 30 is_stmt 0                ; biv150_int8_pv.py:0:30
	sl_or_b64 {tmsk, wcr}, tmsk, s[18:19]
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	.loc	1 164 57                        ; biv150_int8_pv.py:164:57
	sl_mov_b64 tcr, s[4:5]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v49, v47, noreg, #0, null
	ml_xor_b32 v5, v47, 0x10
	sl_mov_b32 s0, 0x1000
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v15, v14
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v50, v5, noreg, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v0, 0x0
	ml_mov_b32 v1, 0x0
	ml_mov_b32 v2, 0x0
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v60, v47, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v3, 0x0
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_xor_b32 v24, v47, 0x20
	ml_xor_b32 v26, v47, 0x30
	ml_slb_load_b32x1  v61, v5, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v19, v18
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s1, 0x1400
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v17, v16
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v13, v24, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v9, v8
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v11, v24, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(4)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[14:15], v[49:50], v[0:3]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v49, v24, noreg, #0, null
	ml_slb_load_b32x1  v50, v26, noreg, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(4)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[14:15], v[60:61], v[0:3]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v14, v26, s0, #0, null
	sl_mov_b32 s0, 0x400
	ml_slb_load_b32x1  v15, v5, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[18:19], v[49:50], v[52:55]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v49, v47, s0, #0, null
	ml_slb_load_b32x1  v50, v5, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[18:19], v[13:14], v[56:59]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v14, v47, s1, #0, null
	ml_slb_load_b32x1  v18, v24, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v13, v12
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v19, v26, s0, #0, null
	sl_mov_b32 s0, 0x800
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[12:13], v[49:50], v[52:55]
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[12:13], v[14:15], v[56:59]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v12, v26, s1, #0, null
	sl_mov_b32 s1, 0x1800
	ml_slb_load_b32x1  v13, v47, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[16:17], v[18:19], v[52:55]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v14, v5, s0, #0, null
	ml_slb_load_b32x1  v7, v24, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[16:17], v[11:12], v[56:59]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v11, v47, s1, #0, null
	ml_slb_load_b32x1  v12, v5, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[8:9], v[13:14], v[52:55]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v13, v24, s0, #0, null
	ml_slb_load_b32x1  v14, v26, s0, #0, null
	sl_mov_b32 s0, 0xc00
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[8:9], v[11:12], v[56:59]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v8, v26, s1, #0, null
	sl_mov_b32 s1, 0x1c00
	ml_slb_load_b32x1  v12, v47, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v11, v10
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v9, v24, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[10:11], v[13:14], v[52:55]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v13, v5, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[10:11], v[7:8], v[56:59]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v7, v47, s1, #0, null
	ml_slb_load_b32x1  v8, v5, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v5, v4
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v10, v26, s0, #0, null
.Ltmp112:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:169:81 ]
	sl_reg_read s0, hwreg(HW_REG_MODE)
.Ltmp113:
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[4:5], v[12:13], v[52:55]
	sl_wait lmcnt(1)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[4:5], v[7:8], v[56:59]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v4, v24, s1, #0, null
	ml_slb_load_b32x1  v5, v26, s1, #0, null
.Ltmp114:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:169:81 ]
	sl_or_b32 {s1, wcr}, s0, 0x3
.Ltmp115:
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v7, v6
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[52:55], v[6:7], v[9:10], v[52:55]
	ml_xor_b32 v9, tid, 0x8
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[56:59], v[6:7], v[4:5], v[56:59]
	.loc	1 163 32 is_stmt 0              ; biv150_int8_pv.py:163:32
	ml_mul_f32 v4, s30, v52
	ml_mul_f32 v5, s30, v53
	ml_mov_b32 v7, 0xff800000
	ml_mul_f32 v6, s30, v56
	.loc	1 164 57 is_stmt 1              ; biv150_int8_pv.py:164:57
	ml_csel_b32 v4, v4, v7, tcr
	ml_csel_b32 v5, v5, v7, tcr
	sl_mov_b64 tcr, s[2:3]
	ml_csel_b32 v6, v6, v7, tcr
.Ltmp116:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	ml_max_f32 v8, v4, v6
.Ltmp117:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v10, v8, v9
.Ltmp118:
	.loc	1 163 32                        ; biv150_int8_pv.py:163:32
	ml_mul_f32 v11, s30, v57
	.loc	1 164 57                        ; biv150_int8_pv.py:164:57
	ml_csel_b32 v7, v11, v7, tcr
.Ltmp119:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	ml_max_f32 v11, v5, v7
.Ltmp120:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v12, v11, v9
.Ltmp121:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v8, v8, v10
	ml_xor_b32 v10, tid, 0x4
.Ltmp122:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v13, v8, v10
.Ltmp123:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v11, v11, v12
.Ltmp124:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v12, v11, v10
.Ltmp125:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v8, v8, v13
	ml_xor_b32 v13, tid, 0x2
.Ltmp126:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v14, v8, v13
.Ltmp127:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v11, v11, v12
.Ltmp128:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v12, v11, v13
.Ltmp129:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v8, v8, v14
	ml_xor_b32 v14, tid, 0x1
.Ltmp130:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v15, v8, v14
.Ltmp131:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v11, v11, v12
.Ltmp132:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v12, v11, v14
.Ltmp133:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v8, v8, v15
.Ltmp134:
	.loc	1 165 42                        ; biv150_int8_pv.py:165:42
	ml_max_f32 v24, v48, v8
	.loc	1 166 44                        ; biv150_int8_pv.py:166:44
	ml_sub_f32 v4, v4, v24
	ml_sub_f32 v6, v6, v24
.Ltmp135:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(0)
	ml_max_f32 v8, v11, v12
.Ltmp136:
	.loc	1 166 35                        ; biv150_int8_pv.py:166:35
	ml_exp_f32 v4, v4
	.loc	1 165 42                        ; biv150_int8_pv.py:165:42
	ml_max_f32 v26, v51, v8
	.loc	1 166 44                        ; biv150_int8_pv.py:166:44
	ml_sub_f32 v5, v5, v26
	ml_sub_f32 v7, v7, v26
	.loc	1 166 35 is_stmt 0              ; biv150_int8_pv.py:166:35
	ml_exp_f32 v5, v5
.Ltmp137:
	.loc	1 15 25 is_stmt 1               ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v8, v22, v4
.Ltmp138:
	.loc	1 166 35                        ; biv150_int8_pv.py:166:35
	ml_exp_f32 v6, v6
.Ltmp139:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v16, v22, v5
.Ltmp140:
	.loc	1 166 35                        ; biv150_int8_pv.py:166:35
	ml_exp_f32 v7, v7
.Ltmp141:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v11, v20, v6
.Ltmp142:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	ml_max_f32 v12, v8, v11
.Ltmp143:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v15, v12, v9
.Ltmp144:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	ml_add_f32 v4, v4, v6
.Ltmp145:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v17, v20, v7
.Ltmp146:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	ml_max_f32 v18, v16, v17
.Ltmp147:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v19, v18, v9
.Ltmp148:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	ml_add_f32 v5, v5, v7
.Ltmp149:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v6, v4, v9
	ml_slb_shuffle_rtn_b32 v7, v5, v9
.Ltmp150:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v9, v12, v15
.Ltmp151:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v12, v9, v10
.Ltmp152:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v15, v18, v19
.Ltmp153:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v18, v15, v10
.Ltmp154:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v4, v4, v6
.Ltmp155:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v6, v4, v10
.Ltmp156:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v5, v5, v7
.Ltmp157:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v7, v5, v10
.Ltmp158:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v9, v9, v12
.Ltmp159:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v10, v9, v13
.Ltmp160:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v12, v15, v18
.Ltmp161:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v15, v12, v13
.Ltmp162:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v4, v4, v6
.Ltmp163:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v6, v4, v13
.Ltmp164:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v5, v5, v7
.Ltmp165:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v7, v5, v13
.Ltmp166:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v9, v9, v10
.Ltmp167:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v10, v9, v14
.Ltmp168:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v12, v12, v15
.Ltmp169:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v13, v12, v14
.Ltmp170:
	.loc	1 167 45                        ; biv150_int8_pv.py:167:45
	ml_sub_f32 v15, v48, v24
.Ltmp171:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v4, v4, v6
.Ltmp172:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v6, v4, v14
.Ltmp173:
	.loc	1 167 31                        ; biv150_int8_pv.py:167:31
	ml_exp_f32 v20, v15
.Ltmp174:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v5, v5, v7
.Ltmp175:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v7, v5, v14
.Ltmp176:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v9, v9, v10
.Ltmp177:
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v9, v9, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v22, v9, 0x3c010204
.Ltmp178:
	.loc	2 192 27 is_stmt 1              ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(2)
	ml_max_f32 v9, v12, v13
.Ltmp179:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_rcp_f32 v10, v22
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v9, v9, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v58, v9, 0x3c010204
.Ltmp180:
	.loc	2 285 15 is_stmt 1              ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v4, v4, v6
.Ltmp181:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_rcp_f32 v6, v58
.Ltmp182:
	.loc	1 168 46                        ; biv150_int8_pv.py:168:46
	ml_fma_f32 v23, v23, v20, v4
.Ltmp183:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_xor_b32 v4, v22, 0x80000000
.Ltmp184:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v5, v5, v7
.Ltmp185:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_xor_b32 v7, v58, 0x80000000
	ml_mul_f32 v9, v8, v10
	ml_mul_f32 v12, v16, v6
	ml_mul_f32 v13, v11, v10
	ml_fma_f32 v8, v4, v9, v8
	ml_fma_f32 v4, v4, v13, v11
	ml_mul_f32 v11, v17, v6
	ml_fma_f32 v14, v7, v12, v16
	ml_fma_f32 v7, v7, v11, v17
	ml_fma_f32 v8, v8, v10, v9
	ml_fma_f32 v4, v4, v10, v13
.Ltmp186:
	.loc	1 167 45                        ; biv150_int8_pv.py:167:45
	ml_sub_f32 v10, v51, v26
.Ltmp187:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_fma_f32 v14, v14, v6, v12
	ml_fma_f32 v6, v7, v6, v11
	ml_mov_b32 v7, 0x99
.Ltmp188:
	.loc	1 167 31                        ; biv150_int8_pv.py:167:31
	ml_exp_f32 v59, v10
.Ltmp189:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v9, v7
	ml_csel_b32 v8, v9, v8, tcr
	.loc	1 17 72 is_stmt 0               ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v8, v8, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v12, v7
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v8, v8
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_csel_b32 v9, v12, v14, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v9, v9, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v13, v7
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v9, v9
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_csel_b32 v4, v13, v4, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v4, v4, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v11, v7
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v4, v4
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_csel_b32 v6, v11, v6, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v6, v6, 0x3f000000
.Ltmp190:
	.loc	1 168 46 is_stmt 1              ; biv150_int8_pv.py:168:46
	ml_fma_f32 v25, v25, v59, v5
.Ltmp191:
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v6, v6
	.loc	1 17 40 is_stmt 0               ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v5, v8, 0x0
	ml_max_f32 v7, v9, 0x0
	ml_max_f32 v4, v4, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:169:81 ]
	ml_min_f32 v5, v5, 0x42fe0000
	ml_min_f32 v7, v7, 0x42fe0000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v6, v6, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:169:81 ]
	ml_min_f32 v4, v4, 0x42fe0000
	ml_min_f32 v6, v6, 0x42fe0000
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:169:81 ]
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v5, v5
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v7, v7
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v4, v4
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v6, v6
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_barrier 
	ml_bfe2_b32 v8, tid, 0x24
	ml_anyop3_b32 v8, v45, v46, v8, 0xfffffffe
	ml_slb_store_b8  v5, v8, noreg, #0, null
	ml_slb_store_b8  v7, v8, noreg, #16, null
	ml_slb_store_b8  v4, v8, noreg, #128, null
	ml_slb_store_b8  v6, v8, noreg, #144, null
	sl_wait lmcnt(0)
	sl_barrier 
	ml_and_b32 v4, tid, 0x10
	ml_or_b32 v4, v45, v4
	.loc	1 19 25 is_stmt 1               ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_slb_load_b8  v5, v4, noreg, #128, null
	sl_mov_b32 s0, 0x2800
	sl_mov_b32 s1, 0x2000
	sl_mov_b32 s2, 0x504
	ml_slb_load_b8  v6, v4, noreg, #129, null
	sl_mov_b32 s3, 0x60504
	ml_slb_load_b8  v7, v4, noreg, #136, null
	ml_slb_load_b8  v8, v4, noreg, #137, null
	ml_slb_load_b8  v9, v4, noreg, #0, null
	ml_slb_load_b8  v10, v4, noreg, #1, null
	ml_slb_load_b8  v11, v4, noreg, #8, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v6, v5, 4
	ml_slb_load_b8  v4, v4, noreg, #9, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v7, v5, s2
	ml_slb_load_b8  v12, v44, s0, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v57, v8, v5, s3
	ml_slb_load_b8  v13, v44, s0, #1, null
	ml_slb_load_b8  v14, v44, s0, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v10, v9, 4
	ml_slb_load_b8  v15, v44, s0, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v11, v5, s2
	ml_slb_load_b8  v16, v44, s1, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v56, v4, v5, s3
	ml_slb_load_b8  v17, v44, s1, #1, null
	ml_slb_load_b8  v18, v44, s1, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v13, v12, 4
	ml_slb_load_b8  v19, v44, s1, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v14, v4, s2
	ml_slb_load_b8  v45, v43, s0, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v9, v15, v4, s3
	ml_slb_load_b8  v46, v43, s0, #257, null
	ml_slb_load_b8  v47, v43, s0, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v17, v16, 4
	ml_slb_load_b8  v48, v43, s0, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v18, v4, s2
	ml_slb_load_b8  v49, v43, s1, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v8, v19, v4, s3
	ml_slb_load_b8  v50, v43, s1, #257, null
	ml_slb_load_b8  v51, v43, s1, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v46, v45, 4
	ml_slb_load_b8  v52, v43, s1, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v47, v4, s2
	ml_slb_load_b8  v53, v44, s0, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v13, v48, v4, s3
	ml_slb_load_b8  v54, v44, s0, #513, null
	ml_slb_load_b8  v55, v44, s0, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v50, v49, 4
	ml_slb_load_b8  v6, v44, s0, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v51, v4, s2
	ml_slb_load_b8  v60, v44, s1, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v12, v52, v4, s3
	ml_slb_load_b8  v61, v44, s1, #513, null
	ml_slb_load_b8  v62, v44, s1, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v54, v53, 4
	ml_slb_load_b8  v63, v44, s1, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v55, v4, s2
	ml_slb_load_b8  v64, v43, s0, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v17, v6, v4, s3
	ml_matrix_mad_i32_i8_m16n16k32 v[4:7], v[56:57], v[8:9], v[0:3]
	ml_slb_load_b8  v65, v43, s0, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[8:11], v[56:57], v[12:13], v[0:3]
	ml_slb_load_b8  v66, v43, s0, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v61, v60, 4
	ml_slb_load_b8  v67, v43, s0, #801, null
	sl_mov_b32 s0, 0x2c00
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v62, v4, s2
	ml_slb_load_b8  v68, v43, s1, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v16, v63, v4, s3
	ml_slb_load_b8  v69, v43, s1, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[12:15], v[56:57], v[16:17], v[0:3]
	ml_slb_load_b8  v70, v43, s1, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v65, v64, 4
	ml_slb_load_b8  v71, v43, s1, #801, null
	sl_mov_b32 s1, 0x2400
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v66, v4, s2
	ml_slb_load_b8  v72, v44, s0, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v67, v4, s3
	ml_slb_load_b8  v73, v44, s0, #1, null
	ml_slb_load_b8  v74, v44, s0, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v69, v68, 4
	ml_slb_load_b8  v45, v44, s0, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v70, v4, s2
	ml_slb_load_b8  v46, v44, s1, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v71, v4, s3
	ml_slb_load_b8  v47, v44, s1, #1, null
	ml_matrix_mad_i32_i8_m16n16k32 v[16:19], v[56:57], v[4:5], v[0:3]
	ml_slb_load_b8  v48, v44, s1, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v73, v72, 4
	ml_slb_load_b8  v75, v44, s1, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v74, v4, s2
	ml_slb_load_b8  v49, v43, s0, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v45, v4, s3
	ml_slb_load_b8  v50, v43, s0, #257, null
	ml_slb_load_b8  v51, v43, s0, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v47, v46, 4
	ml_slb_load_b8  v52, v43, s0, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v48, v4, s2
	ml_slb_load_b8  v53, v43, s1, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v75, v4, s3
	ml_slb_load_b8  v54, v43, s1, #257, null
	ml_slb_load_b8  v55, v43, s1, #288, null
	ml_slb_load_b8  v76, v43, s1, #289, null
	ml_slb_load_b8  v60, v44, s0, #512, null
	ml_slb_load_b8  v8, v44, s0, #513, null
	ml_slb_load_b8  v9, v44, s0, #544, null
	ml_slb_load_b8  v12, v44, s0, #545, null
	ml_slb_load_b8  v13, v44, s1, #512, null
	ml_slb_load_b8  v61, v44, s1, #513, null
	ml_slb_load_b8  v16, v44, s1, #544, null
	ml_slb_load_b8  v17, v44, s1, #545, null
	ml_matrix_mad_i32_i8_m16n16k32 v[44:47], v[56:57], v[4:5], v[0:3]
	ml_slb_load_b8  v62, v43, s0, #768, null
	sl_wait lmcnt(15)
	ml_byte_permute_b32 v4, v50, v49, 4
	sl_wait lmcnt(14)
	ml_byte_permute_b32 v4, v51, v4, s2
	sl_wait lmcnt(13)
	ml_byte_permute_b32 v5, v52, v4, s3
	ml_slb_load_b8  v44, v43, s0, #769, null
	sl_wait lmcnt(12)
	ml_byte_permute_b32 v4, v54, v53, 4
	sl_wait lmcnt(11)
	ml_byte_permute_b32 v4, v55, v4, s2
	sl_wait lmcnt(10)
	ml_byte_permute_b32 v4, v76, v4, s3
	ml_slb_load_b8  v45, v43, s0, #800, null
	ml_matrix_mad_i32_i8_m16n16k32 v[48:51], v[56:57], v[4:5], v[0:3]
	ml_slb_load_b8  v63, v43, s0, #801, null
	sl_wait lmcnt(10)
	ml_byte_permute_b32 v4, v8, v60, 4
	sl_wait lmcnt(9)
	ml_byte_permute_b32 v4, v9, v4, s2
	ml_slb_load_b8  v64, v43, s1, #768, null
	sl_wait lmcnt(7)
	ml_byte_permute_b32 v5, v61, v13, 4
	sl_wait lmcnt(6)
	ml_byte_permute_b32 v9, v16, v5, s2
	ml_byte_permute_b32 v5, v12, v4, s3
	ml_slb_load_b8  v48, v43, s1, #769, null
	sl_wait lmcnt(6)
	ml_byte_permute_b32 v4, v17, v9, s3
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:169:81 ]
	ml_cvt_f32_i32  v12, v50
	ml_cvt_f32_i32  v13, v51
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_slb_load_b8  v8, v43, s1, #800, null
	ml_matrix_mad_i32_i8_m16n16k32 v[52:55], v[56:57], v[4:5], v[0:3]
	ml_slb_load_b8  v9, v43, s1, #801, null
	sl_wait lmcnt(6)
	ml_byte_permute_b32 v4, v44, v62, 4
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v4, v45, v4, s2
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v12, v22, v12
.Ltmp192:
	.loc	1 169 55                        ; biv150_int8_pv.py:169:55
	ml_fma_f32 v37, v37, v20, v12
	ml_mov_b32 v51, v26
.Ltmp193:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	sl_wait lmcnt(2)
	ml_byte_permute_b32 v5, v48, v64, 4
	ml_mov_b32 v48, v24
	sl_wait lmcnt(1)
	ml_byte_permute_b32 v8, v8, v5, s2
	ml_byte_permute_b32 v5, v63, v4, s3
	sl_wait lmcnt(0)
	ml_byte_permute_b32 v4, v9, v8, s3
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:169:81 ]
	ml_cvt_f32_i32  v8, v18
	ml_cvt_f32_i32  v9, v19
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_matrix_mad_i32_i8_m16n16k32 v[0:3], v[56:57], v[4:5], v[0:3]
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:169:81 ]
	ml_cvt_f32_i32  v0, v6
	ml_cvt_f32_i32  v1, v7
	ml_cvt_f32_i32  v4, v10
	ml_cvt_f32_i32  v5, v11
	ml_cvt_f32_i32  v6, v14
	ml_cvt_f32_i32  v7, v15
	ml_cvt_f32_i32  v10, v46
	ml_cvt_f32_i32  v11, v47
	ml_cvt_f32_i32  v14, v54
	ml_cvt_f32_i32  v15, v55
	ml_cvt_f32_i32  v2, v2
	ml_cvt_f32_i32  v3, v3
	.loc	1 20 34 is_stmt 0               ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v0, v22, v0
	ml_mul_f32 v4, v22, v4
	ml_mul_f32 v6, v22, v6
	ml_mul_f32 v8, v22, v8
	ml_mul_f32 v10, v22, v10
	ml_mul_f32 v14, v22, v14
	ml_mul_f32 v2, v22, v2
.Ltmp194:
	.loc	1 169 55 is_stmt 1              ; biv150_int8_pv.py:169:55
	ml_fma_f32 v21, v21, v20, v0
	ml_fma_f32 v29, v29, v20, v4
	ml_fma_f32 v31, v31, v20, v6
	ml_fma_f32 v33, v33, v20, v8
	ml_fma_f32 v35, v35, v20, v10
	ml_fma_f32 v39, v39, v20, v14
	ml_fma_f32 v41, v41, v20, v2
.Ltmp195:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v0, v58, v1
	ml_mul_f32 v1, v58, v5
	ml_mul_f32 v2, v58, v7
	ml_mul_f32 v4, v58, v9
	ml_mul_f32 v5, v58, v11
	ml_mul_f32 v6, v58, v13
	ml_mul_f32 v7, v58, v15
	ml_mul_f32 v3, v58, v3
.Ltmp196:
	.loc	1 169 55                        ; biv150_int8_pv.py:169:55
	ml_fma_f32 v27, v27, v59, v0
	ml_fma_f32 v30, v30, v59, v1
	ml_fma_f32 v32, v32, v59, v2
	ml_fma_f32 v34, v34, v59, v4
	ml_fma_f32 v36, v36, v59, v5
	ml_fma_f32 v38, v38, v59, v6
	ml_fma_f32 v40, v40, v59, v7
	ml_fma_f32 v42, v42, v59, v3
BB0_60:
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_mov_v2s_b32 s11, v152, 0x2
	ml_mov_v2s_b32 s4, v152, 0x0
	ml_mov_v2s_b32 s5, v152, 0x1
	ml_mov_v2s_b32 s8, v152, 0x5
	sl_or_b32 {s11, wcr}, s11, 0x0
	ml_mov_v2s_b32 s9, v152, 0x6
	sl_cbr_wcrnz BB0_62, wcr
; %bb.61:                               ; %.critedge
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	ml_and_b32 v0, tid, 0x30
	ml_srl_b32 v0, v0, 0x4
	.loc	1 90 46                         ; biv150_int8_pv.py:90:46
	ml_mov_v2s_b32 s0, v152, 0x3
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s3, 0x0
	sl_mull_u32 s2, s4, 0x200
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_and_b32 v2, tid, 0xf
	.loc	1 90 46                         ; biv150_int8_pv.py:90:46
	ml_add_i32 v0, s0, v0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_shl_b64 {s[0:1], wcr}, s[8:9], 0x11
	sl_add_i64 s[0:1], s[12:13], s[0:1]
	ml_shl_b32 v0, v0, 0xd
	sl_add_i64 s[0:1], s[2:3], s[0:1]
	ml_addo_u32 {v0, tcr}, s0, v0
	ml_mov_b32 v1, s1
	ml_shl_b32 v2, v2, 0x2
	sl_mov_b32 s0, 0x81c0
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v0, tcr}, v2, v0
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	sl_mov_b32 s0, 0x1c0
	.loc	1 178 47 is_stmt 0              ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[0:1], v21, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	ml_addc_i32 v3, 0, v1, tcr
	sl_wait lmcnt(4)
	ml_addo_u32 {v4, tcr}, s0, v0
	sl_mov_b32 s0, 0x8180
	ml_addc_i32 v5, 0, v1, tcr
	sl_wait lmcnt(0)
	ml_addo_u32 {v6, tcr}, s0, v0
	sl_mov_b32 s0, 0x180
	ml_addc_i32 v7, 0, v1, tcr
	ml_addo_u32 {v8, tcr}, s0, v0
	sl_mov_b32 s0, 0x8140
	ml_addc_i32 v9, 0, v1, tcr
	ml_addo_u32 {v10, tcr}, s0, v0
	sl_mov_b32 s0, 0x140
	ml_addc_i32 v11, 0, v1, tcr
	ml_addo_u32 {v12, tcr}, s0, v0
	sl_mov_b32 s0, 0x8100
	ml_addc_i32 v13, 0, v1, tcr
	ml_addo_u32 {v14, tcr}, s0, v0
	sl_mov_b32 s0, 0x100
	ml_addc_i32 v15, 0, v1, tcr
	ml_addo_u32 {v16, tcr}, s0, v0
	sl_mov_b32 s0, 0x80c0
	ml_addc_i32 v17, 0, v1, tcr
	ml_addo_u32 {v18, tcr}, s0, v0
	sl_mov_b32 s0, 0xc0
	ml_addc_i32 v19, 0, v1, tcr
	ml_addo_u32 {v43, tcr}, s0, v0
	sl_mov_b32 s0, 0x8080
	ml_addc_i32 v44, 0, v1, tcr
	ml_addo_u32 {v45, tcr}, s0, v0
	sl_mov_b32 s0, 0x80
	ml_addc_i32 v46, 0, v1, tcr
	ml_addo_u32 {v49, tcr}, s0, v0
	sl_mov_b32 s0, 0x8040
	ml_addc_i32 v50, 0, v1, tcr
	ml_addo_u32 {v52, tcr}, s0, v0
	sl_mov_b32 s0, 0x40
	ml_addc_i32 v53, 0, v1, tcr
	ml_addo_u32 {v54, tcr}, s0, v0
	sl_mov_b32 s0, 0x8000
	ml_addc_i32 v55, 0, v1, tcr
	ml_addo_u32 {v20, tcr}, s0, v0
	ml_addc_i32 v21, 0, v1, tcr
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[20:21], v27, kop=0
	ml_lsa_store_a64_dword  v[54:55], v29, kop=0
	ml_lsa_store_a64_dword  v[52:53], v30, kop=0
	ml_lsa_store_a64_dword  v[49:50], v31, kop=0
	ml_lsa_store_a64_dword  v[45:46], v32, kop=0
	ml_lsa_store_a64_dword  v[43:44], v33, kop=0
	ml_lsa_store_a64_dword  v[18:19], v34, kop=0
	ml_lsa_store_a64_dword  v[16:17], v35, kop=0
	ml_lsa_store_a64_dword  v[14:15], v36, kop=0
	ml_lsa_store_a64_dword  v[12:13], v37, kop=0
	ml_lsa_store_a64_dword  v[10:11], v38, kop=0
	ml_lsa_store_a64_dword  v[8:9], v39, kop=0
	ml_lsa_store_a64_dword  v[6:7], v40, kop=0
	ml_lsa_store_a64_dword  v[4:5], v41, kop=0
	ml_lsa_store_a64_dword  v[2:3], v42, kop=0
BB0_62:                                 ; %.critedge60
	.loc	1 180 20 is_stmt 1              ; biv150_int8_pv.py:180:20
	sl_shl_b64 {s[0:1], wcr}, s[8:9], 0x8
	.loc	1 180 39 is_stmt 0              ; biv150_int8_pv.py:180:39
	sl_mov_b32 s5, 0x0
	sl_add_i64 s[4:5], s[0:1], s[4:5]
	.loc	1 186 58 is_stmt 1              ; biv150_int8_pv.py:186:58
	ml_mul_f32 v0, v48, 0x3f317218
	ml_mul_f32 v1, v51, 0x3f317218
	.loc	1 186 44 is_stmt 0              ; biv150_int8_pv.py:186:44
	ml_and_b32 v2, tid, 0x1
	ml_cmp_eq_u32 tcr, v2, 0x0
	ml_csel_b32 v2, v0, v1, tcr
	ml_shl_b32 v3, v28, 0x4
	sl_wait lmcnt(4)
	ml_srl_b32 v4, v28, 0x3
	ml_and_b32 v4, v4, 0x6
	ml_bfe2_b32 v5, tid, 0x22
	ml_anyop3_b32 v3, 48, v3, v4, 0xfffffff8
	.loc	1 96 16 is_stmt 1               ; biv150_int8_pv.py:96:16
	ml_and_b32 v4, tid, 0x8
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_anyop3_b32 v3, v3, v5, v4, 0xfffffffe
	ml_slb_shuffle_rtn_b32 v2, v2, v3
	ml_csel_b32 v0, v1, v0, tcr
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	ml_csel_b32 v1, v23, v25, tcr
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_xor_b32 v4, v3, 0x1
	ml_slb_shuffle_rtn_b32 v5, v0, v4
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	sl_wait lmcnt(2)
	ml_csel_b32 v6, v25, v23, tcr
	ml_and_b32 v0, tid, 0x4
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_cmp_eq_u32 tcr, v0, 0x0
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	ml_slb_shuffle_rtn_b32 v0, v1, v3
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_and_b32 v1, v28, 0x78
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	ml_and_b32 v3, tid, 0x7
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	sl_mov_b64 s[0:1], tcr
	ml_cmp_eq_u32 tcr, v1, 0x0
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	ml_slb_shuffle_rtn_b32 v1, v6, v4
	ml_shl_b32 v3, v3, 0x6
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x2
	sl_mov_b64 s[2:3], tcr
	sl_mov_b64 tcr, s[0:1]
	sl_add_i64 s[12:13], s[14:15], s[4:5]
	sl_mov_b32 s15, 0xffffffff
	sl_mull_u32 s6, s7, 0x200
	sl_wait lmcnt(2)
	ml_csel_b32 v4, v2, v5, tcr
	ml_add_i32 v2, s6, v3
	sl_and_savetmsk_b64 {s[10:11], wcr}, s[2:3], tmsk
	ml_lsa_store_dword v4, s[12:15], signed v2, noreg, #0, wb
	sl_or_b64 {tmsk, wcr}, tmsk, s[10:11]
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	sl_and_savetmsk_b64 {s[6:7], wcr}, s[2:3], tmsk
	sl_xor_b64 {s[2:3], wcr}, tmsk, s[6:7]
	; mask branch BB0_64
BB0_63:
	.loc	1 0 47 is_stmt 0                ; biv150_int8_pv.py:0:47
	sl_mov_b64 tcr, s[0:1]
	sl_wait lmcnt(0)
	ml_csel_b32 v0, v0, v1, tcr
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	sl_add_i64 s[12:13], s[16:17], s[4:5]
	ml_lsa_store_dword v0, s[12:15], signed v2, noreg, #0, wb
BB0_64:                                 ; %Flow
	.loc	1 0 47                          ; biv150_int8_pv.py:0:47
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
BB0_65:                                 ; %common.ret
	sl_eop 
.Ltmp197:
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.globl	gqa_decode_int8_pv.kd
	.type	gqa_decode_int8_pv.kd,@object
	.size	gqa_decode_int8_pv.kd, 64
gqa_decode_int8_pv.kd:
	.asciz	"\000\000\000"
	.long	0
	.asciz	"\000\000\000\000\000\000\000"
	.quad	gqa_decode_int8_pv@rel64-gqa_decode_int8_pv.kd
	.asciz	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.long	537382
	.asciz	"\003\000\364\006\211\000\000\000\000\000\000"
	.text
.Lfunc_end0:
	.size	gqa_decode_int8_pv, .Lfunc_end0-gqa_decode_int8_pv
	.cfi_endproc
                                        ; -- End function
	.section	.Iluvatar.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 17464
; NumSgprs: 99
; NumVgprs: 153
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 12
; IeeeMode: 1
; SLBByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 12
; VGPRBlocks: 38
; NumSGPRsForWarpsPerNU: 95
; NumVGPRsForWarpsPerNR: 153
; ReqNTIDx: 0
; MaxNTIDx: 0
; MinCTASm: 0
; ActiveWarp: 1
; WarpLimiterHint : 0
	.type	gPrintBuf,@object               ; @gPrintBuf
	.data
	.weak	gPrintBuf
	.p2align	3, 0x0
gPrintBuf:
	.quad	0
	.size	gPrintBuf, 8

	.type	gAssertReason,@object           ; @gAssertReason
	.weak	gAssertReason
	.p2align	3, 0x0
gAssertReason:
	.quad	0
	.size	gAssertReason, 8

	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	8                               ; DW_FORM_string
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	16                              ; DW_AT_stmt_list
	.byte	6                               ; DW_FORM_data4
	.byte	27                              ; DW_AT_comp_dir
	.byte	8                               ; DW_FORM_string
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	32                              ; DW_AT_inline
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	1                               ; DW_CHILDREN_yes
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	6                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	7                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	5                               ; DW_FORM_data2
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
	.long	379                             ; Length of Unit
	.short	2                               ; DWARF version number
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	8                               ; Address Size (in bytes)
	.byte	1                               ; Abbrev [1] 0xb:0x174 DW_TAG_compile_unit
	.ascii	"triton"                        ; DW_AT_producer
	.byte	0
	.short	2                               ; DW_AT_language
	.ascii	"biv150_int8_pv.py"             ; DW_AT_name
	.byte	0
	.long	.debug_line                     ; DW_AT_stmt_list
	.ascii	"/workspace/experiments/minicpm-s2/code/owned55-int8-pv-20261027/tools/kernels" ; DW_AT_comp_dir
	.byte	0
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.byte	2                               ; Abbrev [2] 0x89:0x15 DW_TAG_subprogram
	.ascii	"gqa_decode_int8_pv"            ; DW_AT_name
	.byte	0
	.byte	1                               ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0x9e:0xe0 DW_TAG_subprogram
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.long	137                             ; DW_AT_abstract_origin
	.byte	4                               ; Abbrev [4] 0xb3:0x18 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.quad	.Ltmp1                          ; DW_AT_low_pc
	.quad	.Ltmp2                          ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	76                              ; DW_AT_call_line
	.byte	41                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xcb:0x26 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges0                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	134                             ; DW_AT_call_line
	.byte	81                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xd7:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges1                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	16                              ; DW_AT_call_line
	.byte	37                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0xe3:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges2                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0xf1:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges3                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	130                             ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0xfd:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges4                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x10a:0x1a DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges5                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	133                             ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0x116:0xd DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges6                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x124:0x26 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges7                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	169                             ; DW_AT_call_line
	.byte	81                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x130:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges8                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	16                              ; DW_AT_call_line
	.byte	37                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x13c:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges9                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x14a:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges10                ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	165                             ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x156:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges11                ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x163:0x1a DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges12                ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	168                             ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0x16f:0xd DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges13                ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp31-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	.Ltmp73-.Lfunc_begin0
	.quad	.Ltmp74-.Lfunc_begin0
	.quad	.Ltmp75-.Lfunc_begin0
	.quad	.Ltmp76-.Lfunc_begin0
	.quad	.Ltmp77-.Lfunc_begin0
	.quad	.Ltmp78-.Lfunc_begin0
	.quad	.Ltmp79-.Lfunc_begin0
	.quad	.Ltmp80-.Lfunc_begin0
	.quad	.Ltmp81-.Lfunc_begin0
	.quad	.Ltmp82-.Lfunc_begin0
	.quad	.Ltmp83-.Lfunc_begin0
	.quad	.Ltmp84-.Lfunc_begin0
	.quad	.Ltmp85-.Lfunc_begin0
	.quad	.Ltmp86-.Lfunc_begin0
	.quad	.Ltmp87-.Lfunc_begin0
	.quad	.Ltmp88-.Lfunc_begin0
	.quad	.Ltmp89-.Lfunc_begin0
	.quad	.Ltmp90-.Lfunc_begin0
	.quad	.Ltmp91-.Lfunc_begin0
	.quad	.Ltmp92-.Lfunc_begin0
	.quad	.Ltmp93-.Lfunc_begin0
	.quad	.Ltmp94-.Lfunc_begin0
	.quad	.Ltmp95-.Lfunc_begin0
	.quad	.Ltmp96-.Lfunc_begin0
	.quad	.Ltmp97-.Lfunc_begin0
	.quad	.Ltmp98-.Lfunc_begin0
	.quad	.Ltmp99-.Lfunc_begin0
	.quad	.Ltmp100-.Lfunc_begin0
	.quad	.Ltmp101-.Lfunc_begin0
	.quad	.Ltmp102-.Lfunc_begin0
	.quad	.Ltmp103-.Lfunc_begin0
	.quad	.Ltmp104-.Lfunc_begin0
	.quad	.Ltmp105-.Lfunc_begin0
	.quad	.Ltmp106-.Lfunc_begin0
	.quad	.Ltmp107-.Lfunc_begin0
	.quad	.Ltmp108-.Lfunc_begin0
	.quad	.Ltmp109-.Lfunc_begin0
	.quad	.Ltmp110-.Lfunc_begin0
	.quad	.Ltmp111-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp34-.Lfunc_begin0
	.quad	.Ltmp35-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp68-.Lfunc_begin0
	.quad	.Ltmp69-.Lfunc_begin0
	.quad	.Ltmp70-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp33-.Lfunc_begin0
	.quad	.Ltmp35-.Lfunc_begin0
	.quad	.Ltmp36-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp44-.Lfunc_begin0
	.quad	.Ltmp45-.Lfunc_begin0
	.quad	.Ltmp46-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp52-.Lfunc_begin0
	.quad	.Ltmp53-.Lfunc_begin0
	.quad	.Ltmp54-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp60-.Lfunc_begin0
	.quad	.Ltmp61-.Lfunc_begin0
	.quad	.Ltmp62-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp68-.Lfunc_begin0
	.quad	.Ltmp69-.Lfunc_begin0
	.quad	.Ltmp70-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges3:
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	.Ltmp25-.Lfunc_begin0
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	.Ltmp27-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges4:
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	.Ltmp17-.Lfunc_begin0
	.quad	.Ltmp18-.Lfunc_begin0
	.quad	.Ltmp19-.Lfunc_begin0
	.quad	.Ltmp20-.Lfunc_begin0
	.quad	.Ltmp21-.Lfunc_begin0
	.quad	.Ltmp22-.Lfunc_begin0
	.quad	.Ltmp23-.Lfunc_begin0
	.quad	.Ltmp24-.Lfunc_begin0
	.quad	.Ltmp25-.Lfunc_begin0
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	.Ltmp27-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges5:
	.quad	.Ltmp28-.Lfunc_begin0
	.quad	.Ltmp30-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp38-.Lfunc_begin0
	.quad	.Ltmp39-.Lfunc_begin0
	.quad	.Ltmp40-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp66-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges6:
	.quad	.Ltmp28-.Lfunc_begin0
	.quad	.Ltmp29-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp38-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp42-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp48-.Lfunc_begin0
	.quad	.Ltmp49-.Lfunc_begin0
	.quad	.Ltmp50-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp56-.Lfunc_begin0
	.quad	.Ltmp57-.Lfunc_begin0
	.quad	.Ltmp58-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp64-.Lfunc_begin0
	.quad	.Ltmp65-.Lfunc_begin0
	.quad	.Ltmp66-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges7:
	.quad	.Ltmp112-.Lfunc_begin0
	.quad	.Ltmp113-.Lfunc_begin0
	.quad	.Ltmp114-.Lfunc_begin0
	.quad	.Ltmp115-.Lfunc_begin0
	.quad	.Ltmp137-.Lfunc_begin0
	.quad	.Ltmp138-.Lfunc_begin0
	.quad	.Ltmp139-.Lfunc_begin0
	.quad	.Ltmp140-.Lfunc_begin0
	.quad	.Ltmp141-.Lfunc_begin0
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp145-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp170-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp180-.Lfunc_begin0
	.quad	.Ltmp181-.Lfunc_begin0
	.quad	.Ltmp182-.Lfunc_begin0
	.quad	.Ltmp183-.Lfunc_begin0
	.quad	.Ltmp184-.Lfunc_begin0
	.quad	.Ltmp185-.Lfunc_begin0
	.quad	.Ltmp186-.Lfunc_begin0
	.quad	.Ltmp187-.Lfunc_begin0
	.quad	.Ltmp188-.Lfunc_begin0
	.quad	.Ltmp189-.Lfunc_begin0
	.quad	.Ltmp190-.Lfunc_begin0
	.quad	.Ltmp191-.Lfunc_begin0
	.quad	.Ltmp192-.Lfunc_begin0
	.quad	.Ltmp193-.Lfunc_begin0
	.quad	.Ltmp194-.Lfunc_begin0
	.quad	.Ltmp195-.Lfunc_begin0
	.quad	.Ltmp196-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges8:
	.quad	.Ltmp142-.Lfunc_begin0
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp146-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp170-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp177-.Lfunc_begin0
	.quad	.Ltmp178-.Lfunc_begin0
	.quad	.Ltmp179-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges9:
	.quad	.Ltmp142-.Lfunc_begin0
	.quad	.Ltmp143-.Lfunc_begin0
	.quad	.Ltmp146-.Lfunc_begin0
	.quad	.Ltmp147-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp151-.Lfunc_begin0
	.quad	.Ltmp152-.Lfunc_begin0
	.quad	.Ltmp153-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp159-.Lfunc_begin0
	.quad	.Ltmp160-.Lfunc_begin0
	.quad	.Ltmp161-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp167-.Lfunc_begin0
	.quad	.Ltmp168-.Lfunc_begin0
	.quad	.Ltmp169-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp177-.Lfunc_begin0
	.quad	.Ltmp178-.Lfunc_begin0
	.quad	.Ltmp179-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges10:
	.quad	.Ltmp116-.Lfunc_begin0
	.quad	.Ltmp118-.Lfunc_begin0
	.quad	.Ltmp119-.Lfunc_begin0
	.quad	.Ltmp134-.Lfunc_begin0
	.quad	.Ltmp135-.Lfunc_begin0
	.quad	.Ltmp136-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges11:
	.quad	.Ltmp116-.Lfunc_begin0
	.quad	.Ltmp117-.Lfunc_begin0
	.quad	.Ltmp119-.Lfunc_begin0
	.quad	.Ltmp120-.Lfunc_begin0
	.quad	.Ltmp121-.Lfunc_begin0
	.quad	.Ltmp122-.Lfunc_begin0
	.quad	.Ltmp123-.Lfunc_begin0
	.quad	.Ltmp124-.Lfunc_begin0
	.quad	.Ltmp125-.Lfunc_begin0
	.quad	.Ltmp126-.Lfunc_begin0
	.quad	.Ltmp127-.Lfunc_begin0
	.quad	.Ltmp128-.Lfunc_begin0
	.quad	.Ltmp129-.Lfunc_begin0
	.quad	.Ltmp130-.Lfunc_begin0
	.quad	.Ltmp131-.Lfunc_begin0
	.quad	.Ltmp132-.Lfunc_begin0
	.quad	.Ltmp133-.Lfunc_begin0
	.quad	.Ltmp134-.Lfunc_begin0
	.quad	.Ltmp135-.Lfunc_begin0
	.quad	.Ltmp136-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges12:
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp145-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp171-.Lfunc_begin0
	.quad	.Ltmp173-.Lfunc_begin0
	.quad	.Ltmp174-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp180-.Lfunc_begin0
	.quad	.Ltmp181-.Lfunc_begin0
	.quad	.Ltmp184-.Lfunc_begin0
	.quad	.Ltmp185-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges13:
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp145-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp149-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp155-.Lfunc_begin0
	.quad	.Ltmp156-.Lfunc_begin0
	.quad	.Ltmp157-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp163-.Lfunc_begin0
	.quad	.Ltmp164-.Lfunc_begin0
	.quad	.Ltmp165-.Lfunc_begin0
	.quad	.Ltmp171-.Lfunc_begin0
	.quad	.Ltmp172-.Lfunc_begin0
	.quad	.Ltmp174-.Lfunc_begin0
	.quad	.Ltmp175-.Lfunc_begin0
	.quad	.Ltmp180-.Lfunc_begin0
	.quad	.Ltmp181-.Lfunc_begin0
	.quad	.Ltmp184-.Lfunc_begin0
	.quad	.Ltmp185-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	".note.GNU-stack","",@progbits
	.iluvatar_isa "bi-iluvatar-ilurt--ivcore-1-1-0"
	.iluvatar_hsa_metadata
---
iluvatar.kernels:
  - .args:
      - .address_space:  global
        .name:           KArg_0
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_1
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_2
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_3
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_4
        .offset:         32
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_5
        .offset:         40
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_6
        .offset:         48
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_7
        .offset:         56
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_8
        .offset:         64
        .size:           8
        .value_kind:     global_buffer
      - .name:           KArg_9
        .offset:         72
        .size:           4
        .value_kind:     by_value
      - .name:           KArg_10
        .offset:         80
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_11
        .offset:         88
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_12
        .offset:         96
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_13
        .offset:         104
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_14
        .offset:         112
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_15
        .offset:         120
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_16
        .offset:         128
        .size:           8
        .value_kind:     by_value
      - .address_space:  global
        .name:           KArg_17
        .offset:         136
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_18
        .offset:         144
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 152
    .max_flat_workgroup_size: 0
    .name:           gqa_decode_int8_pv
    .private_segment_fixed_size: 0
    .sgpr_count:     99
    .sgpr_spill_count: 19
    .symbol:         gqa_decode_int8_pv.kd
    .vgpr_count:     153
    .vgpr_spill_count: 0
    .warp_size:      64
iluvatar.version:
  - 1
  - 0
...

	.end_iluvatar_hsa_metadata
