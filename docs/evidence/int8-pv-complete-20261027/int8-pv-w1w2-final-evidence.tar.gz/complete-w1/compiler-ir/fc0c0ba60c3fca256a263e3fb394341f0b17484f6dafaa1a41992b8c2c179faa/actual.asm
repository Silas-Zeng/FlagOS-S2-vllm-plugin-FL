	.text
	.globl	gqa_decode_int8_pv              ; -- Begin function gqa_decode_int8_pv
	.p2align	3
	.type	gqa_decode_int8_pv,@function
	.iluvatar_kernel gqa_decode_int8_pv
gqa_decode_int8_pv:                     ; @gqa_decode_int8_pv
.Lfunc_begin0:
	.file	1 "/workspace/experiments/minicpm-s2/code/owned55-int8-pv-20261027/tools/kernels" "biv150_int8_pv.py"
	.loc	1 35 0                          ; biv150_int8_pv.py:35:0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_return_column 32
	.iluvatar_kernel_code_t
		iluvatar_code_version_major = 1
		iluvatar_code_version_minor = 3
		iluvatar_machine_kind = 1
		iluvatar_machine_version_major = 1
		iluvatar_machine_version_minor = 1
		iluvatar_machine_version_stepping = 0
		kernel_code_entry_byte_offset = 256
		kernel_code_prefetch_byte_size = 0
		granulated_workitem_vgpr_count = 46
		granulated_warp_sgpr_count = 12
		float_mode = 12
		debug_mode = 0
		has_mbar = 0
		user_sgpr_count = 6
		enable_sgpr_workgroup_id_x = 1
		enable_sgpr_workgroup_id_y = 1
		enable_sgpr_workgroup_id_z = 1
		enable_sgpr_workgroup_info = 1
		enable_vgpr_workitem_id = 3
		granulated_slb_size = 0
		enable_exception = 128
		enable_sgpr_private_segment_buffer = 1
		enable_sgpr_globalvariable_ptr = 0
		enable_sgpr_kernarg_segment_ptr = 1
		enable_sgpr_constvariable_ptr = 0
		enable_sgpr_private_segment_size = 0
		enable_sgpr_grid_workgroup_count_x = 0
		enable_sgpr_grid_workgroup_count_y = 0
		enable_sgpr_grid_workgroup_count_z = 0
		private_element_size = 1
		is_ptr64 = 1
		is_dynamic_callstack = 0
		is_debug_enabled = 0
		enable_private_swizzle = 1
		has_called_assert = 0
		has_called_printf = 0
		has_called_malloc = 0
		enable_srf_flat_shared = 0
		enable_srf_flat_scratch = 0
		has_wgmma = 0
		has_dva = 0
		enable_dynamic_smem_size = 0
		workitem_private_segment_byte_size = 0
		workgroup_group_segment_byte_size = 0
		kernarg_segment_byte_size = 152
		workgroup_fbarrier_count = 0
		warp_sgpr_count = 98
		workitem_vgpr_count = 185
		reserved_vgpr_first = 0
		reserved_vgpr_count = 0
		reserved_sgpr_first = 0
		reserved_sgpr_count = 0
		debug_warp_private_segment_offset_sgpr = 0
		debug_private_segment_buffer_sgpr = 0
		kernarg_segment_alignment = 3
		group_segment_alignment = 4
		private_segment_alignment = 4
		warp_size = 6
		call_convention = -1
		runtime_loader_kernel_symbol = 0
	.end_iluvatar_kernel_code_t
; %bb.0:
	; Func LiveIn Regs:
	;  blockIdx.x : s6  blockIdx.y : s7  blockIdx.z : s8
	ml_vrf_init_u32 v78, tcr
	sl_mov_b32 s86, s6
.Ltmp0:
	.loc	1 71 28 prologue_end            ; biv150_int8_pv.py:71:28
	sl_lsa_load_b32x16 s[12:27], s[4:5], noreg, #0, ca
	.loc	1 75 37                         ; biv150_int8_pv.py:75:37
	sl_mov_b32 s85, 0x0
	sl_mov_b32 s87, s85
	sl_shl_b64 {s[0:1], wcr}, s[86:87], 0x2
	sl_mov_b32 s3, 0xffffffff
	sl_wait smcnt(0)
	sl_add_i64 s[0:1], s[26:27], s[0:1]
	.loc	1 75 22 is_stmt 0               ; biv150_int8_pv.py:75:22
	ml_lsa_load_dword v0, s[0:3], noreg, noreg, #0, ca
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s0, v0, 0x0
.Ltmp1:
	.file	2 "/usr/local/lib/python3.12/site-packages/triton/language" "standard.py"
	.loc	2 65 17 is_stmt 1               ; standard.py:65:17 @[ biv150_int8_pv.py:76:41 ]
	sl_add_i32 s1, s0, 0xff
	.loc	2 65 30 is_stmt 0               ; standard.py:65:30 @[ biv150_int8_pv.py:76:41 ]
	sl_sra_b32 {s2, wcr}, s1, 0x1f
	sl_srl_b32 {s2, wcr}, s2, 0x18
	sl_add_i32 s1, s1, s2
	sl_sra_b32 {s1, wcr}, s1, 0x8
.Ltmp2:
	.loc	1 77 26 is_stmt 1               ; biv150_int8_pv.py:77:26
	sl_mull_u32 s2, s1, s8
	.loc	1 77 46 is_stmt 0               ; biv150_int8_pv.py:77:46
	sl_mull_u32 s60, s2, 0x10
	.loc	1 78 16 is_stmt 1               ; biv150_int8_pv.py:78:16
	sl_cmp_lt_i32 wcr, s60, s0
	sl_cbr_wcrz BB0_110, wcr
; %bb.1:
	.loc	1 0 16 is_stmt 0                ; biv150_int8_pv.py:0:16
	sl_mov_b32 s90, s8
	sl_mov_b32 s6, s7
	sl_lsa_load_b32x16 s[44:59], s[4:5], noreg, #128, ca
	.loc	1 84 29 is_stmt 1               ; biv150_int8_pv.py:84:29
	ml_bfe2_b32 v20, tid, 0x25
	ml_add_i32 v116, v20, 0x2
	ml_add_i32 v114, v20, 0x4
	ml_add_i32 v112, v20, 0x6
	ml_add_i32 v111, v20, 0x8
	ml_add_i32 v110, v20, 0xa
	ml_add_i32 v107, v20, 0xc
	.loc	1 0 0 is_stmt 0                 ; biv150_int8_pv.py:0
	sl_lsa_load_b32x16 s[28:43], s[4:5], noreg, #64, ca
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v105, v20, 0xe
	.loc	1 80 31 is_stmt 1               ; biv150_int8_pv.py:80:31
	sl_add_i32 s1, s2, s1
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v101, v20, 0x12
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	sl_wait smcnt(0)
	ml_mul_u64_u32 v[8:9], s45, v20
	.loc	1 96 28                         ; biv150_int8_pv.py:96:28
	sl_mull_u32 s84, s7, 0x800
	.loc	1 96 16 is_stmt 0               ; biv150_int8_pv.py:96:16
	sl_mov_b32 s51, 0xfff00004
	.loc	1 80 31 is_stmt 1               ; biv150_int8_pv.py:80:31
	sl_mull_u32 s1, s1, 0x10
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[54:55], s44, v20
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_mov_b32 s7, 0x400
	.loc	1 80 62                         ; biv150_int8_pv.py:80:62
	sl_min_i32 s46, s1, s0
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[9:10], s45, v116
	.loc	1 92 20                         ; biv150_int8_pv.py:92:20
	sl_mull_u32 s4, s35, s86
	sl_mul_u64_u32 s[2:3], s34, s86
	sl_add_i32 s3, s3, s4
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[76:77], s44, v116
	.loc	1 96 28                         ; biv150_int8_pv.py:96:28
	sl_shl_b64 {s[2:3], wcr}, s[2:3], 0x1
	sl_add_i64 s[2:3], s[18:19], s[2:3]
	sl_add_i64 s[48:49], s[2:3], s[84:85]
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[10:11], s45, v114
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_mov_b32 s2, 0x3020706
	sl_mov_b32 s3, 0x1000504
	.loc	1 98 50                         ; biv150_int8_pv.py:98:50
	sl_mul_u64_u32 s[0:1], s32, s86
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[74:75], s44, v114
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_shl_b64 {s[76:77], wcr}, s[38:39], 0x1
	sl_shl_b64 {s[74:75], wcr}, s[38:39], 0x2
	sl_mul_u64_u32 s[72:73], s38, 0x6
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[11:12], s45, v112
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_shl_b64 {s[8:9], wcr}, s[38:39], 0x3
	sl_mull_u32 s4, s39, 0xa
	sl_mul_u64_u32 s[92:93], s38, 0xc
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[72:73], s44, v112
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mul_u64_u32 s[26:27], s38, 0xe
	.loc	1 121 28                        ; biv150_int8_pv.py:121:28
	sl_mull_u32 s18, s6, 0x80
	.loc	1 121 14 is_stmt 0              ; biv150_int8_pv.py:121:14
	sl_mov_b32 s19, s85
	.loc	1 120 37 is_stmt 1              ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[12:13], s45, v111
	ml_mul_u64_u32 v[70:71], s44, v111
	ml_mul_u64_u32 v[13:14], s45, v110
	ml_mul_u64_u32 v[68:69], s44, v110
	ml_mul_u64_u32 v[14:15], s45, v107
	ml_mul_u64_u32 v[66:67], s44, v107
	ml_mul_u64_u32 v[15:16], s45, v105
	ml_mul_u64_u32 v[64:65], s44, v105
	.loc	1 99 30                         ; biv150_int8_pv.py:99:30
	ml_and_b32 v0, v101, 0x3
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v99, v20, 0x14
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[16:17], s45, v0
	ml_mul_u64_u32 v[62:63], s44, v0
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_lsa_blkload_x4 v[0:3], s[48:51], noreg, noreg, #0, ca
	.loc	1 99 30                         ; biv150_int8_pv.py:99:30
	ml_and_b32 v4, v99, 0x5
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	ml_and_b32 v21, tid, 0x30
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[17:18], s45, v4
	ml_mul_u64_u32 v[58:59], s44, v4
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_lsa_blkload_x4 v[4:7], s[48:51], noreg, s7, #0, ca
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	ml_and_b32 v18, tid, 0x7
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_shl_b32 v19, v21, 0x5
	ml_shl_b32 v18, v18, 0x3
	ml_and_b32 v22, tid, 0x8
	ml_cmp_eq_u32 tcr, v22, 0x0
	ml_mov_b32 v22, 0x180
	ml_csel_b32 v22, 0, v22, tcr
	ml_anyop3_b32 v22, v22, v19, v18, 0xfffffffe
	sl_wait vmcnt(1)
	ml_byte_permute_b32 v19, v1, v0, s2
	ml_byte_permute_b32 v18, v1, v0, s3
	ml_slb_store_b32x2  v[18:19], v22, noreg, #0, null
	ml_byte_permute_b32 v1, v3, v2, s2
	ml_byte_permute_b32 v0, v3, v2, s3
	ml_xor_b32 v2, v22, 0x80
	ml_slb_store_b32x2  v[0:1], v22, noreg, #64, null
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v100, v20, 0x16
	.loc	1 99 30                         ; biv150_int8_pv.py:99:30
	ml_and_b32 v3, v100, 0x7
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_wait vmcnt(0)
	ml_byte_permute_b32 v1, v5, v4, s2
	ml_byte_permute_b32 v0, v5, v4, s3
	ml_slb_store_b32x2  v[0:1], v2, noreg, #0, null
	ml_byte_permute_b32 v1, v7, v6, s2
	ml_byte_permute_b32 v0, v7, v6, s3
	.loc	1 98 50                         ; biv150_int8_pv.py:98:50
	sl_mull_u32 s2, s33, s86
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	ml_slb_store_b32x2  v[0:1], v2, noreg, #64, null
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[0:1], s45, v3
	.loc	1 98 50                         ; biv150_int8_pv.py:98:50
	sl_add_i32 s1, s1, s2
	.loc	1 98 40 is_stmt 0               ; biv150_int8_pv.py:98:40
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	sl_add_i64 s[2:3], s[28:29], s[0:1]
	.loc	1 120 37 is_stmt 1              ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[60:61], s44, v3
	.loc	1 105 35                        ; biv150_int8_pv.py:105:35
	sl_sub_i32 s0, s46, s60
	.loc	1 105 45 is_stmt 0              ; biv150_int8_pv.py:105:45
	sl_sra_b32 {s1, wcr}, s0, 0x1f
	sl_srl_b32 {s1, wcr}, s1, 0x1b
	.loc	1 84 29 is_stmt 1               ; biv150_int8_pv.py:84:29
	ml_add_i32 v97, v20, 0x18
	.loc	1 99 30                         ; biv150_int8_pv.py:99:30
	ml_and_b32 v3, v97, 0x9
	.loc	1 105 45                        ; biv150_int8_pv.py:105:45
	sl_add_i32 s0, s0, s1
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[1:2], s45, v3
	.loc	1 105 59                        ; biv150_int8_pv.py:105:59
	sl_and_b32 {s0, wcr}, s0, 0xffffffe0
	.loc	1 105 25 is_stmt 0              ; biv150_int8_pv.py:105:25
	sl_add_i32 s50, s0, s60
	.loc	1 114 37 is_stmt 1              ; biv150_int8_pv.py:114:37
	sl_mull_u32 s0, s39, 0x6
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_mul_u64_u32 v[56:57], s44, v3
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_add_i32 s73, s73, s0
	sl_mul_u64_u32 s[0:1], s38, 0xa
	sl_add_i32 s1, s1, s4
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v95, v20, 0x1a
	.loc	1 99 30                         ; biv150_int8_pv.py:99:30
	ml_and_b32 v4, v95, 0xb
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v108, v55, v8
	ml_mul_u64_u32 v[2:3], s45, v4
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_mull_u32 s4, s39, 0xc
	sl_add_i32 s93, s93, s4
	sl_mull_u32 s4, s39, 0xe
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v121, v77, v9
	ml_mul_u64_u32 v[52:53], s44, v4
	.loc	1 114 37                        ; biv150_int8_pv.py:114:37
	sl_add_i32 s27, s27, s4
	.loc	1 115 28                        ; biv150_int8_pv.py:115:28
	sl_mull_u32 s4, s41, s6
	sl_mul_u64_u32 s[32:33], s40, s6
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v120, v75, v10
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v92, v20, 0x1c
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v119, v73, v11
	.loc	1 99 30                         ; biv150_int8_pv.py:99:30
	ml_and_b32 v5, v92, 0xd
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v118, v71, v12
	ml_add_i32 v117, v69, v13
	ml_mul_u64_u32 v[3:4], s45, v5
	.loc	1 115 28                        ; biv150_int8_pv.py:115:28
	sl_add_i32 s33, s33, s4
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v115, v67, v14
	ml_mul_u64_u32 v[50:51], s44, v5
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_add_i32 v90, v20, 0x1e
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v113, v65, v15
	.loc	1 99 30                         ; biv150_int8_pv.py:99:30
	ml_and_b32 v6, v90, 0xf
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v109, v63, v16
	ml_add_i32 v106, v59, v17
	ml_mul_u64_u32 v[4:5], s45, v6
	ml_add_i32 v104, v61, v0
	ml_mul_u64_u32 v[48:49], s44, v6
	ml_add_i32 v103, v57, v1
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_and_b32 v0, tid, 0xf
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v102, v53, v2
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_and_b32 v1, tid, 0x20
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v98, v51, v3
	.loc	1 94 19                         ; biv150_int8_pv.py:94:19
	ml_shl_b32 v2, v78, 0x2
	ml_and_b32 v93, v2, 0x7c
	.loc	1 120 37                        ; biv150_int8_pv.py:120:37
	ml_add_i32 v94, v49, v4
	ml_mov_b32 v5, 0x0
	.loc	1 127 44                        ; biv150_int8_pv.py:127:44
	ml_shl_b32 v87, v0, 0x1
	.loc	1 96 16                         ; biv150_int8_pv.py:96:16
	sl_wait lmcnt(0)
	sl_barrier 
	ml_shl_b32 v0, tid, 0x2
	ml_xor_b32 v2, v0, 0x80
	ml_slb_blkload_x1  v44, noreg, noreg, #0, null
	.loc	1 107 21                        ; biv150_int8_pv.py:107:21
	sl_cmp_lt_i32 wcr, s60, s50
	.loc	1 107 4 is_stmt 0               ; biv150_int8_pv.py:107:4
	ml_mov_b32 v88, 0xff800000
	ml_shl_b32 v91, v78, 0x6
	.loc	1 96 16 is_stmt 1               ; biv150_int8_pv.py:96:16
	ml_slb_blkload_x1  v40, noreg, noreg, #512, null
	ml_and_b32 v3, tid, 0xc
	ml_and_b32 v10, tid, 0x3
	ml_and_b32 v4, tid, 0x4
	ml_slb_blkload_x1  v36, noreg, s7, #0, null
	ml_xor_b32 v6, tid, 0x8
	ml_xor_b32 v7, tid, 0x4
	ml_xor_b32 v8, tid, 0x2
	ml_slb_blkload_x1  v32, noreg, s7, #512, null
	ml_xor_b32 v9, tid, 0x1
	ml_srl_b32 v84, v1, 0x2
	ml_shl_b32 v1, v21, 0x2
	ml_slb_load_b32x1  v46, v2, noreg, #256, null
	ml_shl_b32 v122, v3, 0x2
	ml_shl_b32 v96, v10, 0x3
	ml_shl_b32 v11, v3, 0x6
	ml_slb_load_b32x1  v42, v2, noreg, #768, null
	ml_shl_b32 v3, v3, 0x3
	ml_shl_b32 v10, v10, 0x1
	ml_or_b32 v83, v1, v87
	ml_slb_load_b32x1  v38, v2, s7, #256, null
	sl_mull_u32 s84, s6, 0x4
	ml_or_b32 v86, v0, v11
	ml_or_b32 v85, v3, v10
	ml_slb_load_b32x1  v34, v2, s7, #768, null
	ml_xor_b32 v82, v83, 0x40
	ml_mov_b32 v89, 0xff800000
	ml_mov_b32 v49, 0x0
	ml_mov_b32 v51, 0x0
	ml_mov_b32 v53, 0x0
	ml_mov_b32 v80, 0x0
	ml_mov_b32 v81, 0x0
	ml_mov_b32 v77, 0x0
	ml_mov_b32 v79, 0x0
	ml_mov_b32 v73, 0x0
	ml_mov_b32 v75, 0x0
	ml_mov_b32 v69, 0x0
	ml_mov_b32 v71, 0x0
	ml_mov_b32 v65, 0x0
	ml_mov_b32 v67, 0x0
	ml_mov_b32 v61, 0x0
	ml_mov_b32 v63, 0x0
	ml_mov_b32 v55, 0x0
	ml_mov_b32 v57, 0x0
	ml_mov_b32 v59, 0x0
	sl_cbr_wcrz BB0_4, wcr
; %bb.2:                                ; %.lr.ph
	.loc	1 0 16 is_stmt 0                ; biv150_int8_pv.py:0:16
	sl_mov_b32 s4, 0xcc0
	ml_anyop3_b32 v10, s4, v91, v122, 0xfffffff8
	ml_xor_b32 v11, v10, 0x10
	ml_xor_b32 v12, v10, 0x20
	ml_xor_b32 v13, v10, 0x30
	ml_and_b32 v0, tid, 0x4
	ml_cmp_eq_u32 tcr, v0, 0x0
	ml_mov_b32 v0, 0x140
	ml_csel_b32 v0, 0, v0, tcr
	sl_mov_b32 s4, 0x600
	ml_anyop3_b32 v1, s4, v91, v96, 0xfffffff8
	.loc	1 84 29 is_stmt 1               ; biv150_int8_pv.py:84:29
	ml_bfe2_b32 v2, tid, 0x25
	ml_anyop3_b32 v14, v0, v1, v2, 0xfffffffe
	ml_xor_b32 v15, v14, 0x40
	ml_xor_b32 v16, v86, 0x10
	ml_xor_b32 v17, v86, 0x20
	ml_xor_b32 v18, v86, 0x30
	sl_wait lmcnt(7)
	ml_mov_b32 v45, v44
	sl_wait lmcnt(3)
	ml_mov_b32 v47, v46
	ml_mov_b32 v41, v40
	sl_wait lmcnt(2)
	ml_mov_b32 v43, v42
	ml_mov_b32 v37, v36
	sl_wait lmcnt(1)
	ml_mov_b32 v39, v38
	ml_mov_b32 v33, v32
	sl_wait lmcnt(0)
	ml_mov_b32 v35, v34
	sl_mov_b32 s31, 0xffffffff
	ml_mov_b32 v19, 0x99
	ml_bfe2_b32 v0, tid, 0x24
	ml_anyop3_b32 v20, v85, v84, v0, 0xfffffffe
	ml_and_b32 v0, tid, 0x10
	ml_or_b32 v21, v85, v0
	sl_mov_b32 s38, 0x504
	sl_mov_b32 s39, 0x60504
	sl_mov_b32 s40, 0x1000
	sl_mov_b32 s41, 0x2000
	sl_mov_b32 s44, 0x2800
	sl_mov_b32 s45, 0x800
	sl_mov_b32 s47, 0xc00
	sl_mov_b32 s52, 0x1400
	sl_mov_b32 s53, 0x1800
	sl_mov_b32 s54, 0x1c00
	sl_mov_b32 s55, 0x2c00
	sl_mov_b32 s56, 0x2400
	ml_mov_b32 v22, 0x0
	ml_mov_b32 v23, 0x0
	ml_mov_b32 v24, 0x0
	ml_mov_b32 v25, 0x0
	ml_mov_b32 v26, 0x0
	ml_mov_b32 v27, 0x0
	ml_mov_b32 v28, 0x0
	ml_mov_b32 v29, 0x0
	ml_mov_b32 v30, 0x0
	ml_mov_b32 v31, 0x0
	ml_mov_b32 v123, 0x0
	ml_mov_b32 v124, 0x0
	ml_mov_b32 v125, 0x0
	ml_mov_b32 v126, 0x0
	ml_mov_b32 v127, 0x0
	ml_mov_b32 v128, 0x0
BB0_3:                                  ; =>This Inner Loop Header: Depth=1
	.loc	1 109 54                        ; biv150_int8_pv.py:109:54
	sl_sra_b32 {s4, wcr}, s60, 0x4
	.loc	1 109 42 is_stmt 0              ; biv150_int8_pv.py:109:42
	sl_sra_b32 {s5, wcr}, s4, 0x1f
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x2
	sl_add_i64 s[28:29], s[2:3], s[4:5]
	.loc	1 109 24                        ; biv150_int8_pv.py:109:24
	ml_lsa_load_dwordx2 v[129:130], s[28:31], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 1              ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[34:35], wcr}, s[32:33], 0x1
	.loc	1 124 20 is_stmt 0              ; biv150_int8_pv.py:124:20
	sl_mov_b64 s[70:71], s[50:51]
	sl_mov_b64 s[82:83], s[50:51]
	.loc	1 109 24 is_stmt 1              ; biv150_int8_pv.py:109:24
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s4, v129, 0x0
	ml_mov_b32 v129, v89
	sl_sra_b32 {s5, wcr}, s4, 0x1f
	.loc	1 113 28                        ; biv150_int8_pv.py:113:28
	sl_mul_u64_u32 s[28:29], s36, s4
	sl_mull_u32 s48, s37, s4
	sl_mull_u32 s49, s36, s5
	sl_add_i32 s29, s29, s49
	sl_add_i32 s29, s29, s48
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_shl_b64 {s[28:29], wcr}, s[28:29], 0x1
	sl_add_i64 s[28:29], s[20:21], s[28:29]
	sl_add_i64 s[48:49], s[28:29], s[34:35]
	.loc	1 124 20 is_stmt 0              ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v0, s[48:51], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[48:49], s[76:77]
	.loc	1 110 24 is_stmt 1              ; biv150_int8_pv.py:110:24
	ml_mov_v2s_b32 s28, v130, 0x0
	ml_mov_b32 v130, v88
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v1, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 110 24 is_stmt 1              ; biv150_int8_pv.py:110:24
	sl_sra_b32 {s29, wcr}, s28, 0x1f
	.loc	1 113 28                        ; biv150_int8_pv.py:113:28
	sl_mull_u32 s57, s36, s29
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v2, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 113 28 is_stmt 1              ; biv150_int8_pv.py:113:28
	sl_mul_u64_u32 s[48:49], s36, s28
	sl_add_i32 s49, s49, s57
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v3, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 113 28 is_stmt 1              ; biv150_int8_pv.py:113:28
	sl_mull_u32 s57, s37, s28
	sl_add_i32 s49, s49, s57
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v131, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	sl_shl_b64 {s[48:49], wcr}, s[48:49], 0x1
	sl_add_i64 s[48:49], s[20:21], s[48:49]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v132, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 119 28 is_stmt 1              ; biv150_int8_pv.py:119:28
	sl_mull_u32 s57, s42, s29
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v133, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v134, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v135, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v136, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v137, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v138, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v139, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v140, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v141, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v142, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[48:49], s[34:35]
	sl_add_i64 s[80:81], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	sl_add_i64 s[48:49], s[68:69], s[74:75]
	ml_lsa_blkload_x1 v143, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[34:35], s[80:81], s[76:77]
	sl_add_i64 s[34:35], s[34:35], s[76:77]
	sl_add_i64 s[34:35], s[34:35], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v144, s[80:83], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[34:35], s[34:35], s[76:77]
	sl_add_i64 s[34:35], s[34:35], s[76:77]
	sl_add_i64 s[34:35], s[34:35], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v145, s[48:51], noreg, noreg, #0, ca
	sl_add_i64 s[48:49], s[68:69], s[72:73]
	ml_lsa_blkload_x1 v146, s[48:51], noreg, noreg, #0, ca
	sl_add_i64 s[48:49], s[68:69], s[8:9]
	ml_lsa_blkload_x1 v147, s[48:51], noreg, noreg, #0, ca
	sl_add_i64 s[48:49], s[68:69], s[0:1]
	ml_lsa_blkload_x1 v148, s[48:51], noreg, noreg, #0, ca
	sl_add_i64 s[48:49], s[68:69], s[92:93]
	ml_lsa_blkload_x1 v149, s[48:51], noreg, noreg, #0, ca
	sl_add_i64 s[48:49], s[68:69], s[26:27]
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[34:35], s[76:77]
	.loc	1 119 28 is_stmt 1              ; biv150_int8_pv.py:119:28
	sl_mull_u32 s34, s42, s5
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v150, s[48:51], noreg, noreg, #0, ca
	.loc	1 119 28                        ; biv150_int8_pv.py:119:28
	sl_mul_u64_u32 s[48:49], s42, s4
	sl_add_i32 s34, s49, s34
	sl_mull_u32 s35, s43, s4
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v151, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 119 28 is_stmt 1              ; biv150_int8_pv.py:119:28
	sl_add_i32 s49, s34, s35
	sl_mul_u64_u32 s[34:35], s42, s28
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v152, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 119 28 is_stmt 1              ; biv150_int8_pv.py:119:28
	sl_add_i32 s35, s35, s57
	sl_mull_u32 s57, s43, s28
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v153, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 119 28 is_stmt 1              ; biv150_int8_pv.py:119:28
	sl_add_i32 s35, s35, s57
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v154, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36 is_stmt 0              ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v155, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v156, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v157, s[68:71], noreg, noreg, #0, ca
	.loc	1 124 36                        ; biv150_int8_pv.py:124:36
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_lsa_blkload_x1 v158, s[68:71], noreg, noreg, #0, ca
	sl_wait vmcnt(0)
	sl_barrier 
	.loc	1 125 38 is_stmt 1              ; biv150_int8_pv.py:125:38
	sl_add_i64 s[48:49], s[22:23], s[48:49]
	sl_add_i64 s[48:49], s[18:19], s[48:49]
	ml_addo_u32 {v88, tcr}, s48, v54
	ml_mov_b32 v167, s49
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[0:3], v10, noreg, #0, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	sl_add_i64 s[34:35], s[22:23], s[34:35]
	ml_addc_i32 v89, v167, v108, tcr
	ml_addo_u32 {v88, tcr}, v93, v88
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[143:146], v10, s40, #0, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	sl_add_i64 s[34:35], s[18:19], s[34:35]
	.loc	1 126 48                        ; biv150_int8_pv.py:126:48
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0xe
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v89, 0, v89, tcr
	ml_addo_u32 {v159, tcr}, s48, v76
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[131:134], v11, noreg, #256, null
	.loc	1 126 30                        ; biv150_int8_pv.py:126:30
	sl_add_i64 s[4:5], s[24:25], s[4:5]
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v160, v167, v121, tcr
	ml_addo_u32 {v159, tcr}, v93, v159
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[147:150], v11, s40, #256, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v160, 0, v160, tcr
	ml_addo_u32 {v161, tcr}, s48, v74
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[135:138], v12, noreg, #512, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	sl_nop 0x0
	ml_mov_b32 v137, s35
	ml_addc_i32 v162, v167, v120, tcr
	ml_addo_u32 {v161, tcr}, v93, v161
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[151:154], v12, s40, #512, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v162, 0, v162, tcr
	ml_addo_u32 {v163, tcr}, s48, v72
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[139:142], v13, noreg, #768, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v164, v167, v119, tcr
	ml_addo_u32 {v163, tcr}, v93, v163
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_store_b32x4  v[155:158], v13, s40, #768, null
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v164, 0, v164, tcr
	ml_addo_u32 {v165, tcr}, s48, v70
	.loc	1 125 20 is_stmt 0              ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v138, v[88:89], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v166, v167, v118, tcr
	ml_addo_u32 {v165, tcr}, v93, v165
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v139, v[159:160], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v166, 0, v166, tcr
	ml_addo_u32 {v0, tcr}, s48, v68
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v140, v[161:162], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, v167, v117, tcr
	ml_addo_u32 {v0, tcr}, v93, v0
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v141, v[163:164], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s48, v66
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v142, v[165:166], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, v167, v115, tcr
	ml_addo_u32 {v2, tcr}, v93, v2
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v144, v[0:1], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, 0, v3, tcr
	ml_addo_u32 {v131, tcr}, s48, v64
	.loc	1 126 30 is_stmt 1              ; biv150_int8_pv.py:126:30
	sl_add_i64 s[48:49], s[4:5], s[84:85]
	.loc	1 126 48 is_stmt 0              ; biv150_int8_pv.py:126:48
	sl_shl_b64 {s[4:5], wcr}, s[28:29], 0xe
	.loc	1 126 30                        ; biv150_int8_pv.py:126:30
	sl_add_i64 s[4:5], s[24:25], s[4:5]
	.loc	1 125 38 is_stmt 1              ; biv150_int8_pv.py:125:38
	ml_addc_i32 v132, v167, v113, tcr
	ml_addo_u32 {v131, tcr}, v93, v131
	ml_addc_i32 v132, 0, v132, tcr
	ml_addo_u32 {v133, tcr}, s34, v54
	.loc	1 125 20 is_stmt 0              ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v131, v[131:132], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v134, v137, v108, tcr
	ml_addo_u32 {v133, tcr}, v93, v133
	ml_addc_i32 v134, 0, v134, tcr
	ml_addo_u32 {v88, tcr}, s34, v62
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v132, v[133:134], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v89, v137, v109, tcr
	ml_addo_u32 {v88, tcr}, v93, v88
	ml_addc_i32 v89, 0, v89, tcr
	ml_addo_u32 {v135, tcr}, s34, v58
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v134, v[88:89], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v136, v137, v106, tcr
	ml_addo_u32 {v135, tcr}, v93, v135
	ml_addc_i32 v136, 0, v136, tcr
	ml_addo_u32 {v143, tcr}, s34, v60
	ml_addc_i32 v1, v137, v104, tcr
	ml_addo_u32 {v0, tcr}, v93, v143
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v143, v[2:3], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s34, v56
	ml_addc_i32 v3, v137, v103, tcr
	ml_addo_u32 {v2, tcr}, v93, v2
	ml_addc_i32 v3, 0, v3, tcr
	ml_addo_u32 {v133, tcr}, s34, v52
	ml_addc_i32 v89, v137, v102, tcr
	ml_addo_u32 {v88, tcr}, v93, v133
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v133, v[135:136], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v89, 0, v89, tcr
	ml_addo_u32 {v135, tcr}, s34, v50
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v136, v[0:1], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, v137, v98, tcr
	ml_addo_u32 {v0, tcr}, v93, v135
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v135, v[2:3], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s34, v48
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v88, v[88:89], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, v137, v94, tcr
	ml_addo_u32 {v2, tcr}, v93, v2
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v0, v[0:1], kop=0
	.loc	1 125 38                        ; biv150_int8_pv.py:125:38
	ml_addc_i32 v3, 0, v3, tcr
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_lsa_load_a64_dword  v1, v[2:3], kop=0
	sl_wait vmcnt(15)
	ml_srl_b32 v2, v138, 0x8
	ml_slb_store_b8  v138, v14, s41, #0, null
	ml_slb_store_b8  v2, v14, s41, #2, null
	ml_srl_b32 v2, v138, 0x10
	ml_slb_store_b8  v2, v14, s41, #4, null
	ml_srl_b32 v2, v138, 0x18
	ml_slb_store_b8  v2, v14, s41, #6, null
	sl_wait vmcnt(14)
	ml_srl_b32 v2, v139, 0x8
	ml_slb_store_b8  v139, v14, s41, #32, null
	ml_slb_store_b8  v2, v14, s41, #34, null
	ml_srl_b32 v2, v139, 0x10
	ml_slb_store_b8  v2, v14, s41, #36, null
	ml_srl_b32 v2, v139, 0x18
	ml_slb_store_b8  v2, v14, s41, #38, null
	sl_wait vmcnt(11)
	ml_srl_b32 v2, v142, 0x8
	ml_slb_store_b8  v142, v14, s41, #128, null
	ml_slb_store_b8  v2, v14, s41, #130, null
	ml_srl_b32 v2, v142, 0x10
	ml_slb_store_b8  v2, v14, s41, #132, null
	ml_srl_b32 v2, v142, 0x18
	ml_slb_store_b8  v2, v14, s41, #134, null
	sl_wait vmcnt(10)
	ml_srl_b32 v2, v144, 0x8
	ml_slb_store_b8  v144, v14, s41, #160, null
	ml_slb_store_b8  v2, v14, s41, #162, null
	ml_srl_b32 v2, v144, 0x10
	ml_slb_store_b8  v2, v14, s41, #164, null
	ml_srl_b32 v2, v144, 0x18
	ml_slb_store_b8  v2, v14, s41, #166, null
	sl_wait vmcnt(8)
	ml_srl_b32 v2, v132, 0x8
	ml_slb_store_b8  v132, v14, s44, #0, null
	ml_slb_store_b8  v2, v14, s44, #2, null
	ml_srl_b32 v2, v132, 0x10
	ml_slb_store_b8  v2, v14, s44, #4, null
	ml_srl_b32 v2, v132, 0x18
	ml_slb_store_b8  v2, v14, s44, #6, null
	sl_wait vmcnt(7)
	ml_srl_b32 v2, v134, 0x8
	ml_slb_store_b8  v134, v14, s44, #32, null
	ml_slb_store_b8  v2, v14, s44, #34, null
	ml_srl_b32 v2, v134, 0x10
	ml_slb_store_b8  v2, v14, s44, #36, null
	ml_srl_b32 v2, v134, 0x18
	ml_slb_store_b8  v2, v14, s44, #38, null
	sl_wait vmcnt(3)
	ml_srl_b32 v2, v135, 0x8
	ml_slb_store_b8  v135, v14, s44, #128, null
	ml_slb_store_b8  v2, v14, s44, #130, null
	ml_srl_b32 v2, v135, 0x10
	ml_slb_store_b8  v2, v14, s44, #132, null
	ml_srl_b32 v2, v135, 0x18
	ml_slb_store_b8  v2, v14, s44, #134, null
	sl_wait vmcnt(2)
	ml_srl_b32 v2, v88, 0x8
	ml_slb_store_b8  v88, v14, s44, #160, null
	ml_slb_store_b8  v2, v14, s44, #162, null
	ml_srl_b32 v2, v88, 0x10
	ml_slb_store_b8  v2, v14, s44, #164, null
	ml_srl_b32 v2, v88, 0x18
	ml_slb_store_b8  v2, v14, s44, #166, null
	ml_srl_b32 v2, v140, 0x8
	ml_slb_store_b8  v140, v15, s41, #0, null
	ml_slb_store_b8  v2, v15, s41, #2, null
	ml_srl_b32 v2, v140, 0x10
	ml_slb_store_b8  v2, v15, s41, #4, null
	ml_srl_b32 v2, v140, 0x18
	ml_slb_store_b8  v2, v15, s41, #6, null
	ml_srl_b32 v2, v141, 0x8
	ml_slb_store_b8  v141, v15, s41, #32, null
	ml_slb_store_b8  v2, v15, s41, #34, null
	ml_srl_b32 v2, v141, 0x10
	ml_slb_store_b8  v2, v15, s41, #36, null
	ml_srl_b32 v2, v141, 0x18
	ml_slb_store_b8  v2, v15, s41, #38, null
	ml_srl_b32 v2, v143, 0x8
	ml_slb_store_b8  v143, v15, s41, #128, null
	ml_slb_store_b8  v2, v15, s41, #130, null
	ml_srl_b32 v2, v143, 0x10
	ml_slb_store_b8  v2, v15, s41, #132, null
	ml_srl_b32 v2, v143, 0x18
	ml_slb_store_b8  v2, v15, s41, #134, null
	ml_srl_b32 v2, v131, 0x8
	ml_slb_store_b8  v131, v15, s41, #160, null
	ml_slb_store_b8  v2, v15, s41, #162, null
	ml_srl_b32 v2, v131, 0x10
	ml_slb_store_b8  v2, v15, s41, #164, null
	ml_srl_b32 v2, v131, 0x18
	ml_slb_store_b8  v2, v15, s41, #166, null
	ml_srl_b32 v2, v133, 0x8
	ml_slb_store_b8  v133, v15, s44, #0, null
	ml_slb_store_b8  v2, v15, s44, #2, null
	ml_srl_b32 v2, v133, 0x10
	ml_slb_store_b8  v2, v15, s44, #4, null
	ml_srl_b32 v2, v133, 0x18
	ml_slb_store_b8  v2, v15, s44, #6, null
	ml_srl_b32 v2, v136, 0x8
	ml_slb_store_b8  v136, v15, s44, #32, null
	ml_slb_store_b8  v2, v15, s44, #34, null
	ml_srl_b32 v2, v136, 0x10
	ml_slb_store_b8  v2, v15, s44, #36, null
	ml_srl_b32 v2, v136, 0x18
	ml_slb_store_b8  v2, v15, s44, #38, null
	sl_wait vmcnt(1)
	ml_srl_b32 v2, v0, 0x8
	ml_slb_store_b8  v0, v15, s44, #128, null
	ml_slb_store_b8  v2, v15, s44, #130, null
	ml_srl_b32 v2, v0, 0x10
	ml_srl_b32 v0, v0, 0x18
	ml_slb_store_b8  v2, v15, s44, #132, null
	ml_slb_store_b8  v0, v15, s44, #134, null
	sl_wait vmcnt(0)
	ml_srl_b32 v0, v1, 0x8
	ml_slb_store_b8  v1, v15, s44, #160, null
	.loc	1 126 30 is_stmt 1              ; biv150_int8_pv.py:126:30
	ml_lsa_load_dword v141, s[48:51], unsigned v87, noreg, #0, ca|mie
	sl_add_i64 s[48:49], s[4:5], s[84:85]
	ml_lsa_load_dword v142, s[48:51], unsigned v87, noreg, #0, ca|mie
	.loc	1 125 20                        ; biv150_int8_pv.py:125:20
	ml_slb_store_b8  v0, v15, s44, #162, null
	ml_srl_b32 v0, v1, 0x10
	ml_slb_store_b8  v0, v15, s44, #164, null
	ml_srl_b32 v0, v1, 0x18
	ml_slb_store_b8  v0, v15, s44, #166, null
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	ml_slb_load_b32x1  v88, v86, noreg, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	ml_mov_b32 v0, 0x0
	ml_mov_b32 v1, v5
	ml_mov_b32 v2, v5
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v89, v16, noreg, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	ml_mov_b32 v3, v5
.Ltmp3:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:134:81 ]
	sl_reg_read s4, hwreg(HW_REG_MODE)
.Ltmp4:
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v86, s40, #0, null
.Ltmp5:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:134:81 ]
	sl_or_b32 {s5, wcr}, s4, 0x3
.Ltmp6:
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v140, v16, s40, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[44:45], v[88:89], v[0:3]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v88, v17, noreg, #0, null
	ml_slb_load_b32x1  v89, v18, noreg, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[44:45], v[139:140], v[0:3]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v17, s40, #0, null
	ml_slb_load_b32x1  v140, v18, s40, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[46:47], v[88:89], v[131:134]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v88, v86, s7, #0, null
	ml_slb_load_b32x1  v89, v16, s7, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[46:47], v[139:140], v[135:138]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v86, s52, #0, null
	ml_slb_load_b32x1  v140, v16, s52, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[40:41], v[88:89], v[131:134]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v88, v17, s7, #0, null
	ml_slb_load_b32x1  v89, v18, s7, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[40:41], v[139:140], v[135:138]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v17, s52, #0, null
	ml_slb_load_b32x1  v140, v18, s52, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[42:43], v[88:89], v[131:134]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v88, v86, s45, #0, null
	ml_slb_load_b32x1  v89, v16, s45, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[42:43], v[139:140], v[135:138]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v86, s53, #0, null
	ml_slb_load_b32x1  v140, v16, s53, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[36:37], v[88:89], v[131:134]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v88, v17, s45, #0, null
	ml_slb_load_b32x1  v89, v18, s45, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[36:37], v[139:140], v[135:138]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v17, s53, #0, null
	ml_slb_load_b32x1  v140, v18, s53, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[38:39], v[88:89], v[131:134]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v88, v86, s47, #0, null
	ml_slb_load_b32x1  v89, v16, s47, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[38:39], v[139:140], v[135:138]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v86, s54, #0, null
	ml_slb_load_b32x1  v140, v16, s54, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[32:33], v[88:89], v[131:134]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v88, v17, s47, #0, null
	ml_slb_load_b32x1  v89, v18, s47, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[32:33], v[139:140], v[135:138]
	.loc	1 124 20                        ; biv150_int8_pv.py:124:20
	ml_slb_load_b32x1  v139, v17, s54, #0, null
	ml_slb_load_b32x1  v140, v18, s54, #0, null
	.loc	1 129 27                        ; biv150_int8_pv.py:129:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[131:134], v[34:35], v[88:89], v[131:134]
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[135:138], v[34:35], v[139:140], v[135:138]
	.loc	1 129 32 is_stmt 0              ; biv150_int8_pv.py:129:32
	ml_mul_f32 v89, s30, v131
	ml_mul_f32 v132, s30, v132
	ml_mul_f32 v131, s30, v135
.Ltmp7:
	.loc	2 192 27 is_stmt 1              ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	ml_max_f32 v88, v89, v131
.Ltmp8:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v133, v88, v6
.Ltmp9:
	.loc	1 129 32                        ; biv150_int8_pv.py:129:32
	ml_mul_f32 v134, s30, v136
.Ltmp10:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	ml_max_f32 v135, v132, v134
.Ltmp11:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v136, v135, v6
.Ltmp12:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v88, v88, v133
.Ltmp13:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v133, v88, v7
.Ltmp14:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v135, v135, v136
.Ltmp15:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v136, v135, v7
.Ltmp16:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v88, v88, v133
.Ltmp17:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v133, v88, v8
.Ltmp18:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v135, v135, v136
.Ltmp19:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v136, v135, v8
.Ltmp20:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v88, v88, v133
.Ltmp21:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v133, v88, v9
.Ltmp22:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v135, v135, v136
.Ltmp23:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:130:57 ]
	ml_slb_shuffle_rtn_b32 v136, v135, v9
.Ltmp24:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v88, v88, v133
.Ltmp25:
	.loc	1 130 42                        ; biv150_int8_pv.py:130:42
	ml_max_f32 v88, v130, v88
	.loc	1 131 44                        ; biv150_int8_pv.py:131:44
	ml_sub_f32 v89, v89, v88
	.loc	1 132 45                        ; biv150_int8_pv.py:132:45
	ml_sub_f32 v130, v130, v88
	.loc	1 131 35                        ; biv150_int8_pv.py:131:35
	ml_exp_f32 v133, v89
	.loc	1 131 44 is_stmt 0              ; biv150_int8_pv.py:131:44
	ml_sub_f32 v89, v131, v88
.Ltmp26:
	.loc	2 192 27 is_stmt 1              ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:130:57 ] ]
	sl_wait lmcnt(0)
	ml_max_f32 v131, v135, v136
.Ltmp27:
	.loc	1 131 35                        ; biv150_int8_pv.py:131:35
	ml_exp_f32 v135, v89
	.loc	1 130 42                        ; biv150_int8_pv.py:130:42
	ml_max_f32 v89, v129, v131
	.loc	1 131 44                        ; biv150_int8_pv.py:131:44
	ml_sub_f32 v131, v132, v89
	ml_sub_f32 v132, v134, v89
	.loc	1 131 35 is_stmt 0              ; biv150_int8_pv.py:131:35
	ml_exp_f32 v131, v131
	.loc	1 132 45 is_stmt 1              ; biv150_int8_pv.py:132:45
	ml_sub_f32 v129, v129, v89
.Ltmp28:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	ml_add_f32 v134, v133, v135
.Ltmp29:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v136, v134, v6
.Ltmp30:
	.loc	1 131 35                        ; biv150_int8_pv.py:131:35
	ml_exp_f32 v132, v132
.Ltmp31:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v133, v141, v133
	ml_mul_f32 v135, v142, v135
.Ltmp32:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	ml_max_f32 v137, v133, v135
.Ltmp33:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v138, v137, v6
.Ltmp34:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v139, v141, v131
	ml_mul_f32 v140, v142, v132
.Ltmp35:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	ml_max_f32 v141, v139, v140
.Ltmp36:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v142, v141, v6
.Ltmp37:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	ml_add_f32 v131, v131, v132
.Ltmp38:
	.loc	1 132 31                        ; biv150_int8_pv.py:132:31
	ml_exp_f32 v161, v130
.Ltmp39:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v132, v131, v6
.Ltmp40:
	.loc	1 132 31                        ; biv150_int8_pv.py:132:31
	ml_exp_f32 v162, v129
.Ltmp41:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v134, v134, v136
.Ltmp42:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v136, v134, v7
.Ltmp43:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v137, v137, v138
.Ltmp44:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v138, v137, v7
.Ltmp45:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v141, v141, v142
.Ltmp46:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v142, v141, v7
.Ltmp47:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v131, v131, v132
.Ltmp48:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v132, v131, v7
.Ltmp49:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v134, v134, v136
.Ltmp50:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v136, v134, v8
.Ltmp51:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v137, v137, v138
.Ltmp52:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v138, v137, v8
.Ltmp53:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v141, v141, v142
.Ltmp54:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v142, v141, v8
.Ltmp55:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v131, v131, v132
.Ltmp56:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v132, v131, v8
.Ltmp57:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v134, v134, v136
.Ltmp58:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v136, v134, v9
.Ltmp59:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v137, v137, v138
.Ltmp60:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v138, v137, v9
.Ltmp61:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v141, v141, v142
.Ltmp62:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ]
	ml_slb_shuffle_rtn_b32 v142, v141, v9
.Ltmp63:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v130, v131, v132
.Ltmp64:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:133:66 ]
	ml_slb_shuffle_rtn_b32 v131, v130, v9
.Ltmp65:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v129, v134, v136
.Ltmp66:
	.loc	1 133 46                        ; biv150_int8_pv.py:133:46
	ml_fma_f32 v49, v49, v161, v129
.Ltmp67:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(2)
	ml_max_f32 v132, v137, v138
.Ltmp68:
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v132, v132, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v163, v132, 0x3c010204
	.loc	1 17 58 is_stmt 1               ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_xor_b32 v129, v163, 0x80000000
.Ltmp69:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:134:81 ] ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v132, v141, v142
.Ltmp70:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_rcp_f32 v134, v163
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v132, v132, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v164, v132, 0x3c010204
.Ltmp71:
	.loc	2 285 15 is_stmt 1              ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:133:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v130, v130, v131
.Ltmp72:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_rcp_f32 v131, v164
.Ltmp73:
	.loc	1 133 46                        ; biv150_int8_pv.py:133:46
	ml_fma_f32 v51, v51, v162, v130
.Ltmp74:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_xor_b32 v130, v164, 0x80000000
	ml_mul_f32 v132, v133, v134
	ml_mul_f32 v137, v135, v134
	ml_fma_f32 v133, v129, v132, v133
	ml_mul_f32 v136, v139, v131
	ml_fma_f32 v129, v129, v137, v135
	ml_mul_f32 v135, v140, v131
	ml_fma_f32 v138, v130, v136, v139
	ml_fma_f32 v130, v130, v135, v140
	ml_fma_f32 v133, v133, v134, v132
	ml_fma_f32 v129, v129, v134, v137
	ml_fma_f32 v134, v138, v131, v136
	ml_fma_f32 v130, v130, v131, v135
	ml_cmp_class_f32 tcr, v132, v19
	ml_csel_b32 v131, v132, v133, tcr
	.loc	1 17 72 is_stmt 0               ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v131, v131, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_cmp_class_f32 tcr, v136, v19
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v131, v131
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_csel_b32 v132, v136, v134, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v132, v132, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_cmp_class_f32 tcr, v137, v19
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v132, v132
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_csel_b32 v129, v137, v129, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v129, v129, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_cmp_class_f32 tcr, v135, v19
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v129, v129
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:134:81 ]
	ml_csel_b32 v130, v135, v130, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:134:81 ]
	ml_add_f32 v130, v130, 0x3f000000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v131, v131, 0x0
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:134:81 ]
	ml_floor_f32 v130, v130
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v132, v132, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:134:81 ]
	ml_min_f32 v131, v131, 0x42fe0000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v129, v129, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:134:81 ]
	ml_min_f32 v132, v132, 0x42fe0000
	ml_min_f32 v129, v129, 0x42fe0000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:134:81 ]
	ml_max_f32 v130, v130, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:134:81 ]
	ml_min_f32 v130, v130, 0x42fe0000
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:134:81 ]
	sl_reg_write hwreg(HW_REG_MODE), s5
	ml_cvt_i32_f32  v131, v131
	sl_reg_write hwreg(HW_REG_MODE), s4
	sl_reg_read s4, hwreg(HW_REG_MODE)
	sl_or_b32 {s5, wcr}, s4, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s5
	ml_cvt_i32_f32  v132, v132
	sl_reg_write hwreg(HW_REG_MODE), s4
	sl_reg_read s4, hwreg(HW_REG_MODE)
	sl_or_b32 {s5, wcr}, s4, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s5
	ml_cvt_i32_f32  v129, v129
	sl_reg_write hwreg(HW_REG_MODE), s4
	sl_reg_read s4, hwreg(HW_REG_MODE)
	sl_or_b32 {s5, wcr}, s4, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s5
	ml_cvt_i32_f32  v130, v130
	sl_reg_write hwreg(HW_REG_MODE), s4
	sl_barrier 
	ml_slb_store_b8  v131, v20, noreg, #0, null
	ml_slb_store_b8  v132, v20, noreg, #16, null
	ml_slb_store_b8  v129, v20, noreg, #128, null
	ml_slb_store_b8  v130, v20, noreg, #144, null
	sl_wait lmcnt(0)
	sl_barrier 
	.loc	1 19 25 is_stmt 1               ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v129, v21, noreg, #128, null
.Ltmp75:
	.loc	1 136 20                        ; biv150_int8_pv.py:136:20
	sl_add_i32 s60, s60, 0x20
	.loc	1 107 21                        ; biv150_int8_pv.py:107:21
	sl_cmp_lt_i32 wcr, s60, s50
.Ltmp76:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v130, v21, noreg, #129, null
	ml_slb_load_b8  v131, v21, noreg, #136, null
	ml_slb_load_b8  v132, v21, noreg, #137, null
	ml_slb_load_b8  v133, v21, noreg, #0, null
	ml_slb_load_b8  v134, v21, noreg, #1, null
	ml_slb_load_b8  v135, v21, noreg, #8, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v130, v129, 4
	ml_slb_load_b8  v136, v21, noreg, #9, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v131, v129, s38
	ml_slb_load_b8  v137, v83, s44, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v158, v132, v129, s39
	ml_slb_load_b8  v138, v83, s44, #1, null
	ml_slb_load_b8  v139, v83, s44, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v134, v133, 4
	ml_slb_load_b8  v140, v83, s44, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v135, v129, s38
	ml_slb_load_b8  v141, v83, s41, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v157, v136, v129, s39
	ml_slb_load_b8  v142, v83, s41, #1, null
	ml_slb_load_b8  v143, v83, s41, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v138, v137, 4
	ml_slb_load_b8  v144, v83, s41, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v139, v129, s38
	ml_slb_load_b8  v145, v82, s44, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v134, v140, v129, s39
	ml_slb_load_b8  v146, v82, s44, #257, null
	ml_slb_load_b8  v147, v82, s44, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v142, v141, 4
	ml_slb_load_b8  v148, v82, s44, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v143, v129, s38
	ml_slb_load_b8  v149, v82, s41, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v133, v144, v129, s39
	ml_slb_load_b8  v150, v82, s41, #257, null
	ml_slb_load_b8  v151, v82, s41, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v146, v145, 4
	ml_slb_load_b8  v152, v82, s41, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v147, v129, s38
	ml_slb_load_b8  v153, v83, s44, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v138, v148, v129, s39
	ml_slb_load_b8  v154, v83, s44, #513, null
	ml_slb_load_b8  v155, v83, s44, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v150, v149, 4
	ml_slb_load_b8  v156, v83, s44, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v151, v129, s38
	ml_slb_load_b8  v159, v83, s41, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v137, v152, v129, s39
	ml_slb_load_b8  v160, v83, s41, #513, null
	ml_slb_load_b8  v165, v83, s41, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v154, v153, 4
	ml_slb_load_b8  v166, v83, s41, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v129, v155, v129, s38
	ml_slb_load_b8  v167, v82, s44, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v142, v156, v129, s39
	ml_matrix_mad_i32_i8_m16n16k32 v[129:132], v[157:158], v[133:134], v[0:3]
	ml_slb_load_b8  v168, v82, s44, #769, null
	ml_slb_load_b8  v169, v82, s44, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v133, v160, v159, 4
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v129, v129
	ml_cvt_f32_i32  v130, v130
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v170, v82, s44, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v133, v165, v133, s38
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v131, v131
	ml_cvt_f32_i32  v132, v132
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v171, v82, s41, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v141, v166, v133, s39
	ml_matrix_mad_i32_i8_m16n16k32 v[133:136], v[157:158], v[137:138], v[0:3]
	ml_slb_load_b8  v172, v82, s41, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[137:140], v[157:158], v[141:142], v[0:3]
	ml_slb_load_b8  v173, v82, s41, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v141, v168, v167, 4
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v133, v133
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v174, v82, s41, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v141, v169, v141, s38
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v134, v134
	ml_cvt_f32_i32  v135, v135
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v175, v83, s55, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v146, v170, v141, s39
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v136, v136
	ml_cvt_f32_i32  v137, v137
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v176, v83, s55, #1, null
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v138, v138
	ml_cvt_f32_i32  v139, v139
	ml_cvt_f32_i32  v140, v140
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v177, v83, s55, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v141, v172, v171, 4
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v129, v163, v129
	ml_mul_f32 v131, v163, v131
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v178, v83, s55, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v141, v173, v141, s38
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v133, v163, v133
	ml_mul_f32 v135, v163, v135
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v147, v83, s56, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v145, v174, v141, s39
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v137, v163, v137
	ml_mul_f32 v139, v163, v139
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v148, v83, s56, #1, null
	ml_matrix_mad_i32_i8_m16n16k32 v[141:144], v[157:158], v[145:146], v[0:3]
	ml_slb_load_b8  v179, v83, s56, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v145, v176, v175, 4
.Ltmp77:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v22, v22, v161, v129
	ml_fma_f32 v53, v53, v161, v131
.Ltmp78:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v180, v83, s56, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v145, v177, v145, s38
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v141, v141
	ml_cvt_f32_i32  v142, v142
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v151, v82, s55, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v150, v178, v145, s39
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v143, v143
	ml_cvt_f32_i32  v144, v144
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v152, v82, s55, #257, null
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v141, v163, v141
	ml_mul_f32 v143, v163, v143
.Ltmp79:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v24, v24, v161, v133
.Ltmp80:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v181, v82, s55, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v145, v148, v147, 4
.Ltmp81:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v81, v81, v161, v135
	ml_fma_f32 v26, v26, v161, v137
.Ltmp82:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v182, v82, s55, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v145, v179, v145, s38
.Ltmp83:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v79, v79, v161, v139
	ml_fma_f32 v28, v28, v161, v141
.Ltmp84:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v153, v82, s56, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v149, v180, v145, s39
.Ltmp85:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v75, v75, v161, v143
.Ltmp86:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v129, v164, v134
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v155, v82, s56, #257, null
	ml_matrix_mad_i32_i8_m16n16k32 v[145:148], v[157:158], v[149:150], v[0:3]
	ml_slb_load_b8  v156, v82, s56, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v149, v152, v151, 4
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v131, v164, v138
	ml_mul_f32 v133, v164, v142
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v183, v82, s56, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v149, v181, v149, s38
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v145, v145
	ml_cvt_f32_i32  v146, v146
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v159, v83, s55, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v154, v182, v149, s39
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v147, v147
	ml_cvt_f32_i32  v148, v148
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v160, v83, s55, #513, null
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v145, v163, v145
	ml_mul_f32 v147, v163, v147
.Ltmp87:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v30, v30, v161, v145
.Ltmp88:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v165, v83, s55, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v149, v155, v153, 4
.Ltmp89:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v71, v71, v161, v147
.Ltmp90:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v134, v164, v144
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v166, v83, s55, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v149, v156, v149, s38
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v135, v164, v146
.Ltmp91:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v25, v25, v162, v129
.Ltmp92:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v167, v83, s56, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v153, v183, v149, s39
.Ltmp93:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v27, v27, v162, v131
	ml_fma_f32 v29, v29, v162, v133
.Ltmp94:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v168, v83, s56, #513, null
	ml_matrix_mad_i32_i8_m16n16k32 v[149:152], v[157:158], v[153:154], v[0:3]
	ml_slb_load_b8  v169, v83, s56, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v153, v160, v159, 4
.Ltmp95:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v69, v69, v162, v134
	ml_fma_f32 v31, v31, v162, v135
.Ltmp96:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v170, v83, s56, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v153, v165, v153, s38
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v149, v149
	ml_cvt_f32_i32  v150, v150
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v171, v82, s55, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v160, v166, v153, s39
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v151, v151
	ml_cvt_f32_i32  v152, v152
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v172, v82, s55, #769, null
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v149, v163, v149
	ml_mul_f32 v151, v163, v151
.Ltmp97:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v123, v123, v161, v149
.Ltmp98:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v173, v82, s55, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v154, v168, v167, 4
.Ltmp99:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v67, v67, v161, v151
.Ltmp100:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v137, v164, v150
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v174, v82, s55, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v153, v169, v154, s38
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v138, v164, v152
.Ltmp101:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v124, v124, v162, v137
.Ltmp102:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v175, v82, s56, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v159, v170, v153, s39
.Ltmp103:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v61, v61, v162, v138
.Ltmp104:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	ml_slb_load_b8  v176, v82, s56, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[153:156], v[157:158], v[159:160], v[0:3]
	ml_slb_load_b8  v165, v82, s56, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v159, v172, v171, 4
	ml_slb_load_b8  v166, v82, s56, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v159, v173, v159, s38
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v153, v153
	ml_cvt_f32_i32  v154, v154
	ml_cvt_f32_i32  v155, v155
	ml_cvt_f32_i32  v156, v156
	.loc	1 20 34 is_stmt 0               ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v153, v163, v153
	ml_mul_f32 v155, v163, v155
.Ltmp105:
	.loc	1 134 55 is_stmt 1              ; biv150_int8_pv.py:134:55
	ml_fma_f32 v125, v125, v161, v153
	ml_fma_f32 v63, v63, v161, v155
.Ltmp106:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v139, v164, v154
.Ltmp107:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v126, v126, v162, v139
.Ltmp108:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:134:81 ]
	sl_wait lmcnt(2)
	ml_byte_permute_b32 v160, v176, v175, 4
	sl_wait lmcnt(1)
	ml_byte_permute_b32 v165, v165, v160, s38
	ml_byte_permute_b32 v160, v174, v159, s39
	sl_wait lmcnt(0)
	ml_byte_permute_b32 v159, v166, v165, s39
	ml_matrix_mad_i32_i8_m16n16k32 v[0:3], v[157:158], v[159:160], v[0:3]
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:134:81 ]
	ml_cvt_f32_i32  v0, v0
	ml_cvt_f32_i32  v1, v1
	ml_cvt_f32_i32  v2, v2
	ml_cvt_f32_i32  v3, v3
	.loc	1 20 34 is_stmt 0               ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v0, v163, v0
	ml_mul_f32 v2, v163, v2
.Ltmp109:
	.loc	1 134 55 is_stmt 1              ; biv150_int8_pv.py:134:55
	ml_fma_f32 v127, v127, v161, v0
	ml_fma_f32 v57, v57, v161, v2
.Ltmp110:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:134:81 ]
	ml_mul_f32 v0, v164, v130
	ml_mul_f32 v2, v164, v132
	ml_mul_f32 v130, v164, v136
	ml_mul_f32 v132, v164, v140
	ml_mul_f32 v136, v164, v148
	ml_mul_f32 v140, v164, v156
	ml_mul_f32 v1, v164, v1
	ml_mul_f32 v3, v164, v3
.Ltmp111:
	.loc	1 134 55                        ; biv150_int8_pv.py:134:55
	ml_fma_f32 v23, v23, v162, v0
	ml_fma_f32 v80, v80, v162, v2
	ml_fma_f32 v77, v77, v162, v130
	ml_fma_f32 v73, v73, v162, v132
	ml_fma_f32 v65, v65, v162, v136
	ml_fma_f32 v55, v55, v162, v140
	ml_fma_f32 v128, v128, v162, v1
	ml_fma_f32 v59, v59, v162, v3
	sl_cbr_wcrnz BB0_3, wcr
BB0_4:                                  ; %._crit_edge
	.loc	1 138 20                        ; biv150_int8_pv.py:138:20
	ml_mov_s2v_b32 v184, s12, 0x0
	ml_mov_s2v_b32 v184, s13, 0x1
	ml_mov_s2v_b32 v184, s14, 0x2
	ml_mov_s2v_b32 v184, s15, 0x3
	ml_mov_s2v_b32 v184, s16, 0x4
	ml_mov_s2v_b32 v184, s17, 0x5
	ml_mov_s2v_b32 v184, s18, 0x6
	ml_mov_s2v_b32 v184, s19, 0x7
	ml_mov_s2v_b32 v184, s20, 0x8
	ml_mov_s2v_b32 v184, s21, 0x9
	ml_mov_s2v_b32 v184, s22, 0xa
	ml_mov_s2v_b32 v184, s23, 0xb
	ml_mov_s2v_b32 v184, s24, 0xc
	ml_mov_s2v_b32 v184, s25, 0xd
	ml_mov_s2v_b32 v184, s26, 0xe
	ml_mov_s2v_b32 v184, s27, 0xf
	sl_cmp_lt_i32 wcr, s50, s46
	sl_cbr_wcrz BB0_106, wcr
; %bb.5:
	.loc	1 140 56                        ; biv150_int8_pv.py:140:56
	sl_sra_b32 {s4, wcr}, s50, 0x4
	.loc	1 140 42 is_stmt 0              ; biv150_int8_pv.py:140:42
	sl_sra_b32 {s5, wcr}, s4, 0x1f
	sl_mov_b32 s7, 0xffffffff
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x2
	sl_add_i64 s[4:5], s[2:3], s[4:5]
	.loc	1 140 24                        ; biv150_int8_pv.py:140:24
	ml_lsa_load_dword v0, s[4:7], noreg, noreg, #0, ca
	.loc	1 142 40 is_stmt 1              ; biv150_int8_pv.py:142:40
	sl_add_i32 s3, s50, 0x10
	sl_mov_b32 s28, 0x0
	.loc	1 142 52 is_stmt 0              ; biv150_int8_pv.py:142:52
	sl_cmp_lt_i32 wcr, s3, s46
	sl_mov_b32 s22, 0x0
	.loc	1 140 24 is_stmt 1              ; biv150_int8_pv.py:140:24
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s40, v0, 0x0
	.loc	1 141 24                        ; biv150_int8_pv.py:141:24
	sl_cbr_wcrz BB0_7, wcr
; %bb.6:
	ml_lsa_load_dword v0, s[4:7], noreg, noreg, #4, ca
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s22, v0, 0x0
BB0_7:
	.loc	1 140 70                        ; biv150_int8_pv.py:140:70
	sl_sra_b32 {s41, wcr}, s40, 0x1f
	.loc	1 142 70                        ; biv150_int8_pv.py:142:70
	sl_sra_b32 {s23, wcr}, s22, 0x1f
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0x1
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_sub_bi_u32 s2, s10, s10, wcr
	.loc	1 146 28 is_stmt 1              ; biv150_int8_pv.py:146:28
	sl_mull_u32 s7, s36, s41
	sl_mul_u64_u32 s[4:5], s36, s40
	sl_add_i32 s5, s5, s7
	sl_mull_u32 s7, s37, s40
	sl_add_i32 s5, s5, s7
	sl_mull_u32 s7, s36, s23
	sl_mul_u64_u32 s[34:35], s36, s22
	sl_add_i32 s7, s35, s7
	sl_mull_u32 s29, s37, s22
	sl_add_i32 s35, s7, s29
	.loc	1 157 36                        ; biv150_int8_pv.py:157:36
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x1
	ml_mov_v2s_b32 s52, v184, 0x0
	ml_mov_v2s_b32 s53, v184, 0x1
	ml_mov_v2s_b32 s54, v184, 0x2
	ml_mov_v2s_b32 s55, v184, 0x3
	ml_mov_v2s_b32 s56, v184, 0x4
	ml_mov_v2s_b32 s57, v184, 0x5
	ml_mov_v2s_b32 s58, v184, 0x6
	ml_mov_v2s_b32 s59, v184, 0x7
	ml_mov_v2s_b32 s60, v184, 0x8
	ml_mov_v2s_b32 s61, v184, 0x9
	ml_mov_v2s_b32 s62, v184, 0xa
	ml_mov_v2s_b32 s63, v184, 0xb
	ml_mov_v2s_b32 s64, v184, 0xc
	ml_mov_v2s_b32 s65, v184, 0xd
	ml_mov_v2s_b32 s66, v184, 0xe
	ml_mov_v2s_b32 s67, v184, 0xf
	sl_shl_b64 {s[36:37], wcr}, s[76:77], 0x1
	sl_shl_b64 {s[38:39], wcr}, s[32:33], 0x1
	sl_mov_b64 s[64:65], s[60:61]
	sl_add_i64 s[4:5], s[64:65], s[4:5]
	sl_add_i64 s[68:69], s[4:5], s[38:39]
	sl_add_i64 s[60:61], s[68:69], s[36:37]
	sl_add_i64 s[56:57], s[60:61], s[76:77]
	sl_add_i64 s[52:53], s[56:57], s[76:77]
	sl_add_i64 s[48:49], s[52:53], s[76:77]
	sl_add_i64 s[44:45], s[48:49], s[76:77]
	sl_add_i64 s[4:5], s[44:45], s[76:77]
	sl_add_i64 s[36:37], s[4:5], s[76:77]
	sl_add_i64 s[32:33], s[36:37], s[76:77]
	sl_add_i64 s[88:89], s[32:33], s[76:77]
	sl_add_i64 s[12:13], s[88:89], s[76:77]
	sl_add_i64 s[80:81], s[12:13], s[76:77]
	sl_add_i64 s[20:21], s[80:81], s[76:77]
	sl_mov_b64 s[16:17], s[20:21]
	ml_mov_s2v_b32 v184, s16, 0x10
	ml_mov_s2v_b32 v184, s17, 0x11
	ml_mov_s2v_b32 v184, s18, 0x12
	ml_mov_s2v_b32 v184, s19, 0x13
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_mov_b64 s[16:17], s[20:21]
	ml_mov_s2v_b32 v184, s16, 0x14
	ml_mov_s2v_b32 v184, s17, 0x15
	ml_mov_s2v_b32 v184, s18, 0x16
	ml_mov_s2v_b32 v184, s19, 0x17
	sl_add_i64 s[16:17], s[20:21], s[76:77]
	ml_mov_s2v_b32 v184, s16, 0x18
	ml_mov_s2v_b32 v184, s17, 0x19
	ml_mov_s2v_b32 v184, s18, 0x1a
	ml_mov_s2v_b32 v184, s19, 0x1b
	sl_shl_b64 {s[34:35], wcr}, s[34:35], 0x1
	sl_add_i64 s[20:21], s[64:65], s[34:35]
	sl_add_i64 s[64:65], s[20:21], s[38:39]
	sl_add_i64 s[20:21], s[64:65], s[76:77]
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	.loc	1 157 20 is_stmt 0              ; biv150_int8_pv.py:157:20
	sl_mov_b32 s71, 0xfff00004
	ml_lsa_blkload_x1 v0, s[68:71], noreg, noreg, #0, ca
	.loc	1 157 36                        ; biv150_int8_pv.py:157:36
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_mov_b64 s[16:17], s[20:21]
	ml_mov_s2v_b32 v184, s16, 0x1c
	ml_mov_s2v_b32 v184, s17, 0x1d
	ml_mov_s2v_b32 v184, s18, 0x1e
	ml_mov_s2v_b32 v184, s19, 0x1f
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_mov_b64 s[16:17], s[20:21]
	ml_mov_s2v_b32 v184, s16, 0x20
	ml_mov_s2v_b32 v184, s17, 0x21
	ml_mov_s2v_b32 v184, s18, 0x22
	ml_mov_s2v_b32 v184, s19, 0x23
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_mov_b64 s[16:17], s[20:21]
	ml_mov_s2v_b32 v184, s16, 0x24
	ml_mov_s2v_b32 v184, s17, 0x25
	ml_mov_s2v_b32 v184, s18, 0x26
	ml_mov_s2v_b32 v184, s19, 0x27
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_mov_b64 s[16:17], s[20:21]
	ml_mov_s2v_b32 v184, s16, 0x28
	ml_mov_s2v_b32 v184, s17, 0x29
	ml_mov_s2v_b32 v184, s18, 0x2a
	ml_mov_s2v_b32 v184, s19, 0x2b
	sl_add_i64 s[20:21], s[20:21], s[76:77]
	sl_mov_b64 s[16:17], s[20:21]
	ml_mov_s2v_b32 v184, s16, 0x2c
	ml_mov_s2v_b32 v184, s17, 0x2d
	ml_mov_s2v_b32 v184, s18, 0x2e
	ml_mov_s2v_b32 v184, s19, 0x2f
	sl_add_i64 s[24:25], s[20:21], s[76:77]
	sl_add_i64 s[20:21], s[24:25], s[76:77]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_mov_b32 v1, 0x0
	sl_or_b32 {s2, wcr}, s2, 0x0
	sl_mov_b64 s[16:17], s[20:21]
	.loc	1 157 36                        ; biv150_int8_pv.py:157:36
	sl_add_i64 s[28:29], s[20:21], s[76:77]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_cbr_wcrz BB0_9, wcr
; %bb.8:
	sl_add_i64 s[68:69], s[68:69], s[76:77]
	ml_lsa_blkload_x1 v1, s[68:71], noreg, noreg, #0, ca
BB0_9:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0x2
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v2, 0x0
	sl_cbr_wcrz BB0_11, wcr
; %bb.10:
	sl_mov_b32 s63, 0xfff00004
	ml_lsa_blkload_x1 v2, s[60:63], noreg, noreg, #0, ca
BB0_11:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s7, s50, 0x3
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s7, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v3, 0x0
	sl_cbr_wcrz BB0_13, wcr
; %bb.12:
	sl_mov_b32 s59, 0xfff00004
	ml_lsa_blkload_x1 v3, s[56:59], noreg, noreg, #0, ca
BB0_13:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0x4
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v4, 0x0
	sl_cbr_wcrz BB0_15, wcr
; %bb.14:
	sl_mov_b32 s55, 0xfff00004
	ml_lsa_blkload_x1 v4, s[52:55], noreg, noreg, #0, ca
BB0_15:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s7, s50, 0x5
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s7, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v5, 0x0
	sl_cbr_wcrz BB0_17, wcr
; %bb.16:
	sl_mov_b32 s51, 0xfff00004
	ml_lsa_blkload_x1 v5, s[48:51], noreg, noreg, #0, ca
BB0_17:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0x6
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v6, 0x0
	sl_cbr_wcrz BB0_19, wcr
; %bb.18:
	sl_mov_b32 s47, 0xfff00004
	ml_lsa_blkload_x1 v6, s[44:47], noreg, noreg, #0, ca
BB0_19:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s7, s50, 0x7
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s7, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v7, 0x0
	sl_cbr_wcrz BB0_21, wcr
; %bb.20:
	sl_mov_b32 s7, 0xfff00004
	ml_lsa_blkload_x1 v7, s[4:7], noreg, noreg, #0, ca
BB0_21:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0x8
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v8, 0x0
	sl_cbr_wcrz BB0_23, wcr
; %bb.22:
	sl_mov_b32 s39, 0xfff00004
	ml_lsa_blkload_x1 v8, s[36:39], noreg, noreg, #0, ca
BB0_23:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s4, s50, 0x9
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s4, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v9, 0x0
	sl_cbr_wcrz BB0_25, wcr
; %bb.24:
	sl_mov_b32 s35, 0xfff00004
	ml_lsa_blkload_x1 v9, s[32:35], noreg, noreg, #0, ca
BB0_25:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0xa
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v10, 0x0
	sl_cbr_wcrz BB0_27, wcr
; %bb.26:
	sl_mov_b32 s91, 0xfff00004
	ml_lsa_blkload_x1 v10, s[88:91], noreg, noreg, #0, ca
BB0_27:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s4, s50, 0xb
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s4, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v11, 0x0
	sl_cbr_wcrz BB0_29, wcr
; %bb.28:
	sl_mov_b32 s15, 0xfff00004
	ml_lsa_blkload_x1 v11, s[12:15], noreg, noreg, #0, ca
BB0_29:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0xc
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v12, 0x0
	sl_cbr_wcrz BB0_31, wcr
; %bb.30:
	sl_mov_b32 s83, 0xfff00004
	ml_lsa_blkload_x1 v12, s[80:83], noreg, noreg, #0, ca
BB0_31:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s4, s50, 0xd
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s4, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v13, 0x0
	sl_cbr_wcrz BB0_33, wcr
; %bb.32:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s12, v184, 0x10
	ml_mov_v2s_b32 s13, v184, 0x11
	ml_mov_v2s_b32 s14, v184, 0x12
	ml_mov_v2s_b32 s15, v184, 0x13
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s7, 0xfff00004
	sl_mov_b64 s[4:5], s[12:13]
	ml_lsa_blkload_x1 v13, s[4:7], noreg, noreg, #0, ca
BB0_33:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0xe
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v14, 0x0
	sl_cbr_wcrz BB0_35, wcr
; %bb.34:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s12, v184, 0x14
	ml_mov_v2s_b32 s13, v184, 0x15
	ml_mov_v2s_b32 s14, v184, 0x16
	ml_mov_v2s_b32 s15, v184, 0x17
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s7, 0xfff00004
	sl_mov_b64 s[4:5], s[12:13]
	ml_lsa_blkload_x1 v14, s[4:7], noreg, noreg, #0, ca
BB0_35:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s4, s50, 0xf
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s4, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v15, 0x0
	sl_cbr_wcrz BB0_37, wcr
; %bb.36:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s12, v184, 0x18
	ml_mov_v2s_b32 s13, v184, 0x19
	ml_mov_v2s_b32 s14, v184, 0x1a
	ml_mov_v2s_b32 s15, v184, 0x1b
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s7, 0xfff00004
	sl_mov_b64 s[4:5], s[12:13]
	ml_lsa_blkload_x1 v15, s[4:7], noreg, noreg, #0, ca
BB0_37:
	.loc	1 142 52 is_stmt 1              ; biv150_int8_pv.py:142:52
	sl_cmp_lt_i32 wcr, s3, s46
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_mov_b32 v16, 0x0
	sl_cbr_wcrz BB0_39, wcr
; %bb.38:
	sl_mov_b32 s67, 0xfff00004
	ml_lsa_blkload_x1 v16, s[64:67], noreg, noreg, #0, ca
BB0_39:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s3, s50, 0x11
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s3, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v17, 0x0
	sl_cbr_wcrz BB0_41, wcr
; %bb.40:
	sl_add_i64 s[4:5], s[64:65], s[76:77]
	sl_mov_b32 s7, 0xfff00004
	ml_lsa_blkload_x1 v17, s[4:7], noreg, noreg, #0, ca
BB0_41:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0x12
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v18, 0x0
	sl_cbr_wcrz BB0_43, wcr
; %bb.42:
	sl_add_i64 s[4:5], s[64:65], s[74:75]
	sl_mov_b32 s7, 0xfff00004
	ml_lsa_blkload_x1 v18, s[4:7], noreg, noreg, #0, ca
BB0_43:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s3, s50, 0x13
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s3, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v19, 0x0
	sl_cbr_wcrz BB0_45, wcr
; %bb.44:
	sl_add_i64 s[4:5], s[64:65], s[72:73]
	sl_mov_b32 s7, 0xfff00004
	ml_lsa_blkload_x1 v19, s[4:7], noreg, noreg, #0, ca
BB0_45:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s2, s50, 0x14
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s2, s46
	sl_mov_b32 s2, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v20, 0x0
	sl_cbr_wcrz BB0_47, wcr
; %bb.46:
	sl_add_i64 s[4:5], s[64:65], s[8:9]
	sl_mov_b32 s7, 0xfff00004
	ml_lsa_blkload_x1 v20, s[4:7], noreg, noreg, #0, ca
BB0_47:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s3, s50, 0x15
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s3, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v21, 0x0
	sl_cbr_wcrz BB0_49, wcr
; %bb.48:
	sl_add_i64 s[0:1], s[64:65], s[0:1]
	sl_mov_b32 s3, 0xfff00004
	ml_lsa_blkload_x1 v21, s[0:3], noreg, noreg, #0, ca
BB0_49:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s0, s50, 0x16
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s0, s46
	sl_mov_b32 s0, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v22, 0x0
	sl_cbr_wcrz BB0_51, wcr
; %bb.50:
	sl_add_i64 s[4:5], s[64:65], s[92:93]
	sl_mov_b32 s7, 0xfff00004
	ml_lsa_blkload_x1 v22, s[4:7], noreg, noreg, #0, ca
BB0_51:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s1, s50, 0x17
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s1, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v23, 0x0
	sl_cbr_wcrz BB0_53, wcr
; %bb.52:
	sl_add_i64 s[0:1], s[64:65], s[26:27]
	sl_mov_b32 s3, 0xfff00004
	ml_lsa_blkload_x1 v23, s[0:3], noreg, noreg, #0, ca
BB0_53:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s0, s50, 0x18
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s0, s46
	sl_mov_b32 s0, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v24, 0x0
	sl_cbr_wcrz BB0_55, wcr
; %bb.54:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s12, v184, 0x1c
	ml_mov_v2s_b32 s13, v184, 0x1d
	ml_mov_v2s_b32 s14, v184, 0x1e
	ml_mov_v2s_b32 s15, v184, 0x1f
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s7, 0xfff00004
	sl_mov_b64 s[4:5], s[12:13]
	ml_lsa_blkload_x1 v24, s[4:7], noreg, noreg, #0, ca
BB0_55:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s1, s50, 0x19
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s1, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v25, 0x0
	sl_cbr_wcrz BB0_57, wcr
; %bb.56:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s0, v184, 0x20
	ml_mov_v2s_b32 s1, v184, 0x21
	ml_mov_v2s_b32 s2, v184, 0x22
	ml_mov_v2s_b32 s3, v184, 0x23
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s3, 0xfff00004
	ml_lsa_blkload_x1 v25, s[0:3], noreg, noreg, #0, ca
BB0_57:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s0, s50, 0x1a
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s0, s46
	sl_mov_b32 s0, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v26, 0x0
	sl_cbr_wcrz BB0_59, wcr
; %bb.58:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s12, v184, 0x24
	ml_mov_v2s_b32 s13, v184, 0x25
	ml_mov_v2s_b32 s14, v184, 0x26
	ml_mov_v2s_b32 s15, v184, 0x27
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s7, 0xfff00004
	sl_mov_b64 s[4:5], s[12:13]
	ml_lsa_blkload_x1 v26, s[4:7], noreg, noreg, #0, ca
BB0_59:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s1, s50, 0x1b
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s1, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v27, 0x0
	sl_cbr_wcrz BB0_61, wcr
; %bb.60:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s0, v184, 0x28
	ml_mov_v2s_b32 s1, v184, 0x29
	ml_mov_v2s_b32 s2, v184, 0x2a
	ml_mov_v2s_b32 s3, v184, 0x2b
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s3, 0xfff00004
	ml_lsa_blkload_x1 v27, s[0:3], noreg, noreg, #0, ca
BB0_61:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s0, s50, 0x1c
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s0, s46
	sl_mov_b32 s0, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v28, 0x0
	sl_cbr_wcrz BB0_63, wcr
; %bb.62:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	ml_mov_v2s_b32 s12, v184, 0x2c
	ml_mov_v2s_b32 s13, v184, 0x2d
	ml_mov_v2s_b32 s14, v184, 0x2e
	ml_mov_v2s_b32 s15, v184, 0x2f
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s7, 0xfff00004
	sl_mov_b64 s[4:5], s[12:13]
	ml_lsa_blkload_x1 v28, s[4:7], noreg, noreg, #0, ca
BB0_63:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s1, s50, 0x1d
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s1, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v29, 0x0
	sl_cbr_wcrz BB0_65, wcr
; %bb.64:
	sl_mov_b32 s27, 0xfff00004
	ml_lsa_blkload_x1 v29, s[24:27], noreg, noreg, #0, ca
BB0_65:
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	sl_add_i32 s0, s50, 0x1e
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s0, s46
	sl_mov_b32 s0, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v30, 0x0
	sl_cbr_wcrz BB0_67, wcr
; %bb.66:
	.loc	1 0 20 is_stmt 0                ; biv150_int8_pv.py:0:20
	sl_mov_b64 s[12:13], s[16:17]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s15, 0xfff00004
	ml_lsa_blkload_x1 v30, s[12:15], noreg, noreg, #0, ca
BB0_67:
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	sl_add_i32 s1, s50, 0x1f
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	sl_cmp_lt_i32 wcr, s1, s46
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_mov_b32 v31, 0x0
	sl_cbr_wcrz BB0_69, wcr
; %bb.68:
	sl_mov_b32 s31, 0xfff00004
	ml_lsa_blkload_x1 v31, s[28:31], noreg, noreg, #0, ca
                                        ; implicit-def: $vgpr33
BB0_69:
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_bfe2_b32 v33, tid, 0x25
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v33, s50, v33
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v33
	.loc	1 152 28 is_stmt 1              ; biv150_int8_pv.py:152:28
	sl_mull_u32 s2, s42, s41
	sl_mul_u64_u32 s[0:1], s42, s40
	sl_add_i32 s1, s1, s2
	sl_mull_u32 s2, s43, s40
	sl_add_i32 s1, s1, s2
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	sl_mov_b32 s2, 0xcc0
	ml_anyop3_b32 v33, s2, v91, v122, 0xfffffff8
	ml_slb_store_b32x4  v[0:3], v33, noreg, #0, null
	sl_mov_b32 s2, 0x1000
	ml_xor_b32 v0, v33, 0x10
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s64, v184, 0x0
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x4  v[16:19], v33, s2, #0, null
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s65, v184, 0x1
	ml_mov_v2s_b32 s66, v184, 0x2
	ml_mov_v2s_b32 s67, v184, 0x3
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x4  v[4:7], v0, noreg, #256, null
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s68, v184, 0x4
	ml_mov_v2s_b32 s69, v184, 0x5
	ml_mov_v2s_b32 s70, v184, 0x6
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x4  v[20:23], v0, s2, #256, null
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s71, v184, 0x7
	ml_xor_b32 v0, v33, 0x20
	ml_mov_v2s_b32 s72, v184, 0x8
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x4  v[8:11], v0, noreg, #512, null
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s73, v184, 0x9
	ml_mov_v2s_b32 s74, v184, 0xa
	ml_mov_v2s_b32 s75, v184, 0xb
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x4  v[24:27], v0, s2, #512, null
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s76, v184, 0xc
	ml_xor_b32 v0, v33, 0x30
	ml_mov_v2s_b32 s77, v184, 0xd
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x4  v[12:15], v0, noreg, #768, null
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s78, v184, 0xe
	ml_mov_v2s_b32 s79, v184, 0xf
	.loc	1 158 20 is_stmt 0              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v1, 0x0
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	ml_slb_store_b32x4  v[28:31], v0, s2, #768, null
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	sl_add_i64 s[0:1], s[74:75], s[0:1]
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v3, 0x0
	.loc	1 158 20 is_stmt 0              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_71
BB0_70:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	ml_addo_u32 {v0, tcr}, s4, v54
	ml_mov_b32 v2, s5
	ml_addc_i32 v3, v2, v108, tcr
	ml_addo_u32 {v2, tcr}, v93, v0
	ml_addc_i32 v3, 0, v3, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v3, v[2:3], kop=0
BB0_71:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v0, s50, v116
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_73
BB0_72:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v0, tcr}, s4, v76
	ml_mov_b32 v1, s5
	ml_addc_i32 v1, v1, v121, tcr
	ml_addo_u32 {v0, tcr}, v93, v0
	ml_addc_i32 v1, 0, v1, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v1, v[0:1], kop=0
BB0_73:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v0, s50, v114
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v0
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v0, 0x0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v2, 0x0
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_75
BB0_74:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v2, tcr}, s4, v74
	ml_mov_b32 v4, s5
	ml_addc_i32 v5, v4, v120, tcr
	ml_addo_u32 {v4, tcr}, v93, v2
	ml_addc_i32 v5, 0, v5, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v2, v[4:5], kop=0
BB0_75:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v112
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_77
BB0_76:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v0, tcr}, s4, v72
	ml_mov_b32 v4, s5
	ml_addc_i32 v5, v4, v119, tcr
	ml_addo_u32 {v4, tcr}, v93, v0
	ml_addc_i32 v5, 0, v5, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v0, v[4:5], kop=0
BB0_77:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v111
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v6, 0x0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v8, 0x0
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_79
BB0_78:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v70
	ml_mov_b32 v5, s5
	ml_addc_i32 v5, v5, v118, tcr
	ml_addo_u32 {v4, tcr}, v93, v4
	ml_addc_i32 v5, 0, v5, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v8, v[4:5], kop=0
BB0_79:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v110
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_81
BB0_80:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v68
	ml_mov_b32 v5, s5
	ml_addc_i32 v5, v5, v117, tcr
	ml_addo_u32 {v4, tcr}, v93, v4
	ml_addc_i32 v5, 0, v5, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v6, v[4:5], kop=0
BB0_81:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v107
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v5, 0x0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v7, 0x0
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_83
BB0_82:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v66
	ml_mov_b32 v7, s5
	ml_addc_i32 v7, v7, v115, tcr
	ml_addo_u32 {v9, tcr}, v93, v4
	ml_addc_i32 v10, 0, v7, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v7, v[9:10], kop=0
BB0_83:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v105
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_85
BB0_84:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	sl_add_i64 s[0:1], s[18:19], s[0:1]
	ml_addo_u32 {v4, tcr}, s0, v64
	ml_mov_b32 v5, s1
	ml_addc_i32 v5, v5, v113, tcr
	ml_addo_u32 {v4, tcr}, v93, v4
	ml_addc_i32 v5, 0, v5, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v5, v[4:5], kop=0
BB0_85:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 152 28 is_stmt 1              ; biv150_int8_pv.py:152:28
	sl_mull_u32 s2, s42, s23
	sl_mul_u64_u32 s[0:1], s42, s22
	sl_add_i32 s1, s1, s2
	sl_mull_u32 s2, s43, s22
	sl_add_i32 s1, s1, s2
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	ml_mov_v2s_b32 s64, v184, 0x0
	ml_mov_v2s_b32 s65, v184, 0x1
	ml_mov_v2s_b32 s66, v184, 0x2
	ml_mov_v2s_b32 s67, v184, 0x3
	ml_mov_v2s_b32 s68, v184, 0x4
	ml_mov_v2s_b32 s69, v184, 0x5
	ml_mov_v2s_b32 s70, v184, 0x6
	ml_mov_v2s_b32 s71, v184, 0x7
	ml_mov_v2s_b32 s72, v184, 0x8
	ml_mov_v2s_b32 s73, v184, 0x9
	ml_mov_v2s_b32 s74, v184, 0xa
	ml_mov_v2s_b32 s75, v184, 0xb
	ml_mov_v2s_b32 s76, v184, 0xc
	ml_mov_v2s_b32 s77, v184, 0xd
	ml_mov_v2s_b32 s78, v184, 0xe
	ml_mov_v2s_b32 s79, v184, 0xf
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_bfe2_b32 v4, tid, 0x25
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v4
	.loc	1 158 38                        ; biv150_int8_pv.py:158:38
	sl_add_i64 s[0:1], s[74:75], s[0:1]
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, v4, 0x10
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v10, 0x0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v12, 0x0
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_87
BB0_86:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v54
	ml_mov_b32 v9, s5
	ml_addc_i32 v9, v9, v108, tcr
	ml_addo_u32 {v11, tcr}, v93, v4
	ml_addc_i32 v12, 0, v9, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v12, v[11:12], kop=0
BB0_87:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v101
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_89
BB0_88:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v62
	ml_mov_b32 v9, s5
	ml_addc_i32 v10, v9, v109, tcr
	ml_addo_u32 {v9, tcr}, v93, v4
	ml_addc_i32 v10, 0, v10, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v10, v[9:10], kop=0
BB0_89:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v99
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v9, 0x0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v11, 0x0
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_91
BB0_90:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v58
	ml_mov_b32 v11, s5
	ml_addc_i32 v11, v11, v106, tcr
	ml_addo_u32 {v13, tcr}, v93, v4
	ml_addc_i32 v14, 0, v11, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v11, v[13:14], kop=0
BB0_91:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v100
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_93
BB0_92:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v60
	ml_mov_b32 v9, s5
	ml_addc_i32 v9, v9, v104, tcr
	ml_addo_u32 {v13, tcr}, v93, v4
	ml_addc_i32 v14, 0, v9, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v9, v[13:14], kop=0
BB0_93:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v97
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v14, 0x0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v16, 0x0
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_95
BB0_94:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v56
	ml_mov_b32 v13, s5
	ml_addc_i32 v13, v13, v103, tcr
	ml_addo_u32 {v15, tcr}, v93, v4
	ml_addc_i32 v16, 0, v13, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v16, v[15:16], kop=0
BB0_95:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v95
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_97
BB0_96:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v52
	ml_mov_b32 v13, s5
	ml_addc_i32 v14, v13, v102, tcr
	ml_addo_u32 {v13, tcr}, v93, v4
	ml_addc_i32 v14, 0, v14, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v14, v[13:14], kop=0
BB0_97:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v92
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_mov_b32 v13, 0x0
	sl_add_i64 s[4:5], s[18:19], s[0:1]
	ml_mov_b32 v15, 0x0
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_99
BB0_98:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	ml_addo_u32 {v4, tcr}, s4, v50
	ml_mov_b32 v15, s5
	ml_addc_i32 v15, v15, v98, tcr
	ml_addo_u32 {v17, tcr}, v93, v4
	ml_addc_i32 v18, 0, v15, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v15, v[17:18], kop=0
BB0_99:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 144 36 is_stmt 1              ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v90
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	; mask branch BB0_101
BB0_100:
	.loc	1 158 38 is_stmt 0              ; biv150_int8_pv.py:158:38
	sl_add_i64 s[0:1], s[18:19], s[0:1]
	ml_addo_u32 {v4, tcr}, s0, v48
	ml_mov_b32 v13, s1
	ml_addc_i32 v13, v13, v94, tcr
	ml_addo_u32 {v17, tcr}, v93, v4
	ml_addc_i32 v18, 0, v13, tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_lsa_load_a64_dword  v13, v[17:18], kop=0
BB0_101:
	.loc	1 0 20                          ; biv150_int8_pv.py:0:20
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 84 29 is_stmt 1               ; biv150_int8_pv.py:84:29
	ml_and_b32 v4, tid, 0xf
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v4, s50, v4
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v4
	.loc	1 158 20 is_stmt 1              ; biv150_int8_pv.py:158:20
	ml_and_b32 v4, tid, 0x4
	ml_mov_b32 v17, 0x140
	sl_mov_b32 s0, 0x600
	.loc	1 144 48                        ; biv150_int8_pv.py:144:48
	sl_mov_b64 s[4:5], tcr
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_cmp_eq_u32 tcr, v4, 0x0
	ml_csel_b32 v17, 0, v17, tcr
	ml_anyop3_b32 v18, s0, v91, v96, 0xfffffff8
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_bfe2_b32 v19, tid, 0x25
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_anyop3_b32 v17, v17, v18, v19, 0xfffffffe
	sl_mov_b32 s0, 0x2000
	sl_wait vmcnt(15)
	ml_slb_store_b8  v3, v17, s0, #0, null
	ml_srl_b32 v18, v3, 0x8
	sl_mov_b32 s2, 0x2800
	sl_mov_b32 s85, 0x0
	ml_slb_store_b8  v18, v17, s0, #2, null
	ml_srl_b32 v18, v3, 0x10
	ml_srl_b32 v3, v3, 0x18
	ml_slb_store_b8  v18, v17, s0, #4, null
	ml_slb_store_b8  v3, v17, s0, #6, null
	sl_wait vmcnt(14)
	ml_srl_b32 v3, v1, 0x8
	ml_slb_store_b8  v1, v17, s0, #32, null
	ml_slb_store_b8  v3, v17, s0, #34, null
	ml_srl_b32 v3, v1, 0x10
	ml_srl_b32 v1, v1, 0x18
	ml_slb_store_b8  v3, v17, s0, #36, null
	sl_wait vmcnt(13)
	ml_srl_b32 v3, v2, 0x8
	ml_slb_store_b8  v1, v17, s0, #38, null
	sl_wait vmcnt(11)
	ml_srl_b32 v1, v8, 0x8
	ml_slb_store_b8  v8, v17, s0, #128, null
	ml_slb_store_b8  v1, v17, s0, #130, null
	ml_srl_b32 v1, v8, 0x10
	ml_slb_store_b8  v1, v17, s0, #132, null
	ml_srl_b32 v1, v8, 0x18
	ml_slb_store_b8  v1, v17, s0, #134, null
	sl_wait vmcnt(10)
	ml_srl_b32 v1, v6, 0x8
	ml_slb_store_b8  v6, v17, s0, #160, null
	ml_slb_store_b8  v1, v17, s0, #162, null
	ml_srl_b32 v1, v6, 0x10
	ml_slb_store_b8  v1, v17, s0, #164, null
	ml_srl_b32 v1, v6, 0x18
	ml_mov_b32 v6, 0x0
	ml_slb_store_b8  v1, v17, s0, #166, null
	sl_wait vmcnt(7)
	ml_srl_b32 v1, v12, 0x8
	ml_slb_store_b8  v12, v17, s2, #0, null
	ml_slb_store_b8  v1, v17, s2, #2, null
	ml_srl_b32 v1, v12, 0x10
	ml_slb_store_b8  v1, v17, s2, #4, null
	ml_srl_b32 v1, v12, 0x18
	ml_slb_store_b8  v1, v17, s2, #6, null
	sl_wait vmcnt(6)
	ml_srl_b32 v1, v10, 0x8
	ml_slb_store_b8  v10, v17, s2, #32, null
	ml_slb_store_b8  v1, v17, s2, #34, null
	ml_srl_b32 v1, v10, 0x10
	ml_slb_store_b8  v1, v17, s2, #36, null
	ml_srl_b32 v1, v10, 0x18
	ml_slb_store_b8  v1, v17, s2, #38, null
	sl_wait vmcnt(3)
	ml_srl_b32 v1, v16, 0x8
	ml_slb_store_b8  v16, v17, s2, #128, null
	ml_slb_store_b8  v1, v17, s2, #130, null
	ml_srl_b32 v1, v16, 0x10
	ml_slb_store_b8  v1, v17, s2, #132, null
	ml_srl_b32 v1, v16, 0x18
	ml_slb_store_b8  v1, v17, s2, #134, null
	sl_wait vmcnt(2)
	ml_srl_b32 v1, v14, 0x8
	ml_slb_store_b8  v14, v17, s2, #160, null
	ml_slb_store_b8  v1, v17, s2, #162, null
	ml_srl_b32 v1, v14, 0x10
	ml_slb_store_b8  v1, v17, s2, #164, null
	ml_srl_b32 v1, v14, 0x18
	ml_slb_store_b8  v1, v17, s2, #166, null
	ml_xor_b32 v1, v17, 0x40
	ml_slb_store_b8  v2, v1, s0, #0, null
	ml_slb_store_b8  v3, v1, s0, #2, null
	ml_srl_b32 v3, v2, 0x10
	ml_srl_b32 v2, v2, 0x18
	ml_slb_store_b8  v3, v1, s0, #4, null
	ml_slb_store_b8  v2, v1, s0, #6, null
	ml_srl_b32 v2, v0, 0x8
	ml_slb_store_b8  v0, v1, s0, #32, null
	ml_slb_store_b8  v2, v1, s0, #34, null
	ml_srl_b32 v2, v0, 0x10
	ml_srl_b32 v0, v0, 0x18
	ml_slb_store_b8  v2, v1, s0, #36, null
	ml_slb_store_b8  v0, v1, s0, #38, null
	ml_srl_b32 v0, v7, 0x8
	ml_slb_store_b8  v7, v1, s0, #128, null
	ml_slb_store_b8  v0, v1, s0, #130, null
	ml_srl_b32 v0, v7, 0x10
	ml_slb_store_b8  v0, v1, s0, #132, null
	ml_srl_b32 v0, v7, 0x18
	ml_slb_store_b8  v0, v1, s0, #134, null
	ml_srl_b32 v0, v5, 0x8
	ml_slb_store_b8  v5, v1, s0, #160, null
	ml_slb_store_b8  v0, v1, s0, #162, null
	ml_srl_b32 v0, v5, 0x10
	ml_slb_store_b8  v0, v1, s0, #164, null
	ml_srl_b32 v0, v5, 0x18
	ml_mov_b32 v5, 0x0
	ml_slb_store_b8  v0, v1, s0, #166, null
	ml_srl_b32 v0, v11, 0x8
	.loc	1 159 48                        ; biv150_int8_pv.py:159:48
	sl_shl_b64 {s[0:1], wcr}, s[22:23], 0xe
	ml_mov_v2s_b32 s12, v184, 0x0
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_slb_store_b8  v11, v1, s2, #0, null
	ml_mov_v2s_b32 s13, v184, 0x1
	ml_mov_v2s_b32 s14, v184, 0x2
	ml_mov_v2s_b32 s15, v184, 0x3
	ml_slb_store_b8  v0, v1, s2, #2, null
	ml_srl_b32 v0, v11, 0x10
	ml_mov_v2s_b32 s16, v184, 0x4
	ml_mov_v2s_b32 s17, v184, 0x5
	ml_slb_store_b8  v0, v1, s2, #4, null
	ml_srl_b32 v0, v11, 0x18
	ml_mov_v2s_b32 s18, v184, 0x6
	ml_mov_v2s_b32 s19, v184, 0x7
	ml_slb_store_b8  v0, v1, s2, #6, null
	ml_srl_b32 v0, v9, 0x8
	ml_mov_v2s_b32 s20, v184, 0x8
	ml_mov_v2s_b32 s21, v184, 0x9
	ml_slb_store_b8  v9, v1, s2, #32, null
	ml_mov_v2s_b32 s22, v184, 0xa
	ml_mov_v2s_b32 s23, v184, 0xb
	ml_mov_v2s_b32 s24, v184, 0xc
	ml_slb_store_b8  v0, v1, s2, #34, null
	ml_srl_b32 v0, v9, 0x10
	ml_mov_v2s_b32 s25, v184, 0xd
	ml_mov_v2s_b32 s26, v184, 0xe
	ml_slb_store_b8  v0, v1, s2, #36, null
	ml_srl_b32 v0, v9, 0x18
	ml_mov_v2s_b32 s27, v184, 0xf
	ml_slb_store_b8  v0, v1, s2, #38, null
	sl_wait vmcnt(1)
	ml_srl_b32 v0, v15, 0x8
	.loc	1 159 48                        ; biv150_int8_pv.py:159:48
	sl_add_i64 s[0:1], s[24:25], s[0:1]
	.loc	1 158 20                        ; biv150_int8_pv.py:158:20
	ml_slb_store_b8  v15, v1, s2, #128, null
	ml_slb_store_b8  v0, v1, s2, #130, null
	ml_srl_b32 v0, v15, 0x10
	ml_slb_store_b8  v0, v1, s2, #132, null
	ml_srl_b32 v0, v15, 0x18
	ml_slb_store_b8  v0, v1, s2, #134, null
	sl_wait vmcnt(0)
	ml_srl_b32 v0, v13, 0x8
	ml_slb_store_b8  v13, v1, s2, #160, null
	ml_slb_store_b8  v0, v1, s2, #162, null
	ml_srl_b32 v0, v13, 0x10
	ml_slb_store_b8  v0, v1, s2, #164, null
	ml_srl_b32 v0, v13, 0x18
	ml_slb_store_b8  v0, v1, s2, #166, null
	.loc	1 159 30                        ; biv150_int8_pv.py:159:30
	sl_and_savetmsk_b64 {s[2:3], wcr}, s[4:5], tmsk
	; mask branch BB0_103
BB0_102:
	.loc	1 159 48 is_stmt 0              ; biv150_int8_pv.py:159:48
	sl_shl_b64 {s[8:9], wcr}, s[40:41], 0xe
	sl_add_i64 s[8:9], s[24:25], s[8:9]
	.loc	1 159 30                        ; biv150_int8_pv.py:159:30
	sl_add_i64 s[20:21], s[8:9], s[84:85]
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_load_dword v6, s[20:23], unsigned v87, noreg, #0, ca|mie
BB0_103:
	.loc	1 0 30                          ; biv150_int8_pv.py:0:30
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 84 29 is_stmt 1               ; biv150_int8_pv.py:84:29
	ml_and_b32 v0, tid, 0xf
	.loc	1 144 36                        ; biv150_int8_pv.py:144:36
	ml_add_i32 v0, s50, v0
	ml_add_i32 v0, v0, 0x10
	.loc	1 144 48 is_stmt 0              ; biv150_int8_pv.py:144:48
	ml_cmp_gt_i32 tcr, s46, v0
	sl_mov_b64 s[2:3], tcr
	.loc	1 159 30 is_stmt 1              ; biv150_int8_pv.py:159:30
	sl_and_savetmsk_b64 {s[8:9], wcr}, tcr, tmsk
	; mask branch BB0_105
BB0_104:
	sl_add_i64 s[20:21], s[0:1], s[84:85]
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_load_dword v5, s[20:23], unsigned v87, noreg, #0, ca|mie
BB0_105:
	.loc	1 0 30 is_stmt 0                ; biv150_int8_pv.py:0:30
	sl_or_b64 {tmsk, wcr}, tmsk, s[8:9]
	.loc	1 157 20 is_stmt 1              ; biv150_int8_pv.py:157:20
	sl_wait vmcnt(0) lmcnt(0)
	sl_barrier 
	.loc	1 164 57                        ; biv150_int8_pv.py:164:57
	sl_mov_b64 tcr, s[4:5]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v11, v86, noreg, #0, null
	ml_xor_b32 v19, v86, 0x10
	sl_mov_b32 s0, 0x1000
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v45, v44
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v12, v19, noreg, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v0, 0x0
	ml_mov_b32 v1, 0x0
	ml_mov_b32 v2, 0x0
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v86, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v3, 0x0
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_xor_b32 v20, v86, 0x20
	ml_xor_b32 v21, v86, 0x30
	ml_slb_load_b32x1  v16, v19, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v47, v46
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	sl_mov_b32 s1, 0x1400
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v41, v40
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v17, v20, noreg, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v43, v42
	ml_mov_b32 v37, v36
	ml_mov_b32 v39, v38
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v18, v21, noreg, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	ml_mov_b32 v33, v32
	ml_mov_b32 v35, v34
	sl_wait lmcnt(4)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[44:45], v[11:12], v[0:3]
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[44:45], v[15:16], v[0:3]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v20, s0, #0, null
	ml_slb_load_b32x1  v16, v21, s0, #0, null
	sl_mov_b32 s0, 0x400
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[46:47], v[17:18], v[7:10]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v17, v86, s0, #0, null
	ml_slb_load_b32x1  v18, v19, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[46:47], v[15:16], v[11:14]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v86, s1, #0, null
	ml_slb_load_b32x1  v16, v19, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[40:41], v[17:18], v[7:10]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v17, v20, s0, #0, null
	ml_slb_load_b32x1  v18, v21, s0, #0, null
	sl_mov_b32 s0, 0x800
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[40:41], v[15:16], v[11:14]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v20, s1, #0, null
	ml_slb_load_b32x1  v16, v21, s1, #0, null
	sl_mov_b32 s1, 0x1800
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[42:43], v[17:18], v[7:10]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v17, v86, s0, #0, null
	ml_slb_load_b32x1  v18, v19, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[42:43], v[15:16], v[11:14]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v86, s1, #0, null
	ml_slb_load_b32x1  v16, v19, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[36:37], v[17:18], v[7:10]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v17, v20, s0, #0, null
	ml_slb_load_b32x1  v18, v21, s0, #0, null
	sl_mov_b32 s0, 0xc00
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[36:37], v[15:16], v[11:14]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v20, s1, #0, null
	ml_slb_load_b32x1  v16, v21, s1, #0, null
	sl_mov_b32 s1, 0x1c00
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[38:39], v[17:18], v[7:10]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v17, v86, s0, #0, null
	ml_slb_load_b32x1  v18, v19, s0, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[38:39], v[15:16], v[11:14]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v86, s1, #0, null
	ml_slb_load_b32x1  v16, v19, s1, #0, null
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[32:33], v[17:18], v[7:10]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v17, v20, s0, #0, null
	ml_slb_load_b32x1  v18, v21, s0, #0, null
.Ltmp112:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:169:81 ]
	sl_reg_read s0, hwreg(HW_REG_MODE)
.Ltmp113:
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[32:33], v[15:16], v[11:14]
	.loc	1 157 20                        ; biv150_int8_pv.py:157:20
	ml_slb_load_b32x1  v15, v20, s1, #0, null
	ml_slb_load_b32x1  v16, v21, s1, #0, null
.Ltmp114:
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:169:81 ]
	sl_or_b32 {s1, wcr}, s0, 0x3
.Ltmp115:
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[7:10], v[34:35], v[17:18], v[7:10]
	ml_mov_b32 v10, 0xff800000
	.loc	1 163 32 is_stmt 0              ; biv150_int8_pv.py:163:32
	ml_mul_f32 v7, s30, v7
	ml_mul_f32 v8, s30, v8
	.loc	1 164 57 is_stmt 1              ; biv150_int8_pv.py:164:57
	ml_csel_b32 v7, v7, v10, tcr
	ml_csel_b32 v8, v8, v10, tcr
	sl_mov_b64 tcr, s[2:3]
	.loc	1 163 27                        ; biv150_int8_pv.py:163:27
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[11:14], v[34:35], v[15:16], v[11:14]
	ml_xor_b32 v13, tid, 0x8
	.loc	1 163 32 is_stmt 0              ; biv150_int8_pv.py:163:32
	ml_mul_f32 v9, s30, v11
	.loc	1 164 57 is_stmt 1              ; biv150_int8_pv.py:164:57
	ml_csel_b32 v9, v9, v10, tcr
.Ltmp116:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	ml_max_f32 v11, v7, v9
.Ltmp117:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v14, v11, v13
.Ltmp118:
	.loc	1 163 32                        ; biv150_int8_pv.py:163:32
	ml_mul_f32 v12, s30, v12
	.loc	1 164 57                        ; biv150_int8_pv.py:164:57
	ml_csel_b32 v10, v12, v10, tcr
.Ltmp119:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	ml_max_f32 v12, v8, v10
.Ltmp120:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v15, v12, v13
.Ltmp121:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v11, v11, v14
	ml_xor_b32 v14, tid, 0x4
.Ltmp122:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v16, v11, v14
.Ltmp123:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v12, v12, v15
.Ltmp124:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v15, v12, v14
.Ltmp125:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v11, v11, v16
	ml_xor_b32 v16, tid, 0x2
.Ltmp126:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v17, v11, v16
.Ltmp127:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v12, v12, v15
.Ltmp128:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v15, v12, v16
.Ltmp129:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v11, v11, v17
	ml_xor_b32 v17, tid, 0x1
.Ltmp130:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v18, v11, v17
.Ltmp131:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v12, v12, v15
.Ltmp132:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:165:57 ]
	ml_slb_shuffle_rtn_b32 v15, v12, v17
.Ltmp133:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v11, v11, v18
.Ltmp134:
	.loc	1 165 42                        ; biv150_int8_pv.py:165:42
	ml_max_f32 v35, v88, v11
	.loc	1 166 44                        ; biv150_int8_pv.py:166:44
	ml_sub_f32 v7, v7, v35
	ml_sub_f32 v9, v9, v35
.Ltmp135:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:165:57 ] ]
	sl_wait lmcnt(0)
	ml_max_f32 v11, v12, v15
.Ltmp136:
	.loc	1 166 35                        ; biv150_int8_pv.py:166:35
	ml_exp_f32 v7, v7
	.loc	1 165 42                        ; biv150_int8_pv.py:165:42
	ml_max_f32 v36, v89, v11
	.loc	1 166 44                        ; biv150_int8_pv.py:166:44
	ml_sub_f32 v8, v8, v36
	ml_sub_f32 v10, v10, v36
	.loc	1 166 35 is_stmt 0              ; biv150_int8_pv.py:166:35
	ml_exp_f32 v8, v8
.Ltmp137:
	.loc	1 15 25 is_stmt 1               ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v11, v6, v7
.Ltmp138:
	.loc	1 166 35                        ; biv150_int8_pv.py:166:35
	ml_exp_f32 v9, v9
.Ltmp139:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v6, v6, v8
.Ltmp140:
	.loc	1 166 35                        ; biv150_int8_pv.py:166:35
	ml_exp_f32 v10, v10
.Ltmp141:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v12, v5, v9
.Ltmp142:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	ml_max_f32 v15, v11, v12
.Ltmp143:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v18, v15, v13
.Ltmp144:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	ml_add_f32 v7, v7, v9
.Ltmp145:
	.loc	1 15 25                         ; biv150_int8_pv.py:15:25 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v5, v5, v10
.Ltmp146:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	ml_max_f32 v19, v6, v5
.Ltmp147:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v20, v19, v13
.Ltmp148:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	ml_add_f32 v8, v8, v10
.Ltmp149:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v9, v7, v13
	ml_slb_shuffle_rtn_b32 v10, v8, v13
.Ltmp150:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v13, v15, v18
.Ltmp151:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v15, v13, v14
.Ltmp152:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v18, v19, v20
.Ltmp153:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v19, v18, v14
.Ltmp154:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v7, v7, v9
.Ltmp155:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v9, v7, v14
.Ltmp156:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v8, v8, v10
.Ltmp157:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v10, v8, v14
.Ltmp158:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v13, v13, v15
.Ltmp159:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v14, v13, v16
.Ltmp160:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v15, v18, v19
.Ltmp161:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v18, v15, v16
.Ltmp162:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v7, v7, v9
.Ltmp163:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v9, v7, v16
.Ltmp164:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v8, v8, v10
.Ltmp165:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v10, v8, v16
.Ltmp166:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v13, v13, v14
.Ltmp167:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v14, v13, v17
.Ltmp168:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v15, v15, v18
.Ltmp169:
	.loc	2 213 40                        ; standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ]
	ml_slb_shuffle_rtn_b32 v16, v15, v17
.Ltmp170:
	.loc	1 167 45                        ; biv150_int8_pv.py:167:45
	ml_sub_f32 v18, v88, v35
.Ltmp171:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v7, v7, v9
.Ltmp172:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v9, v7, v17
.Ltmp173:
	.loc	1 167 31                        ; biv150_int8_pv.py:167:31
	ml_exp_f32 v37, v18
.Ltmp174:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v8, v8, v10
.Ltmp175:
	.loc	2 315 36                        ; standard.py:315:36 @[ biv150_int8_pv.py:168:66 ]
	ml_slb_shuffle_rtn_b32 v10, v8, v17
.Ltmp176:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v13, v13, v14
.Ltmp177:
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v13, v13, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v38, v13, 0x3c010204
.Ltmp178:
	.loc	2 192 27 is_stmt 1              ; standard.py:192:27 @[ standard.py:213:40 @[ biv150_int8_pv.py:16:37 @[ biv150_int8_pv.py:169:81 ] ] ]
	sl_wait lmcnt(2)
	ml_max_f32 v13, v15, v16
.Ltmp179:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_rcp_f32 v14, v38
	.loc	1 16 40                         ; biv150_int8_pv.py:16:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v13, v13, 0x1e3ce508
	.loc	1 16 48 is_stmt 0               ; biv150_int8_pv.py:16:48 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v39, v13, 0x3c010204
.Ltmp180:
	.loc	2 285 15 is_stmt 1              ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v7, v7, v9
.Ltmp181:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_rcp_f32 v9, v39
.Ltmp182:
	.loc	1 168 46                        ; biv150_int8_pv.py:168:46
	ml_fma_f32 v49, v49, v37, v7
.Ltmp183:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_xor_b32 v7, v38, 0x80000000
.Ltmp184:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ biv150_int8_pv.py:168:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v8, v8, v10
.Ltmp185:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_xor_b32 v10, v39, 0x80000000
	ml_mul_f32 v13, v11, v14
	ml_mul_f32 v15, v6, v9
	ml_mul_f32 v16, v12, v14
	ml_fma_f32 v11, v7, v13, v11
	ml_fma_f32 v7, v7, v16, v12
	ml_mul_f32 v12, v5, v9
	ml_fma_f32 v6, v10, v15, v6
	ml_fma_f32 v5, v10, v12, v5
	ml_fma_f32 v10, v11, v14, v13
	ml_fma_f32 v7, v7, v14, v16
.Ltmp186:
	.loc	1 167 45                        ; biv150_int8_pv.py:167:45
	ml_sub_f32 v11, v89, v36
.Ltmp187:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_fma_f32 v6, v6, v9, v15
	ml_fma_f32 v5, v5, v9, v12
	ml_mov_b32 v9, 0x99
.Ltmp188:
	.loc	1 167 31                        ; biv150_int8_pv.py:167:31
	ml_exp_f32 v40, v11
.Ltmp189:
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v13, v9
	ml_csel_b32 v10, v13, v10, tcr
	.loc	1 17 72 is_stmt 0               ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v10, v10, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v15, v9
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v10, v10
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_csel_b32 v6, v15, v6, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v6, v6, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v16, v9
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v6, v6
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_csel_b32 v7, v16, v7, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v7, v7, 0x3f000000
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_cmp_class_f32 tcr, v12, v9
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v7, v7
	.loc	1 17 58                         ; biv150_int8_pv.py:17:58 @[ biv150_int8_pv.py:169:81 ]
	ml_csel_b32 v5, v12, v5, tcr
	.loc	1 17 72                         ; biv150_int8_pv.py:17:72 @[ biv150_int8_pv.py:169:81 ]
	ml_add_f32 v5, v5, 0x3f000000
.Ltmp190:
	.loc	1 168 46 is_stmt 1              ; biv150_int8_pv.py:168:46
	ml_fma_f32 v51, v51, v40, v8
.Ltmp191:
	.loc	1 17 49                         ; biv150_int8_pv.py:17:49 @[ biv150_int8_pv.py:169:81 ]
	ml_floor_f32 v5, v5
	.loc	1 17 40 is_stmt 0               ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v8, v10, 0x0
	ml_max_f32 v6, v6, 0x0
	ml_max_f32 v7, v7, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:169:81 ]
	ml_min_f32 v8, v8, 0x42fe0000
	ml_min_f32 v6, v6, 0x42fe0000
	.loc	1 17 40                         ; biv150_int8_pv.py:17:40 @[ biv150_int8_pv.py:169:81 ]
	ml_max_f32 v5, v5, 0x0
	.loc	1 17 26                         ; biv150_int8_pv.py:17:26 @[ biv150_int8_pv.py:169:81 ]
	ml_min_f32 v7, v7, 0x42fe0000
	ml_min_f32 v5, v5, 0x42fe0000
	.loc	1 17 81                         ; biv150_int8_pv.py:17:81 @[ biv150_int8_pv.py:169:81 ]
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v8, v8
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v6, v6
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v7, v7
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_reg_read s0, hwreg(HW_REG_MODE)
	sl_or_b32 {s1, wcr}, s0, 0x3
	sl_reg_write hwreg(HW_REG_MODE), s1
	ml_cvt_i32_f32  v5, v5
	sl_reg_write hwreg(HW_REG_MODE), s0
	sl_barrier 
	ml_bfe2_b32 v9, tid, 0x24
	ml_anyop3_b32 v9, v85, v84, v9, 0xfffffffe
	ml_slb_store_b8  v8, v9, noreg, #0, null
	ml_slb_store_b8  v6, v9, noreg, #16, null
	ml_slb_store_b8  v7, v9, noreg, #128, null
	ml_slb_store_b8  v5, v9, noreg, #144, null
	sl_wait lmcnt(0)
	sl_barrier 
	ml_and_b32 v5, tid, 0x10
	ml_or_b32 v5, v85, v5
	.loc	1 19 25 is_stmt 1               ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_slb_load_b8  v6, v5, noreg, #128, null
	sl_mov_b32 s0, 0x2800
	sl_mov_b32 s1, 0x2000
	sl_mov_b32 s2, 0x504
	ml_slb_load_b8  v7, v5, noreg, #129, null
	sl_mov_b32 s3, 0x60504
	ml_mov_b32 v88, v35
	ml_mov_b32 v89, v36
	ml_slb_load_b8  v8, v5, noreg, #136, null
	ml_slb_load_b8  v9, v5, noreg, #137, null
	ml_slb_load_b8  v10, v5, noreg, #0, null
	ml_slb_load_b8  v11, v5, noreg, #1, null
	ml_slb_load_b8  v12, v5, noreg, #8, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v7, v6, 4
	ml_slb_load_b8  v5, v5, noreg, #9, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v8, v6, s2
	ml_slb_load_b8  v13, v83, s0, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v34, v9, v6, s3
	ml_slb_load_b8  v14, v83, s0, #1, null
	ml_slb_load_b8  v15, v83, s0, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v11, v10, 4
	ml_slb_load_b8  v16, v83, s0, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v12, v6, s2
	ml_slb_load_b8  v17, v83, s1, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v33, v5, v6, s3
	ml_slb_load_b8  v18, v83, s1, #1, null
	ml_slb_load_b8  v19, v83, s1, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v14, v13, 4
	ml_slb_load_b8  v20, v83, s1, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v15, v5, s2
	ml_slb_load_b8  v21, v82, s0, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v10, v16, v5, s3
	ml_slb_load_b8  v22, v82, s0, #257, null
	ml_slb_load_b8  v23, v82, s0, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v18, v17, 4
	ml_slb_load_b8  v24, v82, s0, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v19, v5, s2
	ml_slb_load_b8  v25, v82, s1, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v9, v20, v5, s3
	ml_slb_load_b8  v26, v82, s1, #257, null
	ml_slb_load_b8  v27, v82, s1, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v22, v21, 4
	ml_slb_load_b8  v28, v82, s1, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v23, v5, s2
	ml_slb_load_b8  v29, v83, s0, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v14, v24, v5, s3
	ml_slb_load_b8  v30, v83, s0, #513, null
	ml_slb_load_b8  v31, v83, s0, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v26, v25, 4
	ml_slb_load_b8  v7, v83, s0, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v27, v5, s2
	ml_slb_load_b8  v32, v83, s1, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v13, v28, v5, s3
	ml_slb_load_b8  v41, v83, s1, #513, null
	ml_slb_load_b8  v42, v83, s1, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v30, v29, 4
	ml_slb_load_b8  v43, v83, s1, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v31, v5, s2
	ml_slb_load_b8  v44, v82, s0, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v18, v7, v5, s3
	ml_matrix_mad_i32_i8_m16n16k32 v[5:8], v[33:34], v[9:10], v[0:3]
	ml_slb_load_b8  v45, v82, s0, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[9:12], v[33:34], v[13:14], v[0:3]
	ml_slb_load_b8  v46, v82, s0, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v41, v32, 4
	ml_slb_load_b8  v47, v82, s0, #801, null
	sl_mov_b32 s0, 0x2c00
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v42, v5, s2
	ml_slb_load_b8  v48, v82, s1, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v17, v43, v5, s3
	ml_slb_load_b8  v50, v82, s1, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[13:16], v[33:34], v[17:18], v[0:3]
	ml_slb_load_b8  v52, v82, s1, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v45, v44, 4
	ml_slb_load_b8  v54, v82, s1, #801, null
	sl_mov_b32 s1, 0x2400
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v46, v5, s2
	ml_slb_load_b8  v56, v83, s0, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v47, v5, s3
	ml_slb_load_b8  v58, v83, s0, #1, null
	ml_slb_load_b8  v60, v83, s0, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v50, v48, 4
	ml_slb_load_b8  v21, v83, s0, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v52, v5, s2
	ml_slb_load_b8  v22, v83, s1, #0, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v54, v5, s3
	ml_slb_load_b8  v23, v83, s1, #1, null
	ml_matrix_mad_i32_i8_m16n16k32 v[17:20], v[33:34], v[5:6], v[0:3]
	ml_slb_load_b8  v24, v83, s1, #32, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v58, v56, 4
	ml_slb_load_b8  v62, v83, s1, #33, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v60, v5, s2
	ml_slb_load_b8  v25, v82, s0, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v21, v5, s3
	ml_slb_load_b8  v26, v82, s0, #257, null
	ml_slb_load_b8  v27, v82, s0, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v23, v22, 4
	ml_slb_load_b8  v28, v82, s0, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v24, v5, s2
	ml_slb_load_b8  v29, v82, s1, #256, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v62, v5, s3
	ml_slb_load_b8  v30, v82, s1, #257, null
	ml_matrix_mad_i32_i8_m16n16k32 v[21:24], v[33:34], v[5:6], v[0:3]
	ml_slb_load_b8  v31, v82, s1, #288, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v26, v25, 4
	ml_slb_load_b8  v64, v82, s1, #289, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v27, v5, s2
	ml_slb_load_b8  v32, v83, s0, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v28, v5, s3
	ml_slb_load_b8  v9, v83, s0, #513, null
	ml_slb_load_b8  v10, v83, s0, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v30, v29, 4
	ml_slb_load_b8  v13, v83, s0, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v31, v5, s2
	ml_slb_load_b8  v14, v83, s1, #512, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v64, v5, s3
	ml_slb_load_b8  v41, v83, s1, #513, null
	ml_matrix_mad_i32_i8_m16n16k32 v[25:28], v[33:34], v[5:6], v[0:3]
	ml_slb_load_b8  v17, v83, s1, #544, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v9, v32, 4
	ml_slb_load_b8  v18, v83, s1, #545, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v10, v5, s2
	ml_slb_load_b8  v42, v82, s0, #768, null
	ml_slb_load_b8  v21, v82, s0, #769, null
	ml_slb_load_b8  v22, v82, s0, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v6, v41, v14, 4
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:169:81 ]
	ml_cvt_f32_i32  v14, v28
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_slb_load_b8  v43, v82, s0, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v10, v17, v6, s2
	ml_byte_permute_b32 v6, v13, v5, s3
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:169:81 ]
	ml_cvt_f32_i32  v13, v27
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_slb_load_b8  v44, v82, s1, #768, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v18, v10, s3
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v13, v38, v13
.Ltmp192:
	.loc	1 169 55                        ; biv150_int8_pv.py:169:55
	ml_fma_f32 v67, v67, v37, v13
.Ltmp193:
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_slb_load_b8  v25, v82, s1, #769, null
	ml_matrix_mad_i32_i8_m16n16k32 v[29:32], v[33:34], v[5:6], v[0:3]
	ml_slb_load_b8  v9, v82, s1, #800, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v21, v42, 4
	ml_slb_load_b8  v10, v82, s1, #801, null
	sl_wait lmcnt(5)
	ml_byte_permute_b32 v5, v22, v5, s2
	sl_wait lmcnt(2)
	ml_byte_permute_b32 v6, v25, v44, 4
	sl_wait lmcnt(1)
	ml_byte_permute_b32 v9, v9, v6, s2
	ml_byte_permute_b32 v6, v43, v5, s3
	sl_wait lmcnt(0)
	ml_byte_permute_b32 v5, v10, v9, s3
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:169:81 ]
	ml_cvt_f32_i32  v9, v19
	ml_cvt_f32_i32  v10, v20
	.loc	1 19 25                         ; biv150_int8_pv.py:19:25 @[ biv150_int8_pv.py:169:81 ]
	ml_matrix_mad_i32_i8_m16n16k32 v[0:3], v[33:34], v[5:6], v[0:3]
	.loc	1 20 22                         ; biv150_int8_pv.py:20:22 @[ biv150_int8_pv.py:169:81 ]
	ml_cvt_f32_i32  v0, v7
	ml_cvt_f32_i32  v1, v8
	ml_cvt_f32_i32  v5, v11
	ml_cvt_f32_i32  v6, v12
	ml_cvt_f32_i32  v7, v15
	ml_cvt_f32_i32  v8, v16
	ml_cvt_f32_i32  v11, v23
	ml_cvt_f32_i32  v12, v24
	ml_cvt_f32_i32  v15, v31
	ml_cvt_f32_i32  v16, v32
	ml_cvt_f32_i32  v2, v2
	ml_cvt_f32_i32  v3, v3
	.loc	1 20 34 is_stmt 0               ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v0, v38, v0
	ml_mul_f32 v5, v38, v5
	ml_mul_f32 v7, v38, v7
	ml_mul_f32 v9, v38, v9
	ml_mul_f32 v11, v38, v11
	ml_mul_f32 v15, v38, v15
	ml_mul_f32 v2, v38, v2
.Ltmp194:
	.loc	1 169 55 is_stmt 1              ; biv150_int8_pv.py:169:55
	ml_fma_f32 v53, v53, v37, v0
	ml_fma_f32 v81, v81, v37, v5
	ml_fma_f32 v79, v79, v37, v7
	ml_fma_f32 v75, v75, v37, v9
	ml_fma_f32 v71, v71, v37, v11
	ml_fma_f32 v63, v63, v37, v15
	ml_fma_f32 v57, v57, v37, v2
.Ltmp195:
	.loc	1 20 34                         ; biv150_int8_pv.py:20:34 @[ biv150_int8_pv.py:169:81 ]
	ml_mul_f32 v0, v39, v1
	ml_mul_f32 v1, v39, v6
	ml_mul_f32 v2, v39, v8
	ml_mul_f32 v5, v39, v10
	ml_mul_f32 v6, v39, v12
	ml_mul_f32 v7, v39, v14
	ml_mul_f32 v8, v39, v16
	ml_mul_f32 v3, v39, v3
.Ltmp196:
	.loc	1 169 55                        ; biv150_int8_pv.py:169:55
	ml_fma_f32 v80, v80, v40, v0
	ml_fma_f32 v77, v77, v40, v1
	ml_fma_f32 v73, v73, v40, v2
	ml_fma_f32 v69, v69, v40, v5
	ml_fma_f32 v65, v65, v40, v6
	ml_fma_f32 v61, v61, v40, v7
	ml_fma_f32 v55, v55, v40, v8
	ml_fma_f32 v59, v59, v40, v3
	sl_jump BB0_107
BB0_106:                                ; %._crit_edge._crit_edge
	.loc	1 0 55 is_stmt 0                ; biv150_int8_pv.py:0:55
	ml_mov_v2s_b32 s12, v184, 0x0
	ml_mov_v2s_b32 s13, v184, 0x1
	ml_mov_v2s_b32 s14, v184, 0x2
	ml_mov_v2s_b32 s15, v184, 0x3
	ml_mov_v2s_b32 s16, v184, 0x4
	ml_mov_v2s_b32 s17, v184, 0x5
	ml_mov_v2s_b32 s18, v184, 0x6
	ml_mov_v2s_b32 s19, v184, 0x7
	ml_mov_v2s_b32 s20, v184, 0x8
	ml_mov_v2s_b32 s21, v184, 0x9
	ml_mov_v2s_b32 s22, v184, 0xa
	ml_mov_v2s_b32 s23, v184, 0xb
	ml_mov_v2s_b32 s24, v184, 0xc
	ml_mov_v2s_b32 s25, v184, 0xd
	ml_mov_v2s_b32 s26, v184, 0xe
	ml_mov_v2s_b32 s27, v184, 0xf
BB0_107:
	.loc	1 82 28 is_stmt 1               ; biv150_int8_pv.py:82:28
	ml_and_b32 v7, tid, 0x30
	ml_srl_b32 v0, v7, 0x4
	.loc	1 90 29                         ; biv150_int8_pv.py:90:29
	sl_mull_u32 s0, s6, 0x8
	.loc	1 90 46 is_stmt 0               ; biv150_int8_pv.py:90:46
	ml_add_i32 v0, s0, v0
	.loc	1 178 31 is_stmt 1              ; biv150_int8_pv.py:178:31
	sl_shl_b64 {s[0:1], wcr}, s[86:87], 0x11
	sl_add_i64 s[2:3], s[12:13], s[0:1]
	ml_shl_b32 v0, v0, 0xd
	sl_mov_b32 s1, 0x0
	sl_mull_u32 s0, s90, 0x200
	sl_add_i64 s[2:3], s[0:1], s[2:3]
	ml_addo_u32 {v0, tcr}, s2, v0
	ml_mov_b32 v1, s3
	.loc	1 84 29                         ; biv150_int8_pv.py:84:29
	ml_and_b32 v2, tid, 0xf
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	ml_shl_b32 v2, v2, 0x2
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v0, tcr}, v2, v0
	sl_mov_b32 s0, 0x8000
	.loc	1 180 20                        ; biv150_int8_pv.py:180:20
	sl_shl_b64 {s[8:9], wcr}, s[86:87], 0x8
	.loc	1 180 68 is_stmt 0              ; biv150_int8_pv.py:180:68
	sl_mov_b32 s91, s1
	.loc	1 178 31 is_stmt 1              ; biv150_int8_pv.py:178:31
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	sl_mov_b32 s0, 0x40
	.loc	1 178 47 is_stmt 0              ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[0:1], v53, kop=0
	.loc	1 186 44 is_stmt 1              ; biv150_int8_pv.py:186:44
	sl_mull_u32 s6, s6, 0x200
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v5, tcr}, s0, v0
	.loc	1 178 47 is_stmt 0              ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[2:3], v80, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x8040
	ml_addc_i32 v6, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[5:6], v81, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x80
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v5, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[2:3], v77, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x8080
	ml_addc_i32 v6, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[5:6], v79, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0xc0
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v5, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[2:3], v73, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x80c0
	ml_addc_i32 v6, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[5:6], v75, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x100
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v5, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[2:3], v69, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x8100
	ml_addc_i32 v6, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[5:6], v71, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x140
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v5, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[2:3], v65, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x8140
	ml_addc_i32 v6, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[5:6], v67, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x180
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v5, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[2:3], v61, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x8180
	ml_addc_i32 v6, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[5:6], v63, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x1c0
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v5, tcr}, s0, v0
	.loc	1 178 47                        ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[2:3], v55, kop=0
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	sl_mov_b32 s0, 0x81c0
	.loc	1 186 44 is_stmt 1              ; biv150_int8_pv.py:186:44
	ml_and_b32 v2, tid, 0x1
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	ml_addc_i32 v6, 0, v1, tcr
	ml_addo_u32 {v0, tcr}, s0, v0
	.loc	1 178 47 is_stmt 0              ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[5:6], v57, kop=0
	.loc	1 186 44 is_stmt 1              ; biv150_int8_pv.py:186:44
	ml_srl_b32 v3, v7, 0x3
	ml_srl_b32 v5, v4, 0x2
	.loc	1 178 31                        ; biv150_int8_pv.py:178:31
	ml_addc_i32 v1, 0, v1, tcr
	.loc	1 178 47 is_stmt 0              ; biv150_int8_pv.py:178:47
	ml_lsa_store_a64_dword  v[0:1], v59, kop=0
	.loc	1 186 58 is_stmt 1              ; biv150_int8_pv.py:186:58
	ml_mul_f32 v0, v88, 0x3f317218
	ml_mul_f32 v1, v89, 0x3f317218
	.loc	1 186 44 is_stmt 0              ; biv150_int8_pv.py:186:44
	ml_cmp_eq_u32 tcr, v2, 0x0
	ml_shl_b32 v2, v78, 0x4
	ml_anyop3_b32 v2, 48, v2, v3, 0xfffffff8
	.loc	1 96 16 is_stmt 1               ; biv150_int8_pv.py:96:16
	ml_and_b32 v3, tid, 0x8
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_anyop3_b32 v2, v2, v5, v3, 0xfffffffe
	ml_csel_b32 v3, v0, v1, tcr
	ml_slb_shuffle_rtn_b32 v3, v3, v2
	ml_csel_b32 v0, v1, v0, tcr
	ml_xor_b32 v1, v2, 0x1
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	ml_csel_b32 v6, v51, v49, tcr
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_slb_shuffle_rtn_b32 v5, v0, v1
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	ml_csel_b32 v0, v49, v51, tcr
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_cmp_eq_u32 tcr, v4, 0x0
	.loc	1 180 39                        ; biv150_int8_pv.py:180:39
	sl_add_i64 s[0:1], s[8:9], s[90:91]
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	ml_slb_shuffle_rtn_b32 v0, v0, v2
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	ml_and_b32 v2, tid, 0x38
	sl_mov_b64 s[2:3], tcr
	ml_cmp_eq_u32 tcr, v2, 0x0
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	ml_slb_shuffle_rtn_b32 v1, v6, v1
	.loc	1 82 28                         ; biv150_int8_pv.py:82:28
	ml_and_b32 v2, tid, 0x7
	ml_shl_b32 v2, v2, 0x6
	.loc	1 186 44                        ; biv150_int8_pv.py:186:44
	sl_mov_b64 s[4:5], tcr
	sl_mov_b64 tcr, s[2:3]
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	sl_add_i64 s[12:13], s[14:15], s[0:1]
	sl_mov_b32 s15, 0xffffffff
	ml_add_i32 v2, s6, v2
	sl_wait lmcnt(2)
	ml_csel_b32 v3, v3, v5, tcr
	sl_and_savetmsk_b64 {s[10:11], wcr}, s[4:5], tmsk
	ml_lsa_store_dword v3, s[12:15], signed v2, noreg, #0, wb
	sl_or_b64 {tmsk, wcr}, tmsk, s[10:11]
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	sl_and_savetmsk_b64 {s[6:7], wcr}, s[4:5], tmsk
	sl_xor_b64 {s[4:5], wcr}, tmsk, s[6:7]
	; mask branch BB0_109
BB0_108:
	.loc	1 0 47 is_stmt 0                ; biv150_int8_pv.py:0:47
	sl_mov_b64 tcr, s[2:3]
	sl_wait lmcnt(0)
	ml_csel_b32 v0, v0, v1, tcr
	.loc	1 187 47                        ; biv150_int8_pv.py:187:47
	sl_add_i64 s[12:13], s[16:17], s[0:1]
	ml_lsa_store_dword v0, s[12:15], signed v2, noreg, #0, wb
BB0_109:                                ; %Flow
	.loc	1 0 47                          ; biv150_int8_pv.py:0:47
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
BB0_110:                                ; %common.ret
	sl_eop 
.Ltmp197:
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.globl	gqa_decode_int8_pv.kd
	.type	gqa_decode_int8_pv.kd,@object
	.size	gqa_decode_int8_pv.kd, 64
gqa_decode_int8_pv.kd:
	.asciz	"\000\000\000"
	.long	0
	.asciz	"\000\000\000\000\000\000\000"
	.quad	gqa_decode_int8_pv@rel64-gqa_decode_int8_pv.kd
	.asciz	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.long	537390
	.asciz	"\003\000\364\006\211\000\000\000\000\000\000"
	.text
.Lfunc_end0:
	.size	gqa_decode_int8_pv, .Lfunc_end0-gqa_decode_int8_pv
	.cfi_endproc
                                        ; -- End function
	.section	.Iluvatar.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 21088
; NumSgprs: 98
; NumVgprs: 185
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 12
; IeeeMode: 1
; SLBByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 12
; VGPRBlocks: 46
; NumSGPRsForWarpsPerNU: 94
; NumVGPRsForWarpsPerNR: 185
; ReqNTIDx: 0
; MaxNTIDx: 0
; MinCTASm: 0
; ActiveWarp: 1
; WarpLimiterHint : 0
	.type	gPrintBuf,@object               ; @gPrintBuf
	.data
	.weak	gPrintBuf
	.p2align	3, 0x0
gPrintBuf:
	.quad	0
	.size	gPrintBuf, 8

	.type	gAssertReason,@object           ; @gAssertReason
	.weak	gAssertReason
	.p2align	3, 0x0
gAssertReason:
	.quad	0
	.size	gAssertReason, 8

	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	8                               ; DW_FORM_string
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	16                              ; DW_AT_stmt_list
	.byte	6                               ; DW_FORM_data4
	.byte	27                              ; DW_AT_comp_dir
	.byte	8                               ; DW_FORM_string
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	32                              ; DW_AT_inline
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	1                               ; DW_CHILDREN_yes
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	6                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	7                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	5                               ; DW_FORM_data2
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
	.long	379                             ; Length of Unit
	.short	2                               ; DWARF version number
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	8                               ; Address Size (in bytes)
	.byte	1                               ; Abbrev [1] 0xb:0x174 DW_TAG_compile_unit
	.ascii	"triton"                        ; DW_AT_producer
	.byte	0
	.short	2                               ; DW_AT_language
	.ascii	"biv150_int8_pv.py"             ; DW_AT_name
	.byte	0
	.long	.debug_line                     ; DW_AT_stmt_list
	.ascii	"/workspace/experiments/minicpm-s2/code/owned55-int8-pv-20261027/tools/kernels" ; DW_AT_comp_dir
	.byte	0
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.byte	2                               ; Abbrev [2] 0x89:0x15 DW_TAG_subprogram
	.ascii	"gqa_decode_int8_pv"            ; DW_AT_name
	.byte	0
	.byte	1                               ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0x9e:0xe0 DW_TAG_subprogram
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.long	137                             ; DW_AT_abstract_origin
	.byte	4                               ; Abbrev [4] 0xb3:0x18 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.quad	.Ltmp1                          ; DW_AT_low_pc
	.quad	.Ltmp2                          ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	76                              ; DW_AT_call_line
	.byte	41                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xcb:0x26 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges0                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	134                             ; DW_AT_call_line
	.byte	81                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xd7:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges1                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	16                              ; DW_AT_call_line
	.byte	37                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0xe3:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges2                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0xf1:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges3                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	130                             ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0xfd:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges4                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x10a:0x1a DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges5                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	133                             ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0x116:0xd DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges6                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x124:0x26 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges7                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	169                             ; DW_AT_call_line
	.byte	81                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0x130:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges8                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	16                              ; DW_AT_call_line
	.byte	37                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x13c:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges9                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x14a:0x19 DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges10                ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	165                             ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x156:0xc DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges11                ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x163:0x1a DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges12                ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	168                             ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0x16f:0xd DW_TAG_inlined_subroutine
	.long	137                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges13                ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp31-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	.Ltmp73-.Lfunc_begin0
	.quad	.Ltmp74-.Lfunc_begin0
	.quad	.Ltmp75-.Lfunc_begin0
	.quad	.Ltmp76-.Lfunc_begin0
	.quad	.Ltmp77-.Lfunc_begin0
	.quad	.Ltmp78-.Lfunc_begin0
	.quad	.Ltmp79-.Lfunc_begin0
	.quad	.Ltmp80-.Lfunc_begin0
	.quad	.Ltmp81-.Lfunc_begin0
	.quad	.Ltmp82-.Lfunc_begin0
	.quad	.Ltmp83-.Lfunc_begin0
	.quad	.Ltmp84-.Lfunc_begin0
	.quad	.Ltmp85-.Lfunc_begin0
	.quad	.Ltmp86-.Lfunc_begin0
	.quad	.Ltmp87-.Lfunc_begin0
	.quad	.Ltmp88-.Lfunc_begin0
	.quad	.Ltmp89-.Lfunc_begin0
	.quad	.Ltmp90-.Lfunc_begin0
	.quad	.Ltmp91-.Lfunc_begin0
	.quad	.Ltmp92-.Lfunc_begin0
	.quad	.Ltmp93-.Lfunc_begin0
	.quad	.Ltmp94-.Lfunc_begin0
	.quad	.Ltmp95-.Lfunc_begin0
	.quad	.Ltmp96-.Lfunc_begin0
	.quad	.Ltmp97-.Lfunc_begin0
	.quad	.Ltmp98-.Lfunc_begin0
	.quad	.Ltmp99-.Lfunc_begin0
	.quad	.Ltmp100-.Lfunc_begin0
	.quad	.Ltmp101-.Lfunc_begin0
	.quad	.Ltmp102-.Lfunc_begin0
	.quad	.Ltmp103-.Lfunc_begin0
	.quad	.Ltmp104-.Lfunc_begin0
	.quad	.Ltmp105-.Lfunc_begin0
	.quad	.Ltmp106-.Lfunc_begin0
	.quad	.Ltmp107-.Lfunc_begin0
	.quad	.Ltmp108-.Lfunc_begin0
	.quad	.Ltmp109-.Lfunc_begin0
	.quad	.Ltmp110-.Lfunc_begin0
	.quad	.Ltmp111-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp34-.Lfunc_begin0
	.quad	.Ltmp35-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp68-.Lfunc_begin0
	.quad	.Ltmp69-.Lfunc_begin0
	.quad	.Ltmp70-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp33-.Lfunc_begin0
	.quad	.Ltmp35-.Lfunc_begin0
	.quad	.Ltmp36-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp44-.Lfunc_begin0
	.quad	.Ltmp45-.Lfunc_begin0
	.quad	.Ltmp46-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp52-.Lfunc_begin0
	.quad	.Ltmp53-.Lfunc_begin0
	.quad	.Ltmp54-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp60-.Lfunc_begin0
	.quad	.Ltmp61-.Lfunc_begin0
	.quad	.Ltmp62-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp68-.Lfunc_begin0
	.quad	.Ltmp69-.Lfunc_begin0
	.quad	.Ltmp70-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges3:
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	.Ltmp25-.Lfunc_begin0
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	.Ltmp27-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges4:
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	.Ltmp17-.Lfunc_begin0
	.quad	.Ltmp18-.Lfunc_begin0
	.quad	.Ltmp19-.Lfunc_begin0
	.quad	.Ltmp20-.Lfunc_begin0
	.quad	.Ltmp21-.Lfunc_begin0
	.quad	.Ltmp22-.Lfunc_begin0
	.quad	.Ltmp23-.Lfunc_begin0
	.quad	.Ltmp24-.Lfunc_begin0
	.quad	.Ltmp25-.Lfunc_begin0
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	.Ltmp27-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges5:
	.quad	.Ltmp28-.Lfunc_begin0
	.quad	.Ltmp30-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp38-.Lfunc_begin0
	.quad	.Ltmp39-.Lfunc_begin0
	.quad	.Ltmp40-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp66-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges6:
	.quad	.Ltmp28-.Lfunc_begin0
	.quad	.Ltmp29-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp38-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp42-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp48-.Lfunc_begin0
	.quad	.Ltmp49-.Lfunc_begin0
	.quad	.Ltmp50-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp56-.Lfunc_begin0
	.quad	.Ltmp57-.Lfunc_begin0
	.quad	.Ltmp58-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp64-.Lfunc_begin0
	.quad	.Ltmp65-.Lfunc_begin0
	.quad	.Ltmp66-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges7:
	.quad	.Ltmp112-.Lfunc_begin0
	.quad	.Ltmp113-.Lfunc_begin0
	.quad	.Ltmp114-.Lfunc_begin0
	.quad	.Ltmp115-.Lfunc_begin0
	.quad	.Ltmp137-.Lfunc_begin0
	.quad	.Ltmp138-.Lfunc_begin0
	.quad	.Ltmp139-.Lfunc_begin0
	.quad	.Ltmp140-.Lfunc_begin0
	.quad	.Ltmp141-.Lfunc_begin0
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp145-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp170-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp180-.Lfunc_begin0
	.quad	.Ltmp181-.Lfunc_begin0
	.quad	.Ltmp182-.Lfunc_begin0
	.quad	.Ltmp183-.Lfunc_begin0
	.quad	.Ltmp184-.Lfunc_begin0
	.quad	.Ltmp185-.Lfunc_begin0
	.quad	.Ltmp186-.Lfunc_begin0
	.quad	.Ltmp187-.Lfunc_begin0
	.quad	.Ltmp188-.Lfunc_begin0
	.quad	.Ltmp189-.Lfunc_begin0
	.quad	.Ltmp190-.Lfunc_begin0
	.quad	.Ltmp191-.Lfunc_begin0
	.quad	.Ltmp192-.Lfunc_begin0
	.quad	.Ltmp193-.Lfunc_begin0
	.quad	.Ltmp194-.Lfunc_begin0
	.quad	.Ltmp195-.Lfunc_begin0
	.quad	.Ltmp196-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges8:
	.quad	.Ltmp142-.Lfunc_begin0
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp146-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp170-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp177-.Lfunc_begin0
	.quad	.Ltmp178-.Lfunc_begin0
	.quad	.Ltmp179-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges9:
	.quad	.Ltmp142-.Lfunc_begin0
	.quad	.Ltmp143-.Lfunc_begin0
	.quad	.Ltmp146-.Lfunc_begin0
	.quad	.Ltmp147-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp151-.Lfunc_begin0
	.quad	.Ltmp152-.Lfunc_begin0
	.quad	.Ltmp153-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp159-.Lfunc_begin0
	.quad	.Ltmp160-.Lfunc_begin0
	.quad	.Ltmp161-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp167-.Lfunc_begin0
	.quad	.Ltmp168-.Lfunc_begin0
	.quad	.Ltmp169-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp177-.Lfunc_begin0
	.quad	.Ltmp178-.Lfunc_begin0
	.quad	.Ltmp179-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges10:
	.quad	.Ltmp116-.Lfunc_begin0
	.quad	.Ltmp118-.Lfunc_begin0
	.quad	.Ltmp119-.Lfunc_begin0
	.quad	.Ltmp134-.Lfunc_begin0
	.quad	.Ltmp135-.Lfunc_begin0
	.quad	.Ltmp136-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges11:
	.quad	.Ltmp116-.Lfunc_begin0
	.quad	.Ltmp117-.Lfunc_begin0
	.quad	.Ltmp119-.Lfunc_begin0
	.quad	.Ltmp120-.Lfunc_begin0
	.quad	.Ltmp121-.Lfunc_begin0
	.quad	.Ltmp122-.Lfunc_begin0
	.quad	.Ltmp123-.Lfunc_begin0
	.quad	.Ltmp124-.Lfunc_begin0
	.quad	.Ltmp125-.Lfunc_begin0
	.quad	.Ltmp126-.Lfunc_begin0
	.quad	.Ltmp127-.Lfunc_begin0
	.quad	.Ltmp128-.Lfunc_begin0
	.quad	.Ltmp129-.Lfunc_begin0
	.quad	.Ltmp130-.Lfunc_begin0
	.quad	.Ltmp131-.Lfunc_begin0
	.quad	.Ltmp132-.Lfunc_begin0
	.quad	.Ltmp133-.Lfunc_begin0
	.quad	.Ltmp134-.Lfunc_begin0
	.quad	.Ltmp135-.Lfunc_begin0
	.quad	.Ltmp136-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges12:
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp145-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp150-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp158-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp166-.Lfunc_begin0
	.quad	.Ltmp171-.Lfunc_begin0
	.quad	.Ltmp173-.Lfunc_begin0
	.quad	.Ltmp174-.Lfunc_begin0
	.quad	.Ltmp176-.Lfunc_begin0
	.quad	.Ltmp180-.Lfunc_begin0
	.quad	.Ltmp181-.Lfunc_begin0
	.quad	.Ltmp184-.Lfunc_begin0
	.quad	.Ltmp185-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges13:
	.quad	.Ltmp144-.Lfunc_begin0
	.quad	.Ltmp145-.Lfunc_begin0
	.quad	.Ltmp148-.Lfunc_begin0
	.quad	.Ltmp149-.Lfunc_begin0
	.quad	.Ltmp154-.Lfunc_begin0
	.quad	.Ltmp155-.Lfunc_begin0
	.quad	.Ltmp156-.Lfunc_begin0
	.quad	.Ltmp157-.Lfunc_begin0
	.quad	.Ltmp162-.Lfunc_begin0
	.quad	.Ltmp163-.Lfunc_begin0
	.quad	.Ltmp164-.Lfunc_begin0
	.quad	.Ltmp165-.Lfunc_begin0
	.quad	.Ltmp171-.Lfunc_begin0
	.quad	.Ltmp172-.Lfunc_begin0
	.quad	.Ltmp174-.Lfunc_begin0
	.quad	.Ltmp175-.Lfunc_begin0
	.quad	.Ltmp180-.Lfunc_begin0
	.quad	.Ltmp181-.Lfunc_begin0
	.quad	.Ltmp184-.Lfunc_begin0
	.quad	.Ltmp185-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	".note.GNU-stack","",@progbits
	.iluvatar_isa "bi-iluvatar-ilurt--ivcore-1-1-0"
	.iluvatar_hsa_metadata
---
iluvatar.kernels:
  - .args:
      - .address_space:  global
        .name:           KArg_0
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_1
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_2
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_3
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_4
        .offset:         32
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_5
        .offset:         40
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_6
        .offset:         48
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_7
        .offset:         56
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_8
        .offset:         64
        .size:           8
        .value_kind:     global_buffer
      - .name:           KArg_9
        .offset:         72
        .size:           4
        .value_kind:     by_value
      - .name:           KArg_10
        .offset:         80
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_11
        .offset:         88
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_12
        .offset:         96
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_13
        .offset:         104
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_14
        .offset:         112
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_15
        .offset:         120
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_16
        .offset:         128
        .size:           8
        .value_kind:     by_value
      - .address_space:  global
        .name:           KArg_17
        .offset:         136
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_18
        .offset:         144
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 152
    .max_flat_workgroup_size: 0
    .name:           gqa_decode_int8_pv
    .private_segment_fixed_size: 0
    .sgpr_count:     98
    .sgpr_spill_count: 48
    .symbol:         gqa_decode_int8_pv.kd
    .vgpr_count:     185
    .vgpr_spill_count: 0
    .warp_size:      64
iluvatar.version:
  - 1
  - 0
...

	.end_iluvatar_hsa_metadata
