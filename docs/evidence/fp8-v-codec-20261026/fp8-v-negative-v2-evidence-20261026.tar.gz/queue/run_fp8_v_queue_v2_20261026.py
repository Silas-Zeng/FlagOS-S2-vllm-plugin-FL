from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
R=Path('/workspace/experiments/minicpm-s2');source=R/'code/fp8-v-codec-v2-20261026';sha='513d508e67ca89f28d9832dea3543b9178ff8747';exports=R/'exports';statepath=exports/'fp8-v-queue-v2-state.json'
state={'complete':False,'source_commit':sha,'source':str(source),'team_main':'34942f7e28da5c954ab05878dec75807da9d7a93','owner_pid':os.getpid(),'owner_sid':os.getsid(0),'owner_start_ticks':Path('/proc/self/stat').read_text().split()[21],'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'steps':[],'phase':'starting'}
def save():
 t=statepath.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2));t.replace(statepath)
def run(name,argv,timeout):
 out=R/name;assert not out.exists(),name
 env=os.environ.copy();env['TRITON_CACHE_DIR']=str(R/(name+'-triton'));env['FLAGGEMS_CACHE_DIR']=str(R/(name+'-gems'));env['PYTHONPATH']=str(source/'tools')+':'+str(source)
 step={'name':name,'command':argv,'started':time.time(),'env':{k:env[k] for k in ['TRITON_CACHE_DIR','FLAGGEMS_CACHE_DIR','PYTHONPATH']}};state['steps'].append(step);state['phase']=name;save()
 with (exports/(name+'.log')).open('w') as log:
  child=subprocess.Popen(argv,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT);step['pid']=child.pid;save()
  try:step['returncode']=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:child.terminate();child.wait(timeout=30);raise
 step['ended']=time.time();save();assert step['returncode']==0,(name,step['returncode'])
 result=json.loads((out/'result.json').read_text());assert result.get('passed',result.get('completed')),(name,result.get('errors'))
 step['passed']=True;save();time.sleep(2)
try:
 assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==sha
 run('fp8-v-codec-v2-20261026',['/usr/local/bin/python','-u',str(source/'tools/check_biv150_fp8_v_codec_gpu.py'),'--run-gpu','--source',str(source),'--commit',sha,'--out',str(R/'fp8-v-codec-v2-20261026')],600)
 for decoder,case in [('bits','ragged'),('bits','steady4k'),('bits','steady16k'),('lut','ragged'),('lut','steady4k'),('lut','steady16k')]:
  name=f'fp8-v-{decoder}-{case}-v2-20261026'
  run(name,['/usr/local/bin/python','-u',str(source/'tools/bench_biv150_fp8_v_attention.py'),'--run-gpu','--decoder',decoder,'--case',case,'--out',str(R/name)],900)
 state['complete']=True;state['phase']='completed'
except Exception as e:state['error']=repr(e);state['traceback']=traceback.format_exc();state['phase']='failed'
finally:save()
