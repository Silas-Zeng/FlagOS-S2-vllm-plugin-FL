import os,sys,pathlib,subprocess,json,datetime,traceback
root=pathlib.Path('/workspace/experiments/minicpm-s2/prefill-k128-policy-v1-20261027')
src=pathlib.Path('/workspace/experiments/minicpm-s2/code/prefill-k128-service-v2-20261027')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(pid):
 try:
  f=pathlib.Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split()
  return dict(pid=pid,state=f[0],start_ticks=f[19],sid=os.getsid(pid))
 except FileNotFoundError:return None
state=dict(phase='preflight',utc=now(),controller=identity(os.getpid()),source=str(src),commit='b0d34e6e9213e8026ea65989f3917995cf8fd640',official_score=False)
def save():
 state['updated_utc']=now();p=root/'state.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(root/'state.json')
save()
try:
 import socket
 with socket.socket() as s:assert s.connect_ex(('127.0.0.1',9031))!=0
 smi=subprocess.check_output(['/usr/local/corex/bin/ixsmi'],text=True)
 assert 'No running processes found' in smi
 assert subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip()==state['commit']
 env=dict(os.environ)
 for k in list(env):
  if k.startswith('VLLM_FL_BIV150_'):del env[k]
 env.update(PYTHONPATH=str(src)+':'+str(src/'tools'),VLLM_PLUGINS='fl',PYTHONUNBUFFERED='1',
            TRITON_CACHE_DIR=str(root/'triton-cache'),TORCHINDUCTOR_CACHE_DIR=str(root/'inductor-cache'),FLAGGEMS_CACHE_DIR=str(root/'flaggems-cache'),OMP_NUM_THREADS='4')
 command=[sys.executable,str(src/'tools/check_biv150_k128_policy_gpu.py'),'--run-gpu','--out',str(root/'result')]
 state['command']=command;state['env']={k:env[k] for k in ('PYTHONPATH','TRITON_CACHE_DIR','TORCHINDUCTOR_CACHE_DIR','FLAGGEMS_CACHE_DIR','VLLM_PLUGINS')}
 with (root/'probe.log').open('xb') as log:
  p=subprocess.Popen(command,env=env,cwd=src,stdout=log,stderr=subprocess.STDOUT)
  state.update(phase='running',child=identity(p.pid));save()
  rc=p.wait()
 state.update(phase='completed' if rc==0 else 'failed',returncode=rc,finished_utc=now())
 state['gpu_after']=subprocess.check_output(['/usr/local/corex/bin/ixsmi'],text=True)
 save()
except Exception as e:
 state.update(phase='failed',error=repr(e),traceback=traceback.format_exc());save();raise
