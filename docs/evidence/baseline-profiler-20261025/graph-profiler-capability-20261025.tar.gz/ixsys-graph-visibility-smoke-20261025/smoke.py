import torch
x=torch.randn((64,2048),device='cuda',dtype=torch.bfloat16);w=torch.randn((2048,2560),device='cuda',dtype=torch.bfloat16)
for _ in range(10):y=torch.mm(x,w);z=y+1
torch.cuda.synchronize()
g=torch.cuda.CUDAGraph()
with torch.cuda.graph(g):y=torch.mm(x,w);z=y+1
for _ in range(5):g.replay()
torch.cuda.synchronize()
torch.cuda.nvtx.range_push('EAGER_THREE')
for _ in range(3):y=torch.mm(x,w);z=y+1
torch.cuda.synchronize();torch.cuda.nvtx.range_pop()
torch.cuda.nvtx.range_push('GRAPH_THREE')
for _ in range(3):g.replay()
torch.cuda.synchronize();torch.cuda.nvtx.range_pop()
print('SMOKE_DONE',flush=True)
