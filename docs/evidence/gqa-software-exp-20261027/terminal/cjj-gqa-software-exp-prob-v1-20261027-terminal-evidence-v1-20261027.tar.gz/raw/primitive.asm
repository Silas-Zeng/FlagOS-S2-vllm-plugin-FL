	.text
	.globl	_software_exp2_probe            ; -- Begin function _software_exp2_probe
	.p2align	3
	.type	_software_exp2_probe,@function
	.iluvatar_kernel _software_exp2_probe
_software_exp2_probe:                   ; @_software_exp2_probe
.Lfunc_begin0:
	.file	1 "/workspace/experiments/minicpm-s2/cjj-gqa-software-exp-prob-v1-20261027" "generated-gqa-software-exp.py"
	.loc	1 24 0                          ; generated-gqa-software-exp.py:24:0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_return_column 32
	.iluvatar_kernel_code_t
		iluvatar_code_version_major = 1
		iluvatar_code_version_minor = 3
		iluvatar_machine_kind = 1
		iluvatar_machine_version_major = 1
		iluvatar_machine_version_minor = 1
		iluvatar_machine_version_stepping = 0
		kernel_code_entry_byte_offset = 256
		kernel_code_prefetch_byte_size = 0
		granulated_workitem_vgpr_count = 1
		granulated_warp_sgpr_count = 2
		float_mode = 12
		debug_mode = 0
		has_mbar = 0
		user_sgpr_count = 6
		enable_sgpr_workgroup_id_x = 1
		enable_sgpr_workgroup_id_y = 0
		enable_sgpr_workgroup_id_z = 0
		enable_sgpr_workgroup_info = 1
		enable_vgpr_workitem_id = 3
		granulated_slb_size = 0
		enable_exception = 128
		enable_sgpr_private_segment_buffer = 1
		enable_sgpr_globalvariable_ptr = 0
		enable_sgpr_kernarg_segment_ptr = 1
		enable_sgpr_constvariable_ptr = 0
		enable_sgpr_private_segment_size = 0
		enable_sgpr_grid_workgroup_count_x = 0
		enable_sgpr_grid_workgroup_count_y = 0
		enable_sgpr_grid_workgroup_count_z = 0
		private_element_size = 1
		is_ptr64 = 1
		is_dynamic_callstack = 0
		is_debug_enabled = 0
		enable_private_swizzle = 1
		has_called_assert = 0
		has_called_printf = 0
		has_called_malloc = 0
		enable_srf_flat_shared = 0
		enable_srf_flat_scratch = 0
		has_wgmma = 0
		has_dva = 0
		enable_dynamic_smem_size = 0
		workitem_private_segment_byte_size = 0
		workgroup_group_segment_byte_size = 0
		kernarg_segment_byte_size = 32
		workgroup_fbarrier_count = 0
		warp_sgpr_count = 24
		workitem_vgpr_count = 7
		reserved_vgpr_first = 0
		reserved_vgpr_count = 0
		reserved_sgpr_first = 0
		reserved_sgpr_count = 0
		debug_warp_private_segment_offset_sgpr = 0
		debug_private_segment_buffer_sgpr = 0
		kernarg_segment_alignment = 3
		group_segment_alignment = 4
		private_segment_alignment = 4
		warp_size = 6
		call_convention = -1
		runtime_loader_kernel_symbol = 0
	.end_iluvatar_kernel_code_t
; %bb.0:
	; Func LiveIn Regs:
	;  blockIdx.x : s6
	ml_vrf_init_u32 v0, tcr
.Ltmp0:
	.loc	1 25 35 prologue_end            ; generated-gqa-software-exp.py:25:35
	ml_mov_b32 v1, 0x2010004
	ml_byte_permute_b32 v0, s6, v0, v1
	.loc	1 26 32                         ; generated-gqa-software-exp.py:26:32
	ml_cmp_lt_i32 tcr, v0, 0x8187
	sl_mov_b64 s[0:1], tcr
	ml_cmp_gt_i32 tcr, v0, 0x8186
	.loc	1 26 16 is_stmt 0               ; generated-gqa-software-exp.py:26:16
	sl_and_savetmsk_b64 {s[2:3], wcr}, tcr, tmsk
	sl_xor_b64 {s[2:3], wcr}, tmsk, s[2:3]
                                        ; implicit-def: $vgpr1
	; mask branch BB0_2
BB0_1:                                  ; %._crit_edge
	.loc	1 27 17 is_stmt 1               ; generated-gqa-software-exp.py:27:17
	ml_mov_b32 v1, 0x0
BB0_2:                                  ; %Flow
	.loc	1 0 17 is_stmt 0                ; generated-gqa-software-exp.py:0:17
	sl_or_savetmsk_b64 {s[2:3], wcr}, s[2:3], tmsk
	sl_lsa_load_b32x8 s[12:19], s[4:5], noreg, #0, ca
	.loc	1 26 16 is_stmt 1               ; generated-gqa-software-exp.py:26:16
	ml_mov_b32 v2, 0x0
	ml_mov_b32 v3, 0x0
	sl_xor_savetmsk_b64 {s[4:5], wcr}, s[2:3], tmsk
	; mask branch BB0_4
BB0_3:
	.loc	1 26 20 is_stmt 0               ; generated-gqa-software-exp.py:26:20
	ml_sra_b32 v1, v0, 0x1f
	ml_shl_b32 v3, v0, 0x2
	ml_shl_b32 v4, v1, 0x2
	sl_wait smcnt(0)
	ml_addo_u32 {v3, tcr}, s12, v3
	ml_srl_b32 v5, v0, 0x1e
	ml_or_b32 v4, v4, v5
	ml_mov_b32 v5, s13
	ml_addc_i32 v4, v5, v4, tcr
	.loc	1 26 16                         ; generated-gqa-software-exp.py:26:16
	ml_lsa_load_a64_dword  v3, v[3:4], kop=0
BB0_4:
	.loc	1 0 16                          ; generated-gqa-software-exp.py:0:16
	sl_or_b64 {tmsk, wcr}, tmsk, s[2:3]
	.loc	1 27 17 is_stmt 1               ; generated-gqa-software-exp.py:27:17
	ml_shl_b32 v4, v0, 0x2
	ml_shl_b32 v1, v1, 0x2
	ml_srl_b32 v0, v0, 0x1e
	ml_addo_u32 {v4, tcr}, s14, v4
	ml_or_b32 v0, v1, v0
	ml_mov_b32 v1, s15
.Ltmp1:
	.loc	1 9 16                          ; generated-gqa-software-exp.py:9:16 @[ generated-gqa-software-exp.py:27:47 ]
	sl_reg_read s2, hwreg(HW_REG_MODE)
.Ltmp2:
	.loc	1 27 17                         ; generated-gqa-software-exp.py:27:17
	ml_addc_i32 v0, v1, v0, tcr
.Ltmp3:
	.loc	1 8 36                          ; generated-gqa-software-exp.py:8:36 @[ generated-gqa-software-exp.py:27:47 ]
	sl_wait vmcnt(0)
	ml_min_f32 v1, v3, 0x0
	.loc	1 9 16                          ; generated-gqa-software-exp.py:9:16 @[ generated-gqa-software-exp.py:27:47 ]
	sl_or_b32 {s3, wcr}, s2, 0x3
	.loc	1 8 42                          ; generated-gqa-software-exp.py:8:42 @[ generated-gqa-software-exp.py:27:47 ]
	ml_max_f32 v1, v1, 0xc2fc0000
	.loc	1 9 16                          ; generated-gqa-software-exp.py:9:16 @[ generated-gqa-software-exp.py:27:47 ]
	sl_reg_write hwreg(HW_REG_MODE), s3
	ml_cvt_i32_f32  v5, v1
	sl_reg_write hwreg(HW_REG_MODE), s2
	.loc	1 10 20                         ; generated-gqa-software-exp.py:10:20 @[ generated-gqa-software-exp.py:27:47 ]
	ml_cvt_f32_i32  v6, v5
	.loc	1 10 15 is_stmt 0               ; generated-gqa-software-exp.py:10:15 @[ generated-gqa-software-exp.py:27:47 ]
	ml_sub_f32 v1, v1, v6
	sl_mov_b32 s2, 0x3a7837d7
	.loc	1 12 21 is_stmt 1               ; generated-gqa-software-exp.py:12:21 @[ generated-gqa-software-exp.py:27:47 ]
	ml_mov_b32 v6, 0x3c16e21a
	ml_fma_f32 v6, s2, v1, v6
	sl_mov_b32 s2, 0x3d628048
	.loc	1 13 21                         ; generated-gqa-software-exp.py:13:21 @[ generated-gqa-software-exp.py:27:47 ]
	ml_fma_f32 v6, v6, v1, s2
	sl_mov_b32 s2, 0x3e75f179
	.loc	1 14 21                         ; generated-gqa-software-exp.py:14:21 @[ generated-gqa-software-exp.py:27:47 ]
	ml_fma_f32 v6, v6, v1, s2
	sl_mov_b32 s2, 0x3f3171d4
	.loc	1 15 21                         ; generated-gqa-software-exp.py:15:21 @[ generated-gqa-software-exp.py:27:47 ]
	ml_fma_f32 v6, v6, v1, s2
	.loc	1 16 21                         ; generated-gqa-software-exp.py:16:21 @[ generated-gqa-software-exp.py:27:47 ]
	ml_fma_f32 v1, v6, v1, 1.0
	.loc	1 17 26                         ; generated-gqa-software-exp.py:17:26 @[ generated-gqa-software-exp.py:27:47 ]
	ml_shl_b32 v5, v5, 0x17
	ml_add_i32 v5, v5, 0x3f800000
	.loc	1 18 14                         ; generated-gqa-software-exp.py:18:14 @[ generated-gqa-software-exp.py:27:47 ]
	ml_mul_f32 v1, v1, v5
	.loc	1 19 36                         ; generated-gqa-software-exp.py:19:36 @[ generated-gqa-software-exp.py:27:47 ]
	ml_cmp_uge_f32 tcr, v3, 0xc2fc0000
	ml_csel_b32 v1, v1, v2, tcr
	.loc	1 21 25                         ; generated-gqa-software-exp.py:21:25 @[ generated-gqa-software-exp.py:27:47 ]
	ml_cmp_le_f32 tcr, v3, 0x0
.Ltmp4:
	.loc	1 27 20                         ; generated-gqa-software-exp.py:27:20
	ml_mov_v2s_b32 s4, v4, 0x0
	ml_mov_b32 v2, 0x7fc00000
.Ltmp5:
	.loc	1 21 35                         ; generated-gqa-software-exp.py:21:35 @[ generated-gqa-software-exp.py:27:47 ]
	ml_csel_b32 v1, v1, v2, tcr
.Ltmp6:
	.loc	1 27 20                         ; generated-gqa-software-exp.py:27:20
	ml_mov_v2s_b32 s5, v0, 0x0
	ml_mov_b32 v0, s4
	ml_sub_i32 v0, v4, v0
	sl_mov_b32 s7, 0xffffffff
	sl_and_savetmsk_b64 {s[8:9], wcr}, s[0:1], tmsk
	ml_lsa_store_dword v1, s[4:7], signed v0, noreg, #0, wb
	sl_or_b64 {tmsk, wcr}, tmsk, s[8:9]
	.loc	1 27 4 is_stmt 0                ; generated-gqa-software-exp.py:27:4
	sl_eop 
.Ltmp7:
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.globl	_software_exp2_probe.kd
	.type	_software_exp2_probe.kd,@object
	.size	_software_exp2_probe.kd, 64
_software_exp2_probe.kd:
	.asciz	"\000\000\000"
	.long	0
	.asciz	"\000\000\000\000\000\000\000"
	.quad	_software_exp2_probe@rel64-_software_exp2_probe.kd
	.asciz	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.long	536705
	.asciz	"\003\000\224\006\211\000\000\000\000\000\000"
	.text
.Lfunc_end0:
	.size	_software_exp2_probe, .Lfunc_end0-_software_exp2_probe
	.cfi_endproc
                                        ; -- End function
	.section	.Iluvatar.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 552
; NumSgprs: 24
; NumVgprs: 7
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 12
; IeeeMode: 1
; SLBByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 2
; VGPRBlocks: 1
; NumSGPRsForWarpsPerNU: 20
; NumVGPRsForWarpsPerNR: 7
; ReqNTIDx: 0
; MaxNTIDx: 0
; MinCTASm: 0
; ActiveWarp: 8
; WarpLimiterHint : 0
	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	8                               ; DW_FORM_string
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	16                              ; DW_AT_stmt_list
	.byte	6                               ; DW_FORM_data4
	.byte	27                              ; DW_AT_comp_dir
	.byte	8                               ; DW_FORM_string
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	32                              ; DW_AT_inline
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
	.long	197                             ; Length of Unit
	.short	2                               ; DWARF version number
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	8                               ; Address Size (in bytes)
	.byte	1                               ; Abbrev [1] 0xb:0xbe DW_TAG_compile_unit
	.ascii	"triton"                        ; DW_AT_producer
	.byte	0
	.short	2                               ; DW_AT_language
	.ascii	"generated-gqa-software-exp.py" ; DW_AT_name
	.byte	0
	.long	.debug_line                     ; DW_AT_stmt_list
	.ascii	"/workspace/experiments/minicpm-s2/cjj-gqa-software-exp-prob-v1-20261027" ; DW_AT_comp_dir
	.byte	0
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.byte	2                               ; Abbrev [2] 0x8f:0x17 DW_TAG_subprogram
	.ascii	"_software_exp2_probe"          ; DW_AT_name
	.byte	0
	.byte	1                               ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0xa6:0x22 DW_TAG_subprogram
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.long	143                             ; DW_AT_abstract_origin
	.byte	4                               ; Abbrev [4] 0xbb:0xc DW_TAG_inlined_subroutine
	.long	143                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges0                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	27                              ; DW_AT_call_line
	.byte	47                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Ltmp1-.Lfunc_begin0
	.quad	.Ltmp2-.Lfunc_begin0
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	".note.GNU-stack","",@progbits
	.iluvatar_isa "bi-iluvatar-ilurt--ivcore-1-1-0"
	.iluvatar_hsa_metadata
---
iluvatar.kernels:
  - .args:
      - .address_space:  global
        .name:           KArg_0
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_1
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_2
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_3
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 32
    .max_flat_workgroup_size: 0
    .name:           _software_exp2_probe
    .private_segment_fixed_size: 0
    .sgpr_count:     24
    .sgpr_spill_count: 0
    .symbol:         _software_exp2_probe.kd
    .vgpr_count:     7
    .vgpr_spill_count: 0
    .warp_size:      64
iluvatar.version:
  - 1
  - 0
...

	.end_iluvatar_hsa_metadata
