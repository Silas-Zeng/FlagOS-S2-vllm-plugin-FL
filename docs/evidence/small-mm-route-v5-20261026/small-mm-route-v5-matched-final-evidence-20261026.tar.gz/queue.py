"""Serial actual SDK binding qualification and same-source native-on paired service test."""
import datetime, hashlib, json, os, socket, subprocess, time
from pathlib import Path

R=Path('/workspace/experiments/minicpm-s2')
SOURCE=R/'code/small-mm-route-v5-20261026'
COMMIT='97d5d479bdf03567859085a787a408e7bd16eeea'
STATE=R/'exports/small-mm-route-queue-v5-state.json'
SNAPSHOT=R/'exports/small-bf16-fullwarm-tuning-snapshot-v6-20261025'
state={'completed':[], 'commit':COMMIT, 'queue_pid':os.getpid(),
       'queue_start_ticks':int(Path(f'/proc/{os.getpid()}/stat').read_text().split()[21]),
       'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
def save(phase,**kw):
    state.update(phase=phase,updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),**kw)
    temporary=STATE.with_suffix('.tmp');temporary.write_text(json.dumps(state,indent=2));temporary.replace(STATE)
def identity(pid):
    try:
        v=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'state':v[0],'sid':int(v[3]),'start_ticks':int(v[19])}
    except FileNotFoundError:return None
def live(pid,ticks):
    value=identity(pid)
    return bool(value and value['state']!='Z' and value['start_ticks']==ticks)
def idle():
    with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',9031))!=0
    assert 'No running processes found' in subprocess.check_output(['ixsmi'],text=True)
def run(tag,command):
    idle()
    with (R/f'exports/small-mm-route-{tag}-v5.log').open('w') as log:
        child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    owner=identity(child.pid);owner['command']=command
    (R/f'exports/small-mm-route-{tag}-v5-owner.json').write_text(json.dumps(owner,indent=2))
    save(tag,child=owner)
    while child.poll() is None:time.sleep(3)
    assert child.returncode==0,(tag,child.returncode)
    idle()
try:
    save('waiting_owned_v4')
    while live(409412,329788757):time.sleep(10)
    previous=json.loads((R/'exports/small-mm-route-queue-v4-state.json').read_text())
    assert previous['phase'] in ('completed','failed')
    state['previous_phase']=previous['phase'];state['previous_error']=previous.get('error')
    idle()
    assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==COMMIT
    assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()
    for rows in (1,2,4,8):
        output=R/f'small-mm-route-m{rows}-v5-20261026'
        command=['/usr/local/bin/python',str(SOURCE/'tools/check_biv150_small_mm_route_gpu.py'),
                 '--run-gpu','--source',str(SOURCE),'--commit',COMMIT,'--out',str(output),
                 '--rows',str(rows),'--tuning-snapshot',str(SNAPSHOT)]
        run(f'component-m{rows}',command)
        result=json.loads((output/'result.json').read_text())
        direct_out=[v for v in result['records'] if v['route']=='direct_out']
        assert result['complete'] and result['vendor_restored'] and result['owned_routes_passed'] and result['all_direct_functional_passed']
        assert len(direct_out)==8 and all(v['passed'] and v['selected_by_vendor_wrapper'] for v in direct_out)
        state['completed'].append({'rows':rows,'direct_out_passed':True,
                                  'all_direct_functional_passed':result['all_direct_functional_passed']})
        save('component-completed')
    for binding in ('mm','linear'):
        output=R/f'small-mm-route-{binding}-model-v5-20261026'
        command=['/usr/local/bin/python',str(SOURCE/'tools/run_biv150_small_bf16_acceptance.py'),
                 '--source',str(SOURCE),'--commit',COMMIT,'--out',str(output),
                 '--gate-library',str(R/'code/baseline-profiler-v2-20261025/build-native-w8a8/biv150_native_w8a8.so'),
                 '--native-mode','on','--stable-small-o','1','--small-binding',binding,
                 '--run-throughput','--full-workload-warmup',
                 '--fixtures',str(R/'exports/native-mixed-fixtures-20261025'),
                 '--tuning-snapshot',str(SNAPSHOT)]
        if binding=='mm':command.append('--run-accuracy')
        run('model-'+binding,command)
        result=json.loads((output/'state.json').read_text())
        assert result['complete'] and result['cleanup_complete'] and result['semantic_passed']
        state[binding+'_result']={key:result.get(key) for key in ('semantic_passed','precision_passed','accuracy','performance')}
        save('model-arm-completed')
    save('completed',child=None,acceptance_passed=False,comparison='same source, native-on both arms, mm versus linear binding')
except BaseException as error:
    save('failed',error=repr(error));raise
