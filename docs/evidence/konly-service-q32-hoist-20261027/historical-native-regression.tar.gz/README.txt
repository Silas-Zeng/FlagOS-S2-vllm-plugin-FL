Historical hoisted artifact: unit-regression input only. Never an actual new service artifact, override, metadata, hash admission or GPU acceptance.
