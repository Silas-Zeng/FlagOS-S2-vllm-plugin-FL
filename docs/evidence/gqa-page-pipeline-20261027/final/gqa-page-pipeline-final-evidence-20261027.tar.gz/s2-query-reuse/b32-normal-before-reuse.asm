	.text
	.globl	_gqa_decode_attention           ; -- Begin function _gqa_decode_attention
	.p2align	3
	.type	_gqa_decode_attention,@function
	.iluvatar_kernel _gqa_decode_attention
_gqa_decode_attention:                  ; @_gqa_decode_attention
.Lfunc_begin0:
	.file	1 "/workspace/experiments/minicpm-s2/gqa-page-pipeline-s2-query-reuse-v1-20261027" "generated-gqa-page-pipeline.py"
	.loc	1 6 0                           ; generated-gqa-page-pipeline.py:6:0
	.cfi_sections .debug_frame
	.cfi_startproc
	.cfi_return_column 32
	.iluvatar_kernel_code_t
		iluvatar_code_version_major = 1
		iluvatar_code_version_minor = 3
		iluvatar_machine_kind = 1
		iluvatar_machine_version_major = 1
		iluvatar_machine_version_minor = 1
		iluvatar_machine_version_stepping = 0
		kernel_code_entry_byte_offset = 256
		kernel_code_prefetch_byte_size = 0
		granulated_workitem_vgpr_count = 25
		granulated_warp_sgpr_count = 12
		float_mode = 12
		debug_mode = 0
		has_mbar = 0
		user_sgpr_count = 6
		enable_sgpr_workgroup_id_x = 1
		enable_sgpr_workgroup_id_y = 1
		enable_sgpr_workgroup_id_z = 1
		enable_sgpr_workgroup_info = 1
		enable_vgpr_workitem_id = 3
		granulated_slb_size = 0
		enable_exception = 128
		enable_sgpr_private_segment_buffer = 1
		enable_sgpr_globalvariable_ptr = 0
		enable_sgpr_kernarg_segment_ptr = 1
		enable_sgpr_constvariable_ptr = 0
		enable_sgpr_private_segment_size = 0
		enable_sgpr_grid_workgroup_count_x = 0
		enable_sgpr_grid_workgroup_count_y = 0
		enable_sgpr_grid_workgroup_count_z = 0
		private_element_size = 1
		is_ptr64 = 1
		is_dynamic_callstack = 0
		is_debug_enabled = 0
		enable_private_swizzle = 1
		has_called_assert = 0
		has_called_printf = 0
		has_called_malloc = 0
		enable_srf_flat_shared = 0
		enable_srf_flat_scratch = 0
		has_wgmma = 0
		has_dva = 0
		enable_dynamic_smem_size = 0
		workitem_private_segment_byte_size = 0
		workgroup_group_segment_byte_size = 0
		kernarg_segment_byte_size = 144
		workgroup_fbarrier_count = 0
		warp_sgpr_count = 99
		workitem_vgpr_count = 104
		reserved_vgpr_first = 0
		reserved_vgpr_count = 0
		reserved_sgpr_first = 0
		reserved_sgpr_count = 0
		debug_warp_private_segment_offset_sgpr = 0
		debug_private_segment_buffer_sgpr = 0
		kernarg_segment_alignment = 3
		group_segment_alignment = 4
		private_segment_alignment = 4
		warp_size = 6
		call_convention = -1
		runtime_loader_kernel_symbol = 0
	.end_iluvatar_kernel_code_t
; %bb.0:
	; Func LiveIn Regs:
	;  blockIdx.x : s6  blockIdx.y : s7  blockIdx.z : s8
	ml_vrf_init_u32 v61, tcr
	sl_mov_b32 s74, s6
.Ltmp0:
	.loc	1 7 28 prologue_end             ; generated-gqa-page-pipeline.py:7:28
	sl_lsa_load_b32x16 s[24:39], s[4:5], noreg, #0, ca
	.loc	1 10 37                         ; generated-gqa-page-pipeline.py:10:37
	sl_mov_b32 s1, 0x0
	sl_mov_b32 s75, s1
	sl_shl_b64 {s[2:3], wcr}, s[74:75], 0x2
	sl_mov_b32 s15, 0xffffffff
	sl_wait smcnt(0)
	sl_add_i64 s[12:13], s[36:37], s[2:3]
	.loc	1 10 22 is_stmt 0               ; generated-gqa-page-pipeline.py:10:22
	ml_lsa_load_dword v0, s[12:15], noreg, noreg, #0, ca
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s3, v0, 0x0
.Ltmp1:
	.file	2 "/usr/local/lib/python3.12/site-packages/triton/language" "standard.py"
	.loc	2 65 17 is_stmt 1               ; standard.py:65:17 @[ generated-gqa-page-pipeline.py:11:41 ]
	sl_add_i32 s0, s3, 0x3f
	.loc	2 65 30 is_stmt 0               ; standard.py:65:30 @[ generated-gqa-page-pipeline.py:11:41 ]
	sl_sra_b32 {s2, wcr}, s0, 0x1f
	sl_srl_b32 {s2, wcr}, s2, 0x1a
	sl_add_i32 s0, s0, s2
	sl_sra_b32 {s0, wcr}, s0, 0x6
.Ltmp2:
	.loc	1 12 26 is_stmt 1               ; generated-gqa-page-pipeline.py:12:26
	sl_mull_u32 s2, s0, s8
	.loc	1 12 46 is_stmt 0               ; generated-gqa-page-pipeline.py:12:46
	sl_mull_u32 s40, s2, 0x10
	.loc	1 13 16 is_stmt 1               ; generated-gqa-page-pipeline.py:13:16
	sl_cmp_lt_i32 wcr, s40, s3
	sl_cbr_wcrz BB0_75, wcr
; %bb.1:
	.loc	1 0 16 is_stmt 0                ; generated-gqa-page-pipeline.py:0:16
	sl_mov_b32 s50, s8
	sl_lsa_load_b32x16 s[76:91], s[4:5], noreg, #64, ca
	.loc	1 15 31 is_stmt 1               ; generated-gqa-page-pipeline.py:15:31
	sl_add_i32 s6, s2, s0
	.loc	1 16 28                         ; generated-gqa-page-pipeline.py:16:28
	ml_and_b32 v0, tid, 0x30
	ml_and_b32 v5, tid, 0x7
	.loc	1 23 28                         ; generated-gqa-page-pipeline.py:23:28
	sl_mull_u32 s0, s7, 0x800
	.loc	1 23 16 is_stmt 0               ; generated-gqa-page-pipeline.py:23:16
	sl_mov_b32 s19, 0xfff00004
	sl_mov_b32 s8, 0x400
	ml_and_b32 v9, tid, 0x8
	ml_mov_b32 v10, 0x180
	sl_mov_b32 s12, 0x2000
	.loc	1 15 31 is_stmt 1               ; generated-gqa-page-pipeline.py:15:31
	sl_mull_u32 s6, s6, 0x10
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_shl_b32 v11, v0, 0x5
	.loc	1 22 32                         ; generated-gqa-page-pipeline.py:22:32
	sl_wait smcnt(0)
	sl_mull_u32 s9, s81, s74
	sl_mul_u64_u32 s[4:5], s80, s74
	sl_add_i32 s5, s5, s9
	.loc	1 23 28                         ; generated-gqa-page-pipeline.py:23:28
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x1
	sl_add_i64 s[4:5], s[30:31], s[4:5]
	sl_add_i64 s[16:17], s[4:5], s[0:1]
	.loc	1 23 16 is_stmt 0               ; generated-gqa-page-pipeline.py:23:16
	ml_lsa_blkload_x4 v[1:4], s[16:19], noreg, noreg, #0, ca
	sl_mov_b32 s0, 0x3020706
	sl_mov_b32 s9, 0x1000504
	ml_shl_b32 v0, v5, 0x3
	ml_lsa_blkload_x4 v[5:8], s[16:19], noreg, s8, #0, ca
	ml_cmp_eq_u32 tcr, v9, 0x0
	ml_csel_b32 v9, 0, v10, tcr
	ml_anyop3_b32 v11, v9, v11, v0, 0xfffffffe
	.loc	1 15 62 is_stmt 1               ; generated-gqa-page-pipeline.py:15:62
	sl_min_i32 s6, s6, s3
	.loc	1 24 50                         ; generated-gqa-page-pipeline.py:24:50
	sl_mul_u64_u32 s[4:5], s78, s74
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	sl_wait vmcnt(1)
	ml_byte_permute_b32 v10, v2, v1, s0
	ml_byte_permute_b32 v9, v2, v1, s9
	ml_slb_store_b32x2  v[9:10], v11, s12, #0, null
	ml_byte_permute_b32 v2, v4, v3, s0
	ml_byte_permute_b32 v1, v4, v3, s9
	ml_xor_b32 v9, v11, 0x80
	ml_slb_store_b32x2  v[1:2], v11, s12, #64, null
	sl_wait vmcnt(0)
	ml_byte_permute_b32 v2, v6, v5, s0
	ml_byte_permute_b32 v1, v6, v5, s9
	ml_byte_permute_b32 v4, v8, v7, s0
	ml_slb_store_b32x2  v[1:2], v9, s12, #0, null
	ml_mov_b32 v2, 0x280
	ml_byte_permute_b32 v3, v8, v7, s9
	.loc	1 24 50                         ; generated-gqa-page-pipeline.py:24:50
	sl_mull_u32 s0, s79, s74
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_store_b32x2  v[3:4], v9, s12, #64, null
	.loc	1 24 50                         ; generated-gqa-page-pipeline.py:24:50
	sl_add_i32 s5, s5, s0
	.loc	1 24 40 is_stmt 0               ; generated-gqa-page-pipeline.py:24:40
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x2
	sl_add_i64 s[4:5], s[38:39], s[4:5]
	.loc	1 29 34 is_stmt 1               ; generated-gqa-page-pipeline.py:29:34
	ml_mov_s2v_b32 v103, s4, 0x0
	ml_mov_s2v_b32 v103, s5, 0x1
	sl_sub_i32 s0, s6, s40
	.loc	1 29 44 is_stmt 0               ; generated-gqa-page-pipeline.py:29:44
	sl_sra_b32 {s3, wcr}, s0, 0x1f
	sl_srl_b32 {s3, wcr}, s3, 0x1c
	sl_add_i32 s0, s0, s3
	sl_srl_b32 {s0, wcr}, s0, 0x4
	.loc	1 29 25                         ; generated-gqa-page-pipeline.py:29:25
	sl_add_i32 s0, s0, s2
	sl_mull_u32 s94, s0, 0x10
	.loc	1 23 16 is_stmt 1               ; generated-gqa-page-pipeline.py:23:16
	sl_wait lmcnt(0)
	sl_barrier 
	ml_slb_blkload_x1  v57, noreg, s12, #0, null
	sl_mov_b32 s0, 0x2400
	ml_shl_b32 v1, tid, 0x2
	ml_xor_b32 v62, v1, 0x80
	ml_slb_blkload_x1  v54, noreg, s12, #512, null
	.loc	1 30 59                         ; generated-gqa-page-pipeline.py:30:59
	sl_cmp_lt_i32 wcr, s40, s94
	sl_sub_bi_u32 s2, s10, s10, wcr
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_blkload_x1  v51, noreg, s0, #0, null
	ml_slb_blkload_x1  v48, noreg, s0, #512, null
	ml_slb_load_b32x1  v59, v62, s12, #256, null
	ml_slb_load_b32x1  v56, v62, s12, #768, null
	ml_slb_load_b32x1  v53, v62, s0, #256, null
	ml_slb_load_b32x1  v50, v62, s0, #768, null
	sl_cbr_wcrz BB0_3, wcr
; %bb.2:
	.loc	1 0 16 is_stmt 0                ; generated-gqa-page-pipeline.py:0:16
	sl_sra_b32 {s0, wcr}, s40, 0x4
	sl_sra_b32 {s1, wcr}, s0, 0x1f
	sl_mov_b32 s3, 0xffffffff
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	ml_mov_v2s_b32 s4, v103, 0x0
	ml_mov_v2s_b32 s5, v103, 0x1
	sl_add_i64 s[0:1], s[4:5], s[0:1]
	.loc	1 31 23 is_stmt 1               ; generated-gqa-page-pipeline.py:31:23
	ml_lsa_load_dword v3, s[0:3], noreg, noreg, #0, ca
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s1, v3, 0x0
BB0_3:
	.loc	1 0 23 is_stmt 0                ; generated-gqa-page-pipeline.py:0:23
	ml_mov_s2v_b32 v103, s6, 0x2
	ml_csel_b32 v2, 0, v2, tcr
	.loc	1 18 29 is_stmt 1               ; generated-gqa-page-pipeline.py:18:29
	ml_and_b32 v3, tid, 0xf
	.loc	1 22 93                         ; generated-gqa-page-pipeline.py:22:93
	sl_mov_b32 s12, 0x0
	.loc	1 32 67                         ; generated-gqa-page-pipeline.py:32:67
	sl_shl_b64 {s[44:45], wcr}, s[84:85], 0x1
	.loc	1 32 97 is_stmt 0               ; generated-gqa-page-pipeline.py:32:97
	sl_mull_u32 s0, s87, s7
	sl_mul_u64_u32 s[18:19], s86, s7
	sl_add_i32 s19, s19, s0
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_shl_b64 {s[54:55], wcr}, s[90:91], 0x1
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_shl_b32 v4, v61, 0x6
	ml_and_b32 v5, tid, 0xc
	ml_shl_b32 v6, v5, 0x2
	sl_mov_b32 s0, 0xcc0
	ml_anyop3_b32 v70, s0, v4, v6, 0xfffffff8
	ml_xor_b32 v34, v70, 0x10
	ml_xor_b32 v33, v70, 0x20
	ml_xor_b32 v32, v70, 0x30
	ml_shl_b32 v4, v5, 0x6
	ml_xor_b32 v35, tid, 0x8
	ml_xor_b32 v36, tid, 0x4
	ml_xor_b32 v37, tid, 0x2
	ml_xor_b32 v38, tid, 0x1
	ml_and_b32 v5, tid, 0x10
	ml_and_b32 v6, tid, 0x20
	.loc	1 16 28                         ; generated-gqa-page-pipeline.py:16:28
	ml_and_b32 v7, tid, 0x30
	ml_shl_b32 v7, v7, 0x6
	ml_add_i32 v60, v34, 0x100
	ml_add_i32 v69, v33, 0x200
	ml_add_i32 v58, v32, 0x300
	sl_mov_b32 s77, s7
	sl_mull_u32 s42, s7, 0x100
	ml_or_b32 v49, v1, v4
	ml_shl_b32 v1, v5, 0x1
	ml_srl_b32 v4, v6, 0x1
	ml_anyop3_b32 v55, v2, v7, v0, 0xfffffffe
	ml_xor_b32 v66, v49, 0x10
	ml_xor_b32 v65, v49, 0x20
	ml_xor_b32 v64, v49, 0x30
	ml_anyop3_b32 v63, v1, v4, v3, 0xfffffffe
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_or_b32 {s2, wcr}, s2, 0x0
	ml_xor_b32 v52, v55, 0x80
	ml_mov_s2v_b32 v103, s18, 0x3
	ml_mov_s2v_b32 v103, s19, 0x4
	sl_cbr_wcrz BB0_9, wcr
; %bb.4:                                ; %.lr.ph
	.loc	1 32 67                         ; generated-gqa-page-pipeline.py:32:67
	sl_mul_u64_u32 s[14:15], s84, 0x3
	sl_mull_u32 s0, s85, 0x3
	sl_add_i32 s15, s15, s0
	sl_shl_b64 {s[2:3], wcr}, s[84:85], 0x2
	ml_mov_s2v_b32 v103, s2, 0x5
	ml_mov_s2v_b32 v103, s3, 0x6
	sl_mul_u64_u32 s[8:9], s84, 0x5
	sl_mull_u32 s0, s85, 0x5
	sl_add_i32 s9, s9, s0
	sl_mul_u64_u32 s[6:7], s84, 0x6
	sl_mull_u32 s0, s85, 0x6
	sl_add_i32 s7, s7, s0
	sl_mul_u64_u32 s[4:5], s84, 0x7
	sl_mull_u32 s0, s85, 0x7
	sl_add_i32 s5, s5, s0
	sl_shl_b64 {s[22:23], wcr}, s[84:85], 0x3
	sl_mul_u64_u32 s[2:3], s84, 0x9
	sl_mull_u32 s0, s85, 0x9
	sl_add_i32 s3, s3, s0
	.loc	1 31 67                         ; generated-gqa-page-pipeline.py:31:67
	sl_sra_b32 {s0, wcr}, s1, 0x1f
	.loc	1 32 27                         ; generated-gqa-page-pipeline.py:32:27
	sl_mull_u32 s13, s82, s0
	sl_mul_u64_u32 s[16:17], s82, s1
	sl_add_i32 s13, s17, s13
	sl_mull_u32 s17, s83, s1
	sl_add_i32 s17, s13, s17
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[16:17], wcr}, s[16:17], 0x1
	sl_add_i64 s[16:17], s[32:33], s[16:17]
	sl_shl_b64 {s[18:19], wcr}, s[18:19], 0x1
	ml_mov_s2v_b32 v103, s18, 0x7
	ml_mov_s2v_b32 v103, s19, 0x8
	sl_add_i64 s[48:49], s[16:17], s[18:19]
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	sl_mov_b32 s51, 0xfff00004
	ml_lsa_blkload_x1 v0, s[48:51], noreg, noreg, #0, ca
	.loc	1 32 67 is_stmt 1               ; generated-gqa-page-pipeline.py:32:67
	sl_mul_u64_u32 s[62:63], s84, 0xa
	sl_mull_u32 s13, s85, 0xa
	sl_add_i32 s63, s63, s13
	sl_mul_u64_u32 s[60:61], s84, 0xb
	sl_mull_u32 s13, s85, 0xb
	sl_add_i32 s61, s61, s13
	sl_mul_u64_u32 s[58:59], s84, 0xc
	sl_mull_u32 s13, s85, 0xc
	sl_add_i32 s59, s59, s13
	sl_mul_u64_u32 s[20:21], s84, 0xd
	sl_mull_u32 s13, s85, 0xd
	sl_add_i32 s21, s21, s13
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[36:37], s[48:49], s[44:45]
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	sl_mov_b64 s[38:39], s[50:51]
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[16:17], wcr}, s[44:45], 0x1
	ml_mov_s2v_b32 v103, s16, 0x9
	ml_mov_s2v_b32 v103, s17, 0xa
	sl_shl_b64 {s[14:15], wcr}, s[14:15], 0x1
	ml_mov_s2v_b32 v103, s14, 0xb
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(0)
	ml_slb_store_b32x1  v0, v70, noreg, #0, null
	ml_mov_s2v_b32 v103, s15, 0xc
	.loc	1 32 67 is_stmt 1               ; generated-gqa-page-pipeline.py:32:67
	sl_mul_u64_u32 s[56:57], s84, 0xe
	sl_mull_u32 s13, s85, 0xe
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v0, s[36:39], noreg, noreg, #0, ca
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[36:37], s[48:49], s[16:17]
	.loc	1 32 67 is_stmt 1               ; generated-gqa-page-pipeline.py:32:67
	sl_add_i32 s57, s57, s13
	sl_mull_u32 s13, s85, 0xf
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v1, s[36:39], noreg, noreg, #0, ca
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[36:37], s[48:49], s[14:15]
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mul_u64_u32 s[14:15], s90, 0x3
	sl_shl_b64 {s[16:17], wcr}, s[90:91], 0x2
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v2, s[36:39], noreg, noreg, #0, ca
	.loc	1 32 67                         ; generated-gqa-page-pipeline.py:32:67
	sl_mul_u64_u32 s[36:37], s84, 0xf
	sl_add_i32 s37, s37, s13
	.loc	1 33 67                         ; generated-gqa-page-pipeline.py:33:67
	sl_mull_u32 s13, s91, 0x3
	sl_add_i32 s15, s15, s13
	ml_mov_s2v_b32 v103, s16, 0xd
	ml_mov_s2v_b32 v103, s17, 0xe
	ml_mov_s2v_b32 v103, s22, 0xf
	ml_mov_s2v_b32 v103, s23, 0x10
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[64:65], s[48:49], s[22:23]
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	sl_mov_b64 s[66:67], s[50:51]
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[8:9], wcr}, s[8:9], 0x1
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(2)
	ml_slb_store_b32x1  v0, v70, noreg, #4, null
	ml_mov_s2v_b32 v103, s8, 0x11
	ml_mov_s2v_b32 v103, s9, 0x12
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[6:7], wcr}, s[6:7], 0x1
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(1)
	ml_slb_store_b32x1  v1, v70, noreg, #8, null
	ml_mov_s2v_b32 v103, s6, 0x13
	ml_mov_s2v_b32 v103, s7, 0x14
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mul_u64_u32 s[16:17], s90, 0x5
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(0)
	ml_slb_store_b32x1  v2, v70, noreg, #12, null
	.loc	1 33 67                         ; generated-gqa-page-pipeline.py:33:67
	sl_mul_u64_u32 s[38:39], s90, 0x6
	sl_mul_u64_u32 s[22:23], s90, 0x7
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x1
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v0, s[64:67], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[64:65], s[48:49], s[8:9]
	ml_mov_s2v_b32 v103, s4, 0x15
	ml_mov_s2v_b32 v103, s5, 0x16
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v1, s[64:67], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[64:65], s[48:49], s[6:7]
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mull_u32 s6, s91, 0x5
	sl_add_i32 s17, s17, s6
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v2, s[64:67], noreg, noreg, #0, ca
	.loc	1 33 67                         ; generated-gqa-page-pipeline.py:33:67
	sl_mull_u32 s6, s91, 0x6
	sl_add_i32 s39, s39, s6
	sl_mull_u32 s6, s91, 0x7
	sl_add_i32 s23, s23, s6
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[4:5], s[48:49], s[4:5]
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	sl_mov_b64 s[6:7], s[50:51]
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[2:3], wcr}, s[2:3], 0x1
	ml_mov_s2v_b32 v103, s2, 0x17
	ml_mov_s2v_b32 v103, s3, 0x18
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_shl_b64 {s[80:81], wcr}, s[90:91], 0x3
	sl_mul_u64_u32 s[66:67], s90, 0xb
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(2)
	ml_slb_store_b32x1  v0, v34, noreg, #256, null
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[46:47], wcr}, s[62:63], 0x1
	sl_add_i64 s[68:69], s[48:49], s[46:47]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_mov_b64 s[70:71], s[50:51]
	sl_wait vmcnt(1)
	ml_slb_store_b32x1  v1, v34, noreg, #260, null
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[52:53], wcr}, s[60:61], 0x1
	sl_add_i64 s[60:61], s[48:49], s[52:53]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_mov_b64 s[62:63], s[50:51]
	sl_wait vmcnt(0)
	ml_slb_store_b32x1  v2, v34, noreg, #264, null
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[30:31], wcr}, s[58:59], 0x1
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mul_u64_u32 s[18:19], s90, 0xc
	sl_mull_u32 s8, s91, 0xd
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v0, s[4:7], noreg, noreg, #0, ca
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[4:5], wcr}, s[84:85], 0x4
	sl_add_i64 s[4:5], s[48:49], s[4:5]
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mull_u32 s13, s91, 0xe
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v1, s[4:7], noreg, noreg, #0, ca
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[4:5], s[48:49], s[2:3]
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mull_u32 s2, s91, 0x9
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[20:21], wcr}, s[20:21], 0x1
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v2, s[4:7], noreg, noreg, #0, ca
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mul_u64_u32 s[4:5], s90, 0x9
	sl_add_i32 s5, s5, s2
	sl_mul_u64_u32 s[2:3], s90, 0xa
	sl_mull_u32 s6, s91, 0xa
	sl_add_i32 s3, s3, s6
	sl_mull_u32 s6, s91, 0xb
	sl_add_i32 s67, s67, s6
	sl_mull_u32 s6, s91, 0xc
	sl_add_i32 s19, s19, s6
	sl_mul_u64_u32 s[6:7], s90, 0xd
	sl_add_i32 s7, s7, s8
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(2)
	ml_slb_store_b32x1  v0, v34, noreg, #268, null
	.loc	1 33 67                         ; generated-gqa-page-pipeline.py:33:67
	sl_mul_u64_u32 s[8:9], s90, 0xe
	ml_mov_s2v_b32 v103, s20, 0x19
	ml_mov_s2v_b32 v103, s21, 0x1a
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(1)
	ml_slb_store_b32x1  v1, v33, noreg, #512, null
	sl_mov_b64 s[58:59], s[50:51]
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[92:93], wcr}, s[36:37], 0x1
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_add_i32 s9, s9, s13
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(0)
	ml_slb_store_b32x1  v2, v33, noreg, #516, null
	.loc	1 33 67                         ; generated-gqa-page-pipeline.py:33:67
	sl_mull_u32 s13, s91, 0xf
	.loc	1 33 27 is_stmt 0               ; generated-gqa-page-pipeline.py:33:27
	sl_mull_u32 s0, s88, s0
	sl_mul_u64_u32 s[36:37], s88, s1
	.loc	1 34 20 is_stmt 1               ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v0, s[68:71], noreg, noreg, #0, ca
	.loc	1 33 27                         ; generated-gqa-page-pipeline.py:33:27
	sl_add_i32 s0, s37, s0
	sl_mull_u32 s1, s89, s1
	sl_add_i32 s37, s0, s1
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v1, s[60:63], noreg, noreg, #0, ca
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[60:61], s[48:49], s[30:31]
	.loc	1 35 38 is_stmt 1               ; generated-gqa-page-pipeline.py:35:38
	sl_shl_b64 {s[0:1], wcr}, s[36:37], 0x1
	sl_add_i64 s[0:1], s[34:35], s[0:1]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v2, s[60:63], noreg, noreg, #0, ca
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[60:61], s[48:49], s[20:21]
	sl_shl_b64 {s[20:21], wcr}, s[56:57], 0x1
	ml_mov_s2v_b32 v103, s20, 0x1b
	ml_mov_s2v_b32 v103, s21, 0x1c
	sl_add_i64 s[56:57], s[48:49], s[20:21]
	.loc	1 33 67 is_stmt 1               ; generated-gqa-page-pipeline.py:33:67
	sl_mul_u64_u32 s[20:21], s90, 0xf
	sl_add_i32 s21, s21, s13
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_mov_b32 s43, s12
	sl_mov_b64 s[78:79], s[54:55]
	sl_shl_b64 {s[64:65], wcr}, s[22:23], 0x1
	sl_shl_b64 {s[66:67], wcr}, s[66:67], 0x1
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(2)
	ml_slb_store_b32x1  v0, v33, noreg, #520, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_mov_b64 s[86:87], s[50:51]
	sl_mov_b64 s[22:23], s[50:51]
	ml_mov_b32 v39, 0x0
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(1)
	ml_slb_store_b32x1  v1, v33, noreg, #524, null
	ml_xor_b32 v40, v63, 0x10
	ml_mov_b32 v71, 0xff800000
	sl_mov_b32 s41, 0x1400
	sl_wait vmcnt(0)
	ml_slb_store_b32x1  v2, v32, noreg, #768, null
	ml_mov_b32 v6, 0x0
	ml_mov_b32 v7, 0x0
	ml_mov_b32 v8, 0x0
	ml_lsa_blkload_x1 v0, s[60:63], noreg, noreg, #0, ca
	ml_mov_b32 v9, 0x0
	ml_mov_b32 v10, 0x0
	ml_mov_b32 v11, 0x0
	ml_lsa_blkload_x1 v1, s[56:59], noreg, noreg, #0, ca
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[56:57], s[48:49], s[92:93]
	.loc	1 35 38 is_stmt 1               ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[48:49], s[0:1], s[42:43]
	sl_shl_b64 {s[0:1], wcr}, s[8:9], 0x1
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v2, s[56:59], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_shl_b64 {s[58:59], wcr}, s[20:21], 0x1
	sl_add_i64 s[36:37], s[48:49], s[58:59]
	sl_add_i64 s[20:21], s[48:49], s[0:1]
	sl_shl_b64 {s[8:9], wcr}, s[6:7], 0x1
	sl_add_i64 s[72:73], s[48:49], s[8:9]
	sl_add_i64 s[60:61], s[48:49], s[54:55]
	sl_shl_b64 {s[6:7], wcr}, s[14:15], 0x1
	sl_shl_b64 {s[56:57], wcr}, s[18:19], 0x1
	.loc	1 35 20 is_stmt 0               ; generated-gqa-page-pipeline.py:35:20
	sl_mov_b64 s[18:19], s[50:51]
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_shl_b64 {s[14:15], wcr}, s[90:91], 0x4
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v83, s[48:51], noreg, noreg, #0, ca
	ml_mov_b32 v12, 0x0
	ml_mov_b32 v13, 0x0
	ml_mov_b32 v14, 0x0
	.loc	1 34 20 is_stmt 1               ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(3)
	ml_slb_store_b32x1  v0, v32, noreg, #772, null
	ml_mov_b32 v15, 0x0
	ml_mov_b32 v16, 0x0
	ml_mov_b32 v17, 0x0
	sl_wait vmcnt(2)
	ml_slb_store_b32x1  v1, v32, noreg, #776, null
	ml_mov_b32 v18, 0x0
	ml_mov_b32 v19, 0x0
	ml_mov_b32 v20, 0x0
	sl_wait vmcnt(1)
	ml_slb_store_b32x1  v2, v32, noreg, #780, null
	ml_mov_b32 v21, 0x0
	ml_mov_b32 v22, 0x0
	ml_mov_b32 v23, 0x0
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v0, s[60:63], noreg, noreg, #0, ca
	.loc	1 35 38 is_stmt 0               ; generated-gqa-page-pipeline.py:35:38
	sl_shl_b64 {s[60:61], wcr}, s[54:55], 0x1
	sl_add_i64 s[68:69], s[48:49], s[60:61]
	sl_shl_b64 {s[62:63], wcr}, s[16:17], 0x1
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v41, s[68:71], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[68:69], s[48:49], s[6:7]
	sl_shl_b64 {s[54:55], wcr}, s[4:5], 0x1
	ml_mov_b32 v24, 0x0
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v1, s[68:71], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[68:69], s[48:49], s[80:81]
	ml_mov_b32 v25, 0x0
	ml_mov_b32 v26, 0x0
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v42, s[68:71], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[68:69], s[48:49], s[62:63]
	ml_mov_b32 v27, 0x0
	ml_mov_b32 v28, 0x0
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v2, s[68:71], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_shl_b64 {s[70:71], wcr}, s[38:39], 0x1
	sl_add_i64 s[16:17], s[48:49], s[70:71]
	sl_shl_b64 {s[68:69], wcr}, s[2:3], 0x1
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v43, s[16:19], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[16:17], s[48:49], s[64:65]
	sl_add_i64 s[84:85], s[48:49], s[68:69]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(5)
	ml_and_b32 v76, v0, 0xffff
	ml_lsa_blkload_x1 v3, s[16:19], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[16:17], s[48:49], s[14:15]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_bfe2_b32 v80, v0, 0x210
	sl_mov_b64 s[2:3], s[74:75]
	ml_lsa_blkload_x1 v44, s[16:19], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[16:17], s[48:49], s[54:55]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(5)
	ml_and_b32 v78, v1, 0xffff
	ml_bfe2_b32 v81, v1, 0x210
	ml_lsa_blkload_x1 v4, s[16:19], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[16:17], s[48:49], s[66:67]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_mov_b64 s[74:75], s[50:51]
	sl_mov_b64 s[38:39], s[50:51]
	ml_lsa_blkload_x1 v5, s[16:19], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[16:17], s[48:49], s[56:57]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(5)
	ml_and_b32 v47, v2, 0xffff
	ml_bfe2_b32 v73, v2, 0x210
	ml_lsa_blkload_x1 v0, s[72:75], noreg, noreg, #0, ca
	sl_mov_b64 s[74:75], s[2:3]
	sl_mov_b32 s72, 0x1800
	sl_mov_b32 s73, 0x1c00
	sl_wait vmcnt(4)
	ml_and_b32 v75, v3, 0xffff
	ml_bfe2_b32 v77, v3, 0x210
	ml_lsa_blkload_x1 v1, s[36:39], noreg, noreg, #0, ca
	sl_mov_b32 s36, 0x1000706
	sl_mov_b32 s37, 0x1000504
	sl_mov_b32 s38, 0x2000
	ml_lsa_blkload_x1 v74, s[84:87], noreg, noreg, #0, ca
	sl_mov_b32 s39, 0x2400
	sl_wait vmcnt(4)
	ml_and_b32 v84, v4, 0xffff
	ml_bfe2_b32 v86, v4, 0x210
	ml_lsa_blkload_x1 v45, s[16:19], noreg, noreg, #0, ca
	sl_mov_b32 s16, 0x400
	sl_wait vmcnt(4)
	ml_and_b32 v85, v5, 0xffff
	ml_bfe2_b32 v88, v5, 0x210
	ml_lsa_blkload_x1 v46, s[20:23], noreg, noreg, #0, ca
	sl_add_i32 s22, s94, 0xfffffff0
	sl_wait vmcnt(4)
	ml_and_b32 v79, v0, 0xffff
	ml_bfe2_b32 v82, v0, 0x210
	ml_and_b32 v0, tid, 0x10
	ml_cmp_eq_u32 tcr, v0, 0x0
	ml_and_b32 v0, tid, 0x20
	sl_mov_b32 s23, 0xffffffff
	sl_wait vmcnt(3)
	ml_bfe2_b32 v91, v1, 0x210
	ml_and_b32 v90, v1, 0xffff
	sl_mov_b64 s[2:3], tcr
	ml_cmp_eq_u32 tcr, v0, 0x0
	sl_mov_b32 s17, 0x800
	sl_mov_b32 s18, 0xc00
	sl_mov_b32 s19, 0x1000
	sl_mov_b64 s[4:5], tcr
	ml_mov_b32 v0, 0x0
	ml_mov_b32 v1, 0x0
	ml_mov_b32 v2, 0x0
	ml_mov_b32 v3, 0x0
	ml_mov_b32 v4, 0x0
	ml_mov_b32 v5, 0x0
	ml_mov_b32 v29, 0x0
	ml_mov_b32 v30, 0x0
	ml_mov_b32 v31, 0x0
	ml_mov_b32 v67, 0x0
	ml_mov_b32 v68, 0x0
	ml_mov_b32 v72, 0xff800000
	ml_mov_v2s_b32 s90, v103, 0x0
	ml_mov_v2s_b32 s91, v103, 0x1
	sl_jump BB0_7
BB0_5:                                  ;   in Loop: Header=BB0_7 Depth=1
	.loc	1 31 53 is_stmt 1               ; generated-gqa-page-pipeline.py:31:53
	sl_sra_b32 {s14, wcr}, s40, 0x4
	.loc	1 31 41 is_stmt 0               ; generated-gqa-page-pipeline.py:31:41
	sl_sra_b32 {s15, wcr}, s14, 0x1f
	sl_shl_b64 {s[14:15], wcr}, s[14:15], 0x2
	sl_add_i64 s[20:21], s[90:91], s[14:15]
	.loc	1 31 23                         ; generated-gqa-page-pipeline.py:31:23
	ml_lsa_load_dword v41, s[20:23], noreg, noreg, #0, ca
	.loc	1 34 20 is_stmt 1               ; generated-gqa-page-pipeline.py:34:20
	sl_mov_b64 s[86:87], s[50:51]
	.loc	1 34 36 is_stmt 0               ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s48, v103, 0x7
	ml_mov_v2s_b32 s49, v103, 0x8
	.loc	1 31 23 is_stmt 1               ; generated-gqa-page-pipeline.py:31:23
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s13, v41, 0x0
	sl_sra_b32 {s20, wcr}, s13, 0x1f
	.loc	1 32 27                         ; generated-gqa-page-pipeline.py:32:27
	sl_mul_u64_u32 s[14:15], s82, s13
	sl_mull_u32 s21, s83, s13
	sl_mull_u32 s43, s82, s20
	sl_add_i32 s15, s15, s43
	sl_add_i32 s15, s15, s21
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[14:15], wcr}, s[14:15], 0x1
	sl_add_i64 s[14:15], s[32:33], s[14:15]
	sl_add_i64 s[48:49], s[14:15], s[48:49]
	sl_add_i64 s[84:85], s[48:49], s[44:45]
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v47, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s14, v103, 0x9
	ml_mov_v2s_b32 s15, v103, 0xa
	.loc	1 33 27 is_stmt 1               ; generated-gqa-page-pipeline.py:33:27
	sl_mull_u32 s20, s88, s20
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v86, s[48:51], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_mov_b32 s43, s12
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	ml_mov_v2s_b32 s14, v103, 0xb
	.loc	1 34 20 is_stmt 0               ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v73, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s15, v103, 0xc
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v75, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s14, v103, 0x5
	ml_mov_v2s_b32 s15, v103, 0x6
	sl_shl_b64 {s[14:15], wcr}, s[14:15], 0x1
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v76, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s14, v103, 0x11
	ml_mov_v2s_b32 s15, v103, 0x12
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(3)
	ml_slb_store_b32x1  v86, v70, noreg, #0, null
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	ml_mov_v2s_b32 s14, v103, 0x13
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v77, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s15, v103, 0x14
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v47, v70, noreg, #4, null
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	ml_mov_v2s_b32 s14, v103, 0x15
	ml_mov_v2s_b32 s15, v103, 0x16
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v78, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v79, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s14, v103, 0xf
	ml_mov_v2s_b32 s15, v103, 0x10
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(5)
	ml_slb_store_b32x1  v73, v70, noreg, #8, null
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_shl_b64 {s[14:15], wcr}, s[14:15], 0x1
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v80, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	ml_mov_v2s_b32 s14, v103, 0x17
	ml_mov_v2s_b32 s15, v103, 0x18
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(5)
	ml_slb_store_b32x1  v75, v70, noreg, #12, null
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	ml_mov_v2s_b32 s14, v103, 0x19
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v81, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[46:47]
	ml_mov_v2s_b32 s15, v103, 0x1a
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v82, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[52:53]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v83, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[30:31]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v84, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	ml_mov_v2s_b32 s14, v103, 0x1b
	ml_mov_v2s_b32 s15, v103, 0x1c
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v85, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v88, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 36                         ; generated-gqa-page-pipeline.py:34:36
	sl_add_i64 s[84:85], s[48:49], s[92:93]
	.loc	1 33 27 is_stmt 1               ; generated-gqa-page-pipeline.py:33:27
	sl_mul_u64_u32 s[14:15], s88, s13
	sl_add_i32 s15, s15, s20
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_lsa_blkload_x1 v93, s[84:87], noreg, noreg, #0, ca
	.loc	1 33 27                         ; generated-gqa-page-pipeline.py:33:27
	sl_mull_u32 s13, s89, s13
	sl_add_i32 s15, s15, s13
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_shl_b64 {s[14:15], wcr}, s[14:15], 0x1
	sl_add_i64 s[14:15], s[34:35], s[14:15]
	sl_add_i64 s[48:49], s[14:15], s[42:43]
	sl_add_i64 s[84:85], s[48:49], s[78:79]
	.loc	1 35 20 is_stmt 0               ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v94, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[60:61]
	ml_mov_v2s_b32 s14, v103, 0xd
	ml_mov_v2s_b32 s15, v103, 0xe
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v41, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[6:7]
	sl_shl_b64 {s[14:15], wcr}, s[14:15], 0x1
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v95, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	sl_shl_b64 {s[14:15], wcr}, s[80:81], 0x1
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v42, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[62:63]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v96, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[70:71]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v43, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[64:65]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v97, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[14:15]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v44, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[54:55]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v98, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[68:69]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v74, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[66:67]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(5)
	ml_and_b32 v47, v96, 0xffff
	ml_bfe2_b32 v73, v96, 0x210
	ml_lsa_blkload_x1 v99, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[56:57]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v45, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[8:9]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(5)
	ml_and_b32 v75, v97, 0xffff
	ml_lsa_blkload_x1 v100, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[0:1]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_lsa_blkload_x1 v46, s[84:87], noreg, noreg, #0, ca
	.loc	1 35 38                         ; generated-gqa-page-pipeline.py:35:38
	sl_add_i64 s[84:85], s[48:49], s[58:59]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(5)
	ml_bfe2_b32 v86, v98, 0x210
	ml_lsa_blkload_x1 v92, s[84:87], noreg, noreg, #0, ca
	.loc	1 34 20 is_stmt 1               ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v76, v34, noreg, #256, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_and_b32 v76, v94, 0xffff
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v77, v34, noreg, #260, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_bfe2_b32 v77, v97, 0x210
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v78, v34, noreg, #264, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_and_b32 v78, v95, 0xffff
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v79, v34, noreg, #268, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(2)
	ml_and_b32 v79, v100, 0xffff
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v80, v33, noreg, #512, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_bfe2_b32 v80, v94, 0x210
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v81, v33, noreg, #516, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_bfe2_b32 v81, v95, 0x210
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v82, v33, noreg, #520, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_bfe2_b32 v82, v100, 0x210
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v83, v33, noreg, #524, null
	ml_slb_store_b32x1  v84, v32, noreg, #768, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_and_b32 v84, v98, 0xffff
	ml_lsa_blkload_x1 v83, s[48:51], noreg, noreg, #0, ca
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v85, v32, noreg, #772, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_and_b32 v85, v99, 0xffff
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v88, v32, noreg, #776, null
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_bfe2_b32 v88, v99, 0x210
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x1  v93, v32, noreg, #780, null
BB0_6:                                  ;   in Loop: Header=BB0_7 Depth=1
	.loc	1 40 46                         ; generated-gqa-page-pipeline.py:40:46
	ml_fma_f32 v67, v67, v87, v90
	ml_fma_f32 v68, v68, v89, v91
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_wait vmcnt(1)
	ml_and_b32 v90, v92, 0xffff
	.loc	1 30 59                         ; generated-gqa-page-pipeline.py:30:59
	sl_cmp_lt_i32 wcr, s40, s94
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_bfe2_b32 v91, v92, 0x210
	.loc	1 30 59                         ; generated-gqa-page-pipeline.py:30:59
	sl_cbr_wcrz BB0_10, wcr
BB0_7:                                  ; =>This Inner Loop Header: Depth=1
	.loc	1 0 59 is_stmt 0                ; generated-gqa-page-pipeline.py:0:59
	ml_mov_b32 v89, v72
	.loc	1 30 59 is_stmt 1               ; generated-gqa-page-pipeline.py:30:59
	sl_cmp_lt_i32 wcr, s40, s22
	ml_mov_b32 v87, v71
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	sl_wait vmcnt(0) lmcnt(0) g2scnt(0)
	sl_barrier 
	.loc	1 41 77                         ; generated-gqa-page-pipeline.py:41:77
	sl_mov_b64 tcr, s[2:3]
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_blkload_x1  v71, noreg, s38, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	ml_mov_b32 v92, 0x0
	ml_mov_b32 v93, v39
	ml_mov_b32 v94, v39
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_load_b32x1  v96, v62, s38, #256, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	ml_mov_b32 v95, v39
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v97, v49, noreg, #0, null
	ml_slb_load_b32x1  v98, v66, noreg, #0, null
	ml_slb_load_b32x1  v99, v65, noreg, #0, null
	ml_slb_load_b32x1  v100, v64, noreg, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(5)
	ml_mov_b32 v72, v71
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v101, v49, s16, #0, null
	ml_slb_load_b32x1  v102, v66, s16, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(4)
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[71:72], v[97:98], v[92:95]
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_blkload_x1  v71, noreg, s38, #512, null
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v98, v65, s16, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	ml_mov_b32 v97, v96
	sl_wait lmcnt(4)
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[96:97], v[99:100], v[92:95]
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_load_b32x1  v96, v62, s38, #768, null
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v99, v64, s16, #0, null
	ml_slb_load_b32x1  v100, v49, s17, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(4)
	ml_mov_b32 v72, v71
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[71:72], v[101:102], v[92:95]
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_blkload_x1  v71, noreg, s39, #0, null
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v101, v66, s17, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(4)
	ml_mov_b32 v97, v96
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[96:97], v[98:99], v[92:95]
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_load_b32x1  v96, v62, s39, #256, null
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v98, v65, s17, #0, null
	ml_slb_load_b32x1  v99, v64, s17, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(4)
	ml_mov_b32 v72, v71
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[71:72], v[100:101], v[92:95]
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_blkload_x1  v71, noreg, s39, #512, null
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v100, v49, s18, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(4)
	ml_mov_b32 v97, v96
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v101, v66, s18, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[96:97], v[98:99], v[92:95]
	.loc	1 23 16                         ; generated-gqa-page-pipeline.py:23:16
	ml_slb_load_b32x1  v96, v62, s39, #768, null
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v98, v65, s18, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(4)
	ml_mov_b32 v72, v71
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_load_b32x1  v99, v64, s18, #0, null
	.loc	1 36 27                         ; generated-gqa-page-pipeline.py:36:27
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[71:72], v[100:101], v[92:95]
	sl_wait lmcnt(2)
	ml_mov_b32 v97, v96
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[92:95], v[96:97], v[98:99], v[92:95]
	.loc	1 36 32 is_stmt 0               ; generated-gqa-page-pipeline.py:36:32
	ml_mul_f32 v92, s76, v92
.Ltmp3:
	.loc	2 213 40 is_stmt 1              ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v71, v92, v35
.Ltmp4:
	.loc	1 36 32                         ; generated-gqa-page-pipeline.py:36:32
	ml_mul_f32 v93, s76, v93
.Ltmp5:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v72, v93, v35
.Ltmp6:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v94, v92, v71
.Ltmp7:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v95, v94, v36
.Ltmp8:
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_byte_permute_b32 v71, v76, v83, s37
.Ltmp9:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v96, v93, v72
.Ltmp10:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v97, v96, v36
.Ltmp11:
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_byte_permute_b32 v72, v80, v83, s36
	ml_slb_store_b32x2  v[71:72], v55, s19, #0, null
	ml_byte_permute_b32 v72, v81, v41, s36
	ml_byte_permute_b32 v71, v78, v41, s37
	ml_slb_store_b32x2  v[71:72], v55, s19, #64, null
	ml_byte_permute_b32 v72, v86, v44, s36
	ml_byte_permute_b32 v71, v84, v44, s37
	ml_slb_store_b32x2  v[71:72], v55, s19, #256, null
	ml_byte_permute_b32 v72, v88, v74, s36
	ml_byte_permute_b32 v71, v85, v74, s37
.Ltmp12:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(4)
	ml_max_f32 v41, v94, v95
.Ltmp13:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v76, v41, v37
.Ltmp14:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(4)
	ml_max_f32 v78, v96, v97
.Ltmp15:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v80, v78, v37
.Ltmp16:
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_store_b32x2  v[71:72], v55, s19, #320, null
	ml_byte_permute_b32 v72, v73, v42, s36
	ml_byte_permute_b32 v71, v47, v42, s37
	ml_byte_permute_b32 v42, v77, v43, s36
	ml_slb_store_b32x2  v[71:72], v52, s19, #0, null
.Ltmp17:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v44, v41, v76
.Ltmp18:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v74, v44, v38
.Ltmp19:
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_byte_permute_b32 v41, v75, v43, s37
.Ltmp20:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(3)
	ml_max_f32 v76, v78, v80
.Ltmp21:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ]
	ml_slb_shuffle_rtn_b32 v78, v76, v38
.Ltmp22:
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_store_b32x2  v[41:42], v52, s19, #64, null
.Ltmp23:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(2)
	ml_max_f32 v41, v44, v74
.Ltmp24:
	.loc	1 37 42                         ; generated-gqa-page-pipeline.py:37:42
	ml_max_f32 v71, v87, v41
	.loc	1 38 44                         ; generated-gqa-page-pipeline.py:38:44
	ml_sub_f32 v41, v92, v71
.Ltmp25:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:37:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v42, v76, v78
.Ltmp26:
	.loc	1 38 35                         ; generated-gqa-page-pipeline.py:38:35
	ml_exp_f32 v43, v41
	.loc	1 37 42                         ; generated-gqa-page-pipeline.py:37:42
	ml_max_f32 v72, v89, v42
	.loc	1 38 44                         ; generated-gqa-page-pipeline.py:38:44
	ml_sub_f32 v41, v93, v72
	.loc	1 38 35 is_stmt 0               ; generated-gqa-page-pipeline.py:38:35
	ml_exp_f32 v44, v41
	.loc	1 39 45 is_stmt 1               ; generated-gqa-page-pipeline.py:39:45
	ml_sub_f32 v41, v87, v71
.Ltmp27:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v47, v43, v35
.Ltmp28:
	.loc	1 41 77                         ; generated-gqa-page-pipeline.py:41:77
	ml_cvt_bf16_f32  v42, v43
	.loc	1 39 31                         ; generated-gqa-page-pipeline.py:39:31
	ml_exp_f32 v87, v41
.Ltmp29:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v73, v44, v35
.Ltmp30:
	.loc	1 41 77                         ; generated-gqa-page-pipeline.py:41:77
	ml_cvt_bf16_f32  v74, v44
	ml_csel_b32 v75, v42, v74, tcr
	ml_cvt_i32_i16  v75, v75
	ml_slb_shuffle_rtn_b32 v75, v75, v63
	ml_csel_b32 v41, v74, v42, tcr
	ml_cvt_i32_i16  v41, v41
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_byte_permute_b32 v42, v82, v45, s36
	.loc	1 41 77                         ; generated-gqa-page-pipeline.py:41:77
	ml_slb_shuffle_rtn_b32 v74, v41, v40
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_byte_permute_b32 v41, v79, v45, s37
	.loc	1 39 45                         ; generated-gqa-page-pipeline.py:39:45
	ml_sub_f32 v45, v89, v72
	.loc	1 41 36                         ; generated-gqa-page-pipeline.py:41:36
	ml_mul_f32 v0, v0, v87
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_store_b32x2  v[41:42], v52, s19, #256, null
	.loc	1 39 31                         ; generated-gqa-page-pipeline.py:39:31
	ml_exp_f32 v89, v45
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_byte_permute_b32 v42, v91, v46, s36
	ml_byte_permute_b32 v41, v90, v46, s37
	ml_slb_store_b32x2  v[41:42], v52, s19, #320, null
.Ltmp31:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ] ]
	sl_wait lmcnt(5)
	ml_add_f32 v41, v43, v47
.Ltmp32:
	.loc	1 41 77                         ; generated-gqa-page-pipeline.py:41:77
	sl_mov_b64 tcr, s[4:5]
	.loc	1 41 36 is_stmt 0               ; generated-gqa-page-pipeline.py:41:36
	ml_mul_f32 v1, v1, v89
.Ltmp33:
	.loc	2 285 15 is_stmt 1              ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ] ]
	sl_wait lmcnt(4)
	ml_add_f32 v42, v44, v73
.Ltmp34:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v45, v41, v36
.Ltmp35:
	.loc	1 41 36                         ; generated-gqa-page-pipeline.py:41:36
	ml_mul_f32 v2, v2, v87
	ml_mul_f32 v3, v3, v89
	.loc	1 41 77 is_stmt 0               ; generated-gqa-page-pipeline.py:41:77
	sl_wait lmcnt(4)
	ml_and_b32 v43, v75, 0xffff
	.loc	1 41 36                         ; generated-gqa-page-pipeline.py:41:36
	ml_mul_f32 v4, v4, v87
	ml_mul_f32 v5, v5, v89
	ml_mul_f32 v6, v6, v87
	.loc	1 41 77                         ; generated-gqa-page-pipeline.py:41:77
	sl_wait lmcnt(3)
	ml_and_b32 v44, v74, 0xffff
	ml_csel_b32 v46, v43, v44, tcr
	ml_csel_b32 v47, v44, v43, tcr
.Ltmp36:
	.loc	2 315 36 is_stmt 1              ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v43, v42, v36
.Ltmp37:
	.loc	1 41 36                         ; generated-gqa-page-pipeline.py:41:36
	ml_mul_f32 v7, v7, v89
	ml_mul_f32 v8, v8, v87
	ml_mul_f32 v9, v9, v89
	ml_mul_f32 v10, v10, v87
	ml_mul_f32 v11, v11, v89
	ml_mul_f32 v12, v12, v87
	ml_mul_f32 v13, v13, v89
	ml_mul_f32 v14, v14, v87
	ml_mul_f32 v15, v15, v89
.Ltmp38:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v41, v41, v45
.Ltmp39:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v44, v41, v37
.Ltmp40:
	.loc	1 41 36                         ; generated-gqa-page-pipeline.py:41:36
	ml_mul_f32 v16, v16, v87
	ml_mul_f32 v17, v17, v89
	ml_mul_f32 v18, v18, v87
	ml_mul_f32 v19, v19, v89
	ml_mul_f32 v20, v20, v87
	ml_mul_f32 v21, v21, v89
	ml_mul_f32 v22, v22, v87
	ml_mul_f32 v23, v23, v89
.Ltmp41:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v42, v42, v43
.Ltmp42:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v43, v42, v37
.Ltmp43:
	.loc	1 41 36                         ; generated-gqa-page-pipeline.py:41:36
	ml_mul_f32 v24, v24, v87
	ml_mul_f32 v25, v25, v89
	ml_mul_f32 v26, v26, v87
	ml_mul_f32 v27, v27, v89
	ml_mul_f32 v28, v28, v87
	ml_mul_f32 v29, v29, v89
	ml_mul_f32 v30, v30, v87
	ml_mul_f32 v31, v31, v89
.Ltmp44:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v41, v41, v44
.Ltmp45:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v44, v41, v38
.Ltmp46:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v90, v41, v44
	ml_add_f32 v41, v42, v43
.Ltmp47:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ]
	ml_slb_shuffle_rtn_b32 v42, v41, v38
.Ltmp48:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:40:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v91, v41, v42
.Ltmp49:
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_barrier 
	ml_slb_blkload_x1  v41, noreg, s19, #0, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	ml_byte_permute_b32 v45, v47, v46, s37
	ml_mov_b32 v46, v45
	.loc	1 30 59                         ; generated-gqa-page-pipeline.py:30:59
	sl_add_i32 s40, s40, 0x10
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_blkload_x1  v42, noreg, s19, #256, null
	ml_slb_load_b32x1  v43, v62, s19, #512, null
	ml_slb_load_b32x1  v44, v62, s19, #768, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[0:3], v[45:46], v[41:42], v[0:3]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_blkload_x1  v41, noreg, s41, #0, null
	ml_slb_blkload_x1  v42, noreg, s41, #256, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[4:7], v[45:46], v[43:44], v[4:7]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_load_b32x1  v43, v62, s41, #512, null
	ml_slb_load_b32x1  v44, v62, s41, #768, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[8:11], v[45:46], v[41:42], v[8:11]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_blkload_x1  v41, noreg, s72, #0, null
	ml_slb_blkload_x1  v42, noreg, s72, #256, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[12:15], v[45:46], v[43:44], v[12:15]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_load_b32x1  v43, v62, s72, #512, null
	ml_slb_load_b32x1  v44, v62, s72, #768, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[16:19], v[45:46], v[41:42], v[16:19]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_blkload_x1  v41, noreg, s73, #0, null
	ml_slb_blkload_x1  v42, noreg, s73, #256, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[20:23], v[45:46], v[43:44], v[20:23]
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_slb_load_b32x1  v43, v62, s73, #512, null
	ml_slb_load_b32x1  v44, v62, s73, #768, null
	.loc	1 41 87                         ; generated-gqa-page-pipeline.py:41:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[24:27], v[45:46], v[41:42], v[24:27]
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[28:31], v[45:46], v[43:44], v[28:31]
	.loc	1 31 23                         ; generated-gqa-page-pipeline.py:31:23
	sl_cbr_wcrnz BB0_5, wcr
; %bb.8:                                ;   in Loop: Header=BB0_7 Depth=1
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_mov_b32 v41, 0x0
	ml_mov_b32 v42, 0x0
	ml_mov_b32 v43, 0x0
	ml_mov_b32 v44, 0x0
	ml_slb_store_b32x4  v[41:44], v70, noreg, #0, null
	ml_mov_b32 v76, 0x0
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	ml_mov_b32 v92, 0x0
	ml_mov_b32 v80, 0x0
	.loc	1 34 20                         ; generated-gqa-page-pipeline.py:34:20
	ml_slb_store_b32x4  v[41:44], v34, noreg, #256, null
	ml_mov_b32 v78, 0x0
	ml_mov_b32 v81, 0x0
	ml_mov_b32 v47, 0x0
	ml_slb_store_b32x4  v[41:44], v33, noreg, #512, null
	ml_mov_b32 v73, 0x0
	ml_mov_b32 v75, 0x0
	ml_mov_b32 v77, 0x0
	ml_slb_store_b32x4  v[41:44], v32, noreg, #768, null
	ml_mov_b32 v84, 0x0
	ml_mov_b32 v86, 0x0
	ml_mov_b32 v85, 0x0
	ml_mov_b32 v88, 0x0
	ml_mov_b32 v79, 0x0
	ml_mov_b32 v82, 0x0
	ml_mov_b32 v83, 0x0
	ml_mov_b32 v41, 0x0
	ml_mov_b32 v42, 0x0
	ml_mov_b32 v43, 0x0
	ml_mov_b32 v44, 0x0
	ml_mov_b32 v74, 0x0
	ml_mov_b32 v45, 0x0
	ml_mov_b32 v46, 0x0
	.loc	1 35 20                         ; generated-gqa-page-pipeline.py:35:20
	sl_jump BB0_6
BB0_9:
	.loc	1 0 20 is_stmt 0                ; generated-gqa-page-pipeline.py:0:20
	sl_mov_b64 s[78:79], s[54:55]
	.loc	1 34 20 is_stmt 1               ; generated-gqa-page-pipeline.py:34:20
	ml_mov_b32 v3, 0x0
	ml_mov_b32 v4, 0x0
	ml_mov_b32 v5, 0x0
	ml_mov_b32 v6, 0x0
	ml_slb_store_b32x4  v[3:6], v70, noreg, #0, null
	ml_mov_b32 v71, 0xff800000
	ml_mov_b32 v67, 0x0
	ml_mov_b32 v72, 0xff800000
	ml_slb_store_b32x4  v[3:6], v34, noreg, #256, null
	ml_mov_b32 v68, 0x0
	ml_mov_b32 v0, 0x0
	ml_mov_b32 v1, 0x0
	ml_slb_store_b32x4  v[3:6], v33, noreg, #512, null
	ml_mov_b32 v2, 0x0
	ml_mov_b32 v7, 0x0
	ml_mov_b32 v8, 0x0
	ml_slb_store_b32x4  v[3:6], v32, noreg, #768, null
	ml_mov_b32 v9, 0x0
	ml_mov_b32 v3, 0x0
	ml_mov_b32 v4, 0x0
	ml_mov_b32 v5, 0x0
	ml_mov_b32 v6, 0x0
	ml_mov_b32 v10, 0x0
	ml_mov_b32 v11, 0x0
	ml_mov_b32 v12, 0x0
	ml_mov_b32 v13, 0x0
	ml_mov_b32 v14, 0x0
	ml_mov_b32 v15, 0x0
	ml_mov_b32 v16, 0x0
	ml_mov_b32 v17, 0x0
	ml_mov_b32 v18, 0x0
	ml_mov_b32 v19, 0x0
	ml_mov_b32 v20, 0x0
	ml_mov_b32 v21, 0x0
	ml_mov_b32 v22, 0x0
	ml_mov_b32 v23, 0x0
	ml_mov_b32 v24, 0x0
	ml_mov_b32 v25, 0x0
	ml_mov_b32 v26, 0x0
	ml_mov_b32 v27, 0x0
	ml_mov_b32 v28, 0x0
	ml_mov_b32 v29, 0x0
	ml_mov_b32 v30, 0x0
	ml_mov_b32 v31, 0x0
	ml_mov_v2s_b32 s90, v103, 0x0
	ml_mov_v2s_b32 s91, v103, 0x1
BB0_10:                                 ; %._crit_edge
	.loc	1 30 59                         ; generated-gqa-page-pipeline.py:30:59
	sl_wait vmcnt(0) lmcnt(0) g2scnt(0)
	sl_barrier 
	ml_mov_v2s_b32 s22, v103, 0x2
	.loc	1 43 20                         ; generated-gqa-page-pipeline.py:43:20
	sl_cmp_lt_i32 wcr, s94, s22
	.loc	1 43 7 is_stmt 0                ; generated-gqa-page-pipeline.py:43:7
	sl_cbr_wcrz BB0_72, wcr
; %bb.11:
	.loc	1 44 55 is_stmt 1               ; generated-gqa-page-pipeline.py:44:55
	sl_sra_b32 {s0, wcr}, s94, 0x4
	.loc	1 44 41 is_stmt 0               ; generated-gqa-page-pipeline.py:44:41
	sl_sra_b32 {s1, wcr}, s0, 0x1f
	sl_mov_b32 s3, 0xffffffff
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	sl_add_i64 s[0:1], s[90:91], s[0:1]
	.loc	1 44 23                         ; generated-gqa-page-pipeline.py:44:23
	ml_lsa_load_dword v32, s[0:3], noreg, noreg, #0, ca
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s2, s94, 0x1
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	sl_mov_b32 s15, 0xfff00004
	ml_mov_b32 v33, 0x0
	.loc	1 44 23                         ; generated-gqa-page-pipeline.py:44:23
	sl_wait vmcnt(0)
	ml_mov_v2s_b32 s7, v32, 0x0
	sl_sra_b32 {s8, wcr}, s7, 0x1f
	.loc	1 46 27                         ; generated-gqa-page-pipeline.py:46:27
	sl_mul_u64_u32 s[0:1], s82, s7
	sl_mull_u32 s3, s83, s7
	.loc	1 45 48                         ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s2, s22
	sl_sub_bi_u32 s2, s10, s10, wcr
	.loc	1 46 27                         ; generated-gqa-page-pipeline.py:46:27
	sl_mull_u32 s4, s82, s8
	sl_add_i32 s1, s1, s4
	.loc	1 48 36                         ; generated-gqa-page-pipeline.py:48:36
	ml_mov_v2s_b32 s4, v103, 0x3
	ml_mov_v2s_b32 s5, v103, 0x4
	.loc	1 46 27                         ; generated-gqa-page-pipeline.py:46:27
	sl_add_i32 s1, s1, s3
	.loc	1 48 36                         ; generated-gqa-page-pipeline.py:48:36
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x1
	sl_add_i64 s[0:1], s[32:33], s[0:1]
	sl_shl_b64 {s[4:5], wcr}, s[4:5], 0x1
	sl_add_i64 s[12:13], s[0:1], s[4:5]
	.loc	1 48 20 is_stmt 0               ; generated-gqa-page-pipeline.py:48:20
	ml_lsa_blkload_x1 v32, s[12:15], noreg, noreg, #0, ca
	.loc	1 48 36                         ; generated-gqa-page-pipeline.py:48:36
	sl_shl_b64 {s[0:1], wcr}, s[44:45], 0x1
	sl_mov_b32 s4, 0x0
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	sl_or_b32 {s2, wcr}, s2, 0x0
	sl_cbr_wcrz BB0_13, wcr
; %bb.12:
	sl_add_i64 s[16:17], s[12:13], s[44:45]
	sl_mov_b64 s[18:19], s[14:15]
	ml_lsa_blkload_x1 v33, s[16:19], noreg, noreg, #0, ca
BB0_13:
	.loc	1 0 0                           ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[12:13], s[12:13], s[0:1]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s0, s94, 0x2
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s0, s22
	sl_sub_bi_u32 s3, s10, s10, wcr
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v34, 0x0
	sl_cbr_wcrz BB0_15, wcr
; %bb.14:
	ml_lsa_blkload_x1 v34, s[12:15], noreg, noreg, #0, ca
BB0_15:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[12:13], s[12:13], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s0, s94, 0x3
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s0, s22
	sl_sub_bi_u32 s4, s10, s10, wcr
	sl_mov_b32 s0, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v35, 0x0
	sl_cbr_wcrz BB0_17, wcr
; %bb.16:
	ml_lsa_blkload_x1 v35, s[12:15], noreg, noreg, #0, ca
BB0_17:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[12:13], s[12:13], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s1, s94, 0x4
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s1, s22
	sl_sub_bi_u32 s5, s10, s10, wcr
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v36, 0x0
	sl_cbr_wcrz BB0_19, wcr
; %bb.18:
	ml_lsa_blkload_x1 v36, s[12:15], noreg, noreg, #0, ca
BB0_19:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[12:13], s[12:13], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s0, s94, 0x5
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s0, s22
	sl_sub_bi_u32 s6, s10, s10, wcr
	sl_mov_b32 s1, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v37, 0x0
	sl_cbr_wcrz BB0_21, wcr
; %bb.20:
	ml_lsa_blkload_x1 v37, s[12:15], noreg, noreg, #0, ca
BB0_21:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[12:13], s[12:13], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s0, s94, 0x6
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s0, s22
	sl_sub_bi_u32 s0, s10, s10, wcr
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v38, 0x0
	sl_cbr_wcrz BB0_23, wcr
; %bb.22:
	ml_lsa_blkload_x1 v38, s[12:15], noreg, noreg, #0, ca
BB0_23:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[16:17], s[12:13], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s1, s94, 0x7
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s1, s22
	sl_sub_bi_u32 s12, s10, s10, wcr
	sl_mov_b32 s1, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v39, 0x0
	sl_cbr_wcrz BB0_25, wcr
; %bb.24:
	sl_mov_b32 s19, 0xfff00004
	ml_lsa_blkload_x1 v39, s[16:19], noreg, noreg, #0, ca
BB0_25:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[16:17], s[16:17], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s9, s94, 0x8
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s9, s22
	sl_sub_bi_u32 s13, s10, s10, wcr
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v40, 0x0
	sl_cbr_wcrz BB0_27, wcr
; %bb.26:
	sl_mov_b32 s19, 0xfff00004
	ml_lsa_blkload_x1 v40, s[16:19], noreg, noreg, #0, ca
BB0_27:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[16:17], s[16:17], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s1, s94, 0x9
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s1, s22
	sl_sub_bi_u32 s14, s10, s10, wcr
	sl_mov_b32 s1, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v41, 0x0
	sl_cbr_wcrz BB0_29, wcr
; %bb.28:
	sl_mov_b32 s19, 0xfff00004
	ml_lsa_blkload_x1 v41, s[16:19], noreg, noreg, #0, ca
BB0_29:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[16:17], s[16:17], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s9, s94, 0xa
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s9, s22
	sl_sub_bi_u32 s15, s10, s10, wcr
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v42, 0x0
	sl_cbr_wcrz BB0_31, wcr
; %bb.30:
	sl_mov_b32 s19, 0xfff00004
	ml_lsa_blkload_x1 v42, s[16:19], noreg, noreg, #0, ca
BB0_31:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[20:21], s[16:17], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s1, s94, 0xb
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s1, s22
	sl_sub_bi_u32 s16, s10, s10, wcr
	sl_mov_b32 s1, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v43, 0x0
	sl_cbr_wcrz BB0_33, wcr
; %bb.32:
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_blkload_x1 v43, s[20:23], noreg, noreg, #0, ca
BB0_33:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[20:21], s[20:21], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s9, s94, 0xc
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s9, s22
	sl_sub_bi_u32 s17, s10, s10, wcr
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v44, 0x0
	sl_cbr_wcrz BB0_35, wcr
; %bb.34:
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_blkload_x1 v44, s[20:23], noreg, noreg, #0, ca
BB0_35:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[20:21], s[20:21], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s1, s94, 0xd
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s1, s22
	sl_sub_bi_u32 s18, s10, s10, wcr
	sl_mov_b32 s1, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v45, 0x0
	sl_cbr_wcrz BB0_37, wcr
; %bb.36:
	sl_mov_b32 s23, 0xfff00004
	ml_lsa_blkload_x1 v45, s[20:23], noreg, noreg, #0, ca
BB0_37:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[36:37], s[20:21], s[44:45]
	.loc	1 45 36 is_stmt 1               ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s9, s94, 0xe
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s9, s22
	sl_sub_bi_u32 s19, s10, s10, wcr
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v46, 0x0
	sl_cbr_wcrz BB0_39, wcr
; %bb.38:
	sl_mov_b32 s39, 0xfff00004
	ml_lsa_blkload_x1 v46, s[36:39], noreg, noreg, #0, ca
BB0_39:
	.loc	1 45 36                         ; generated-gqa-page-pipeline.py:45:36
	sl_add_i32 s1, s94, 0xf
	.loc	1 45 48 is_stmt 0               ; generated-gqa-page-pipeline.py:45:48
	sl_cmp_lt_i32 wcr, s1, s22
	sl_sub_bi_u32 s20, s10, s10, wcr
	sl_mov_b32 s43, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_mov_b32 v47, 0x0
	sl_cbr_wcrz BB0_41, wcr
; %bb.40:
	.loc	1 0 0 is_stmt 0                 ; generated-gqa-page-pipeline.py:0
	sl_add_i64 s[36:37], s[36:37], s[44:45]
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	sl_mov_b32 s39, 0xfff00004
	ml_lsa_blkload_x1 v47, s[36:39], noreg, noreg, #0, ca
                                        ; implicit-def: $vgpr73
BB0_41:
	.loc	1 47 27 is_stmt 1               ; generated-gqa-page-pipeline.py:47:27
	sl_mull_u32 s1, s88, s8
	sl_mul_u64_u32 s[8:9], s88, s7
	sl_add_i32 s1, s9, s1
	sl_mull_u32 s7, s89, s7
	sl_add_i32 s9, s1, s7
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	sl_wait vmcnt(0)
	ml_slb_store_b32x4  v[32:35], v70, noreg, #0, null
	.loc	1 49 38                         ; generated-gqa-page-pipeline.py:49:38
	sl_shl_b64 {s[8:9], wcr}, s[8:9], 0x1
	sl_add_i64 s[8:9], s[34:35], s[8:9]
	sl_add_i64 s[32:33], s[8:9], s[42:43]
	.loc	1 49 20 is_stmt 0               ; generated-gqa-page-pipeline.py:49:20
	sl_mov_b32 s35, 0xfff00004
	ml_lsa_blkload_x1 v33, s[32:35], noreg, noreg, #0, ca
	.loc	1 49 38                         ; generated-gqa-page-pipeline.py:49:38
	sl_shl_b64 {s[8:9], wcr}, s[78:79], 0x1
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_mov_b32 v34, 0x0
	ml_mov_b32 v35, 0x0
	.loc	1 48 20 is_stmt 1               ; generated-gqa-page-pipeline.py:48:20
	ml_slb_store_b32x4  v[36:39], v60, noreg, #0, null
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_or_b32 {s2, wcr}, s2, 0x0
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_store_b32x4  v[40:43], v69, noreg, #0, null
	ml_slb_store_b32x4  v[44:47], v58, noreg, #0, null
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_43, wcr
; %bb.42:
	sl_add_i64 s[36:37], s[32:33], s[78:79]
	sl_mov_b64 s[38:39], s[34:35]
	ml_lsa_blkload_x1 v35, s[36:39], noreg, noreg, #0, ca
BB0_43:
	sl_or_b32 {s3, wcr}, s3, 0x0
	.loc	1 49 0 is_stmt 0                ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[8:9]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_45, wcr
; %bb.44:
	ml_lsa_blkload_x1 v34, s[32:35], noreg, noreg, #0, ca
BB0_45:
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_mov_b32 v36, 0x0
	sl_or_b32 {s4, wcr}, s4, 0x0
	ml_mov_b32 v37, 0x0
	sl_cbr_wcrz BB0_47, wcr
; %bb.46:
	ml_lsa_blkload_x1 v37, s[32:35], noreg, noreg, #0, ca
BB0_47:
	sl_or_b32 {s5, wcr}, s5, 0x0
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_49, wcr
; %bb.48:
	ml_lsa_blkload_x1 v36, s[32:35], noreg, noreg, #0, ca
BB0_49:
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_mov_b32 v38, 0x0
	sl_or_b32 {s6, wcr}, s6, 0x0
	ml_mov_b32 v39, 0x0
	sl_cbr_wcrz BB0_51, wcr
; %bb.50:
	ml_lsa_blkload_x1 v39, s[32:35], noreg, noreg, #0, ca
BB0_51:
	sl_or_b32 {s0, wcr}, s0, 0x0
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_53, wcr
; %bb.52:
	ml_lsa_blkload_x1 v38, s[32:35], noreg, noreg, #0, ca
BB0_53:
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_mov_b32 v41, 0x0
	sl_or_b32 {s12, wcr}, s12, 0x0
	ml_mov_b32 v40, 0x0
	sl_cbr_wcrz BB0_55, wcr
; %bb.54:
	ml_lsa_blkload_x1 v40, s[32:35], noreg, noreg, #0, ca
BB0_55:
	sl_or_b32 {s13, wcr}, s13, 0x0
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_57, wcr
; %bb.56:
	ml_lsa_blkload_x1 v41, s[32:35], noreg, noreg, #0, ca
BB0_57:
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[32:33], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_mov_b32 v42, 0x0
	sl_or_b32 {s14, wcr}, s14, 0x0
	ml_mov_b32 v43, 0x0
	sl_cbr_wcrz BB0_59, wcr
; %bb.58:
	ml_lsa_blkload_x1 v43, s[32:35], noreg, noreg, #0, ca
BB0_59:
	sl_or_b32 {s15, wcr}, s15, 0x0
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[12:13], s[32:33], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_61, wcr
; %bb.60:
	sl_mov_b32 s15, 0xfff00004
	ml_lsa_blkload_x1 v42, s[12:15], noreg, noreg, #0, ca
BB0_61:
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[12:13], s[12:13], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_mov_b32 v44, 0x0
	sl_or_b32 {s16, wcr}, s16, 0x0
	ml_mov_b32 v45, 0x0
	sl_cbr_wcrz BB0_63, wcr
; %bb.62:
	sl_mov_b32 s15, 0xfff00004
	ml_lsa_blkload_x1 v45, s[12:15], noreg, noreg, #0, ca
BB0_63:
	sl_or_b32 {s17, wcr}, s17, 0x0
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[12:13], s[12:13], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_65, wcr
; %bb.64:
	sl_mov_b32 s15, 0xfff00004
	ml_lsa_blkload_x1 v44, s[12:15], noreg, noreg, #0, ca
BB0_65:
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[12:13], s[12:13], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_mov_b32 v46, 0x0
	sl_or_b32 {s18, wcr}, s18, 0x0
	ml_mov_b32 v47, 0x0
	sl_cbr_wcrz BB0_67, wcr
; %bb.66:
	sl_mov_b32 s15, 0xfff00004
	ml_lsa_blkload_x1 v47, s[12:15], noreg, noreg, #0, ca
BB0_67:
	sl_or_b32 {s19, wcr}, s19, 0x0
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[12:13], s[12:13], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_cbr_wcrz BB0_69, wcr
; %bb.68:
	sl_mov_b32 s15, 0xfff00004
	ml_lsa_blkload_x1 v46, s[12:15], noreg, noreg, #0, ca
BB0_69:
	ml_mov_b32 v32, 0x0
	sl_or_b32 {s20, wcr}, s20, 0x0
	ml_mov_b32 v58, 0x0
	sl_cbr_wcrz BB0_71, wcr
; %bb.70:
	.loc	1 49 0                          ; generated-gqa-page-pipeline.py:49
	sl_add_i64 s[0:1], s[12:13], s[78:79]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_mov_b32 s3, 0xfff00004
	ml_lsa_blkload_x1 v58, s[0:3], noreg, noreg, #0, ca
BB0_71:
	sl_mov_b32 s2, 0x3020706
	sl_wait vmcnt(0)
	ml_byte_permute_b32 v70, v35, v33, s2
	sl_mov_b32 s1, 0x1000504
	ml_byte_permute_b32 v69, v35, v33, s1
	sl_mov_b32 s0, 0x1000
	ml_slb_store_b32x2  v[69:70], v55, s0, #0, null
	ml_byte_permute_b32 v35, v37, v34, s2
	ml_byte_permute_b32 v34, v37, v34, s1
	ml_byte_permute_b32 v33, v43, v41, s1
	ml_slb_store_b32x2  v[34:35], v55, s0, #64, null
	ml_byte_permute_b32 v34, v43, v41, s2
	.loc	1 18 29 is_stmt 1               ; generated-gqa-page-pipeline.py:18:29
	ml_and_b32 v35, tid, 0xf
	.loc	1 45 36                         ; generated-gqa-page-pipeline.py:45:36
	ml_add_i32 v35, s94, v35
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_slb_store_b32x2  v[33:34], v55, s0, #256, null
	ml_byte_permute_b32 v34, v45, v42, s2
	ml_byte_permute_b32 v33, v45, v42, s1
	.loc	1 45 48                         ; generated-gqa-page-pipeline.py:45:48
	ml_cmp_gt_i32 tcr, s22, v35
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_slb_store_b32x2  v[33:34], v55, s0, #320, null
	ml_byte_permute_b32 v34, v39, v36, s2
	ml_byte_permute_b32 v33, v39, v36, s1
	ml_slb_store_b32x2  v[33:34], v52, s0, #0, null
	ml_byte_permute_b32 v34, v40, v38, s2
	ml_byte_permute_b32 v33, v40, v38, s1
	ml_slb_store_b32x2  v[33:34], v52, s0, #64, null
	ml_byte_permute_b32 v34, v47, v44, s2
	ml_byte_permute_b32 v33, v47, v44, s1
	ml_slb_store_b32x2  v[33:34], v52, s0, #256, null
	ml_byte_permute_b32 v34, v58, v46, s2
	ml_byte_permute_b32 v33, v58, v46, s1
	ml_slb_store_b32x2  v[33:34], v52, s0, #320, null
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	sl_wait lmcnt(0)
	sl_barrier 
	ml_slb_load_b32x1  v36, v49, noreg, #0, null
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	ml_mov_b32 v58, v57
	ml_mov_b32 v33, v32
	ml_mov_b32 v34, v32
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v37, v66, noreg, #0, null
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	ml_mov_b32 v35, v32
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	sl_mov_b32 s2, 0x400
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	ml_mov_b32 v60, v59
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v38, v65, noreg, #0, null
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	ml_mov_b32 v55, v54
	ml_mov_b32 v52, v51
	ml_xor_b32 v40, tid, 0x2
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v39, v64, noreg, #0, null
	ml_xor_b32 v41, tid, 0x1
	ml_and_b32 v42, tid, 0x10
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[57:58], v[36:37], v[32:35]
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v36, v49, s2, #0, null
	ml_slb_load_b32x1  v37, v66, s2, #0, null
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	ml_mov_b32 v57, v56
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[59:60], v[38:39], v[32:35]
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v38, v65, s2, #0, null
	ml_slb_load_b32x1  v39, v64, s2, #0, null
	sl_mov_b32 s2, 0x800
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[54:55], v[36:37], v[32:35]
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v36, v49, s2, #0, null
	ml_slb_load_b32x1  v37, v66, s2, #0, null
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	ml_mov_b32 v54, v53
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[56:57], v[38:39], v[32:35]
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v38, v65, s2, #0, null
	ml_slb_load_b32x1  v39, v64, s2, #0, null
	sl_mov_b32 s2, 0xc00
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[51:52], v[36:37], v[32:35]
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v36, v49, s2, #0, null
	ml_slb_load_b32x1  v37, v66, s2, #0, null
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	ml_mov_b32 v49, v48
	ml_mov_b32 v51, v50
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[53:54], v[38:39], v[32:35]
	.loc	1 48 20                         ; generated-gqa-page-pipeline.py:48:20
	ml_slb_load_b32x1  v38, v65, s2, #0, null
	ml_slb_load_b32x1  v39, v64, s2, #0, null
	.loc	1 50 27                         ; generated-gqa-page-pipeline.py:50:27
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[48:49], v[36:37], v[32:35]
	sl_wait lmcnt(0)
	ml_matrix_mad_f32_bf16_m16n16k16 v[32:35], v[50:51], v[38:39], v[32:35]
	ml_mov_b32 v34, 0xff800000
	ml_xor_b32 v38, tid, 0x8
	ml_xor_b32 v39, tid, 0x4
	.loc	1 50 32 is_stmt 0               ; generated-gqa-page-pipeline.py:50:32
	ml_mul_f32 v32, s76, v32
	.loc	1 51 57 is_stmt 1               ; generated-gqa-page-pipeline.py:51:57
	ml_csel_b32 v32, v32, v34, tcr
.Ltmp50:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v35, v32, v38
.Ltmp51:
	.loc	1 50 32                         ; generated-gqa-page-pipeline.py:50:32
	ml_mul_f32 v33, s76, v33
	.loc	1 51 57                         ; generated-gqa-page-pipeline.py:51:57
	ml_csel_b32 v33, v33, v34, tcr
	.loc	1 56 77                         ; generated-gqa-page-pipeline.py:56:77
	ml_cmp_eq_u32 tcr, v42, 0x0
.Ltmp52:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v34, v33, v38
.Ltmp53:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v35, v32, v35
.Ltmp54:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v36, v35, v39
.Ltmp55:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v34, v33, v34
.Ltmp56:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v37, v34, v39
.Ltmp57:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v35, v35, v36
.Ltmp58:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v36, v35, v40
.Ltmp59:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v34, v34, v37
.Ltmp60:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v37, v34, v40
.Ltmp61:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v35, v35, v36
.Ltmp62:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v36, v35, v41
.Ltmp63:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v34, v34, v37
.Ltmp64:
	.loc	2 213 40                        ; standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ]
	ml_slb_shuffle_rtn_b32 v37, v34, v41
.Ltmp65:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(1)
	ml_max_f32 v35, v35, v36
.Ltmp66:
	.loc	1 52 42                         ; generated-gqa-page-pipeline.py:52:42
	ml_max_f32 v43, v71, v35
	.loc	1 53 44                         ; generated-gqa-page-pipeline.py:53:44
	ml_sub_f32 v32, v32, v43
.Ltmp67:
	.loc	2 192 27                        ; standard.py:192:27 @[ standard.py:213:40 @[ generated-gqa-page-pipeline.py:52:57 ] ]
	sl_wait lmcnt(0)
	ml_max_f32 v34, v34, v37
.Ltmp68:
	.loc	1 53 35                         ; generated-gqa-page-pipeline.py:53:35
	ml_exp_f32 v44, v32
	.loc	1 52 42                         ; generated-gqa-page-pipeline.py:52:42
	ml_max_f32 v45, v72, v34
	.loc	1 53 44                         ; generated-gqa-page-pipeline.py:53:44
	ml_sub_f32 v32, v33, v45
	.loc	1 56 77                         ; generated-gqa-page-pipeline.py:56:77
	ml_xor_b32 v33, v63, 0x10
	.loc	1 53 35                         ; generated-gqa-page-pipeline.py:53:35
	ml_exp_f32 v46, v32
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_slb_blkload_x1  v32, noreg, s0, #0, null
	.loc	1 54 45                         ; generated-gqa-page-pipeline.py:54:45
	ml_sub_f32 v34, v71, v43
	ml_sub_f32 v35, v72, v45
	.loc	1 56 77                         ; generated-gqa-page-pipeline.py:56:77
	ml_cvt_bf16_f32  v36, v44
	.loc	1 54 31                         ; generated-gqa-page-pipeline.py:54:31
	ml_exp_f32 v47, v34
	.loc	1 56 77                         ; generated-gqa-page-pipeline.py:56:77
	ml_cvt_bf16_f32  v37, v46
	ml_csel_b32 v42, v36, v37, tcr
	ml_cvt_i32_i16  v42, v42
	ml_slb_shuffle_rtn_b32 v42, v42, v63
	ml_csel_b32 v34, v37, v36, tcr
	ml_cvt_i32_i16  v34, v34
	.loc	1 54 31                         ; generated-gqa-page-pipeline.py:54:31
	ml_exp_f32 v48, v35
	.loc	1 56 77                         ; generated-gqa-page-pipeline.py:56:77
	ml_slb_shuffle_rtn_b32 v34, v34, v33
	ml_and_b32 v35, tid, 0x20
	.loc	1 56 36 is_stmt 0               ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v0, v0, v47
	ml_mul_f32 v2, v2, v47
	.loc	1 49 20 is_stmt 1               ; generated-gqa-page-pipeline.py:49:20
	ml_slb_blkload_x1  v33, noreg, s0, #256, null
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v1, v1, v48
	ml_mul_f32 v3, v3, v48
	.loc	1 56 77 is_stmt 0               ; generated-gqa-page-pipeline.py:56:77
	ml_cmp_eq_u32 tcr, v35, 0x0
	.loc	1 49 20 is_stmt 1               ; generated-gqa-page-pipeline.py:49:20
	ml_slb_load_b32x1  v37, v62, s0, #768, null
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v4, v4, v47
	ml_mul_f32 v5, v5, v48
	ml_mul_f32 v6, v6, v47
	ml_mul_f32 v7, v7, v48
	ml_mul_f32 v8, v8, v47
	ml_mul_f32 v9, v9, v48
	ml_mul_f32 v10, v10, v47
	.loc	1 56 77 is_stmt 0               ; generated-gqa-page-pipeline.py:56:77
	sl_wait lmcnt(3)
	ml_and_b32 v35, v42, 0xffff
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v11, v11, v48
	ml_mul_f32 v12, v12, v47
	ml_mul_f32 v13, v13, v48
	.loc	1 56 77                         ; generated-gqa-page-pipeline.py:56:77
	sl_wait lmcnt(2)
	ml_and_b32 v34, v34, 0xffff
	ml_csel_b32 v36, v35, v34, tcr
	ml_csel_b32 v34, v34, v35, tcr
	.loc	1 56 87                         ; generated-gqa-page-pipeline.py:56:87
	ml_byte_permute_b32 v34, v34, v36, s1
	.loc	1 49 20 is_stmt 1               ; generated-gqa-page-pipeline.py:49:20
	ml_slb_load_b32x1  v36, v62, s0, #512, null
	.loc	1 56 87                         ; generated-gqa-page-pipeline.py:56:87
	ml_mov_b32 v35, v34
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	sl_mov_b32 s0, 0x1400
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v14, v14, v47
	.loc	1 56 87 is_stmt 0               ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[0:3], v[34:35], v[32:33], v[0:3]
	.loc	1 49 20 is_stmt 1               ; generated-gqa-page-pipeline.py:49:20
	ml_slb_blkload_x1  v0, noreg, s0, #0, null
	ml_slb_blkload_x1  v1, noreg, s0, #256, null
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v15, v15, v48
	ml_mul_f32 v16, v16, v47
	ml_mul_f32 v17, v17, v48
	ml_mul_f32 v18, v18, v47
	ml_mul_f32 v19, v19, v48
	ml_mul_f32 v20, v20, v47
	ml_mul_f32 v21, v21, v48
	ml_mul_f32 v22, v22, v47
	.loc	1 56 87 is_stmt 0               ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[4:7], v[34:35], v[36:37], v[4:7]
	.loc	1 49 20 is_stmt 1               ; generated-gqa-page-pipeline.py:49:20
	ml_slb_load_b32x1  v4, v62, s0, #512, null
	ml_slb_load_b32x1  v5, v62, s0, #768, null
	sl_mov_b32 s0, 0x1800
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v23, v23, v48
	ml_mul_f32 v24, v24, v47
	.loc	1 56 87 is_stmt 0               ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[8:11], v[34:35], v[0:1], v[8:11]
	.loc	1 49 20 is_stmt 1               ; generated-gqa-page-pipeline.py:49:20
	ml_slb_blkload_x1  v0, noreg, s0, #0, null
	ml_slb_blkload_x1  v1, noreg, s0, #256, null
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v25, v25, v48
	ml_mul_f32 v26, v26, v47
.Ltmp69:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v8, v44, v38
.Ltmp70:
	.loc	1 56 36                         ; generated-gqa-page-pipeline.py:56:36
	ml_mul_f32 v27, v27, v48
	ml_mul_f32 v28, v28, v47
	ml_mul_f32 v29, v29, v48
	ml_mul_f32 v30, v30, v47
	ml_mul_f32 v31, v31, v48
	.loc	1 56 87 is_stmt 0               ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[12:15], v[34:35], v[4:5], v[12:15]
	.loc	1 49 20 is_stmt 1               ; generated-gqa-page-pipeline.py:49:20
	ml_slb_load_b32x1  v4, v62, s0, #512, null
	ml_slb_load_b32x1  v5, v62, s0, #768, null
	sl_mov_b32 s0, 0x1c00
	ml_mov_b32 v71, v43
	ml_mov_b32 v72, v45
	.loc	1 56 87                         ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[16:19], v[34:35], v[0:1], v[16:19]
.Ltmp71:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v0, v46, v38
.Ltmp72:
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_slb_blkload_x1  v1, noreg, s0, #256, null
.Ltmp73:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(4)
	ml_add_f32 v8, v44, v8
.Ltmp74:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v9, v8, v39
.Ltmp75:
	.loc	1 56 87                         ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(3)
	ml_matrix_mad_f32_bf16_m16n16k16 v[20:23], v[34:35], v[4:5], v[20:23]
.Ltmp76:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(2)
	ml_add_f32 v12, v46, v0
.Ltmp77:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v13, v12, v39
.Ltmp78:
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_slb_blkload_x1  v0, noreg, s0, #0, null
.Ltmp79:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(2)
	ml_add_f32 v4, v8, v9
.Ltmp80:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v8, v4, v40
.Ltmp81:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(2)
	ml_add_f32 v5, v12, v13
.Ltmp82:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v9, v5, v40
.Ltmp83:
	.loc	1 56 87                         ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[24:27], v[34:35], v[0:1], v[24:27]
	.loc	1 49 20                         ; generated-gqa-page-pipeline.py:49:20
	ml_slb_load_b32x1  v0, v62, s0, #512, null
	ml_slb_load_b32x1  v1, v62, s0, #768, null
.Ltmp84:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v4, v4, v8
.Ltmp85:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v8, v4, v41
.Ltmp86:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(3)
	ml_add_f32 v5, v5, v9
.Ltmp87:
	.loc	2 315 36                        ; standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ]
	ml_slb_shuffle_rtn_b32 v9, v5, v41
.Ltmp88:
	.loc	1 56 87                         ; generated-gqa-page-pipeline.py:56:87
	sl_wait lmcnt(2)
	ml_matrix_mad_f32_bf16_m16n16k16 v[28:31], v[34:35], v[0:1], v[28:31]
.Ltmp89:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(1)
	ml_add_f32 v0, v4, v8
.Ltmp90:
	.loc	1 55 46                         ; generated-gqa-page-pipeline.py:55:46
	ml_fma_f32 v67, v67, v47, v0
.Ltmp91:
	.loc	2 285 15                        ; standard.py:285:15 @[ standard.py:315:36 @[ generated-gqa-page-pipeline.py:55:66 ] ]
	sl_wait lmcnt(0)
	ml_add_f32 v0, v5, v9
.Ltmp92:
	.loc	1 55 46                         ; generated-gqa-page-pipeline.py:55:46
	ml_fma_f32 v68, v68, v48, v0
BB0_72:
	.loc	1 16 28                         ; generated-gqa-page-pipeline.py:16:28
	ml_and_b32 v24, tid, 0x30
	ml_srl_b32 v0, v24, 0x4
	.loc	1 21 29                         ; generated-gqa-page-pipeline.py:21:29
	sl_mull_u32 s0, s77, 0x8
	.loc	1 21 46 is_stmt 0               ; generated-gqa-page-pipeline.py:21:46
	ml_add_i32 v0, s0, v0
	.loc	1 59 31 is_stmt 1               ; generated-gqa-page-pipeline.py:59:31
	sl_shl_b64 {s[0:1], wcr}, s[74:75], 0x11
	sl_add_i64 s[2:3], s[24:25], s[0:1]
	ml_shl_b32 v0, v0, 0xd
	sl_mov_b32 s1, 0x0
	sl_mull_u32 s0, s50, 0x200
	sl_add_i64 s[2:3], s[0:1], s[2:3]
	ml_addo_u32 {v0, tcr}, s2, v0
	ml_mov_b32 v1, s3
	.loc	1 18 29                         ; generated-gqa-page-pipeline.py:18:29
	ml_and_b32 v4, tid, 0xf
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_shl_b32 v4, v4, 0x2
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v0, tcr}, v4, v0
	sl_mov_b32 s0, 0x8000
	.loc	1 60 33                         ; generated-gqa-page-pipeline.py:60:33
	sl_shl_b64 {s[6:7], wcr}, s[74:75], 0x8
	.loc	1 60 81 is_stmt 0               ; generated-gqa-page-pipeline.py:60:81
	sl_mov_b32 s51, s1
	.loc	1 59 31 is_stmt 1               ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v1, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s0, v0
	sl_mov_b32 s0, 0x40
	.loc	1 59 47 is_stmt 0               ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[0:1], v2, kop=0
	.loc	1 61 44 is_stmt 1               ; generated-gqa-page-pipeline.py:61:44
	sl_mov_b32 s15, 0xffffffff
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v8, tcr}, s0, v0
	sl_mov_b32 s0, 0x8040
	.loc	1 59 47 is_stmt 0               ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[4:5], v3, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v9, 0, v1, tcr
	ml_addo_u32 {v12, tcr}, s0, v0
	sl_mov_b32 s0, 0x80
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[8:9], v6, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v13, 0, v1, tcr
	ml_addo_u32 {v16, tcr}, s0, v0
	sl_mov_b32 s0, 0x8080
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[12:13], v7, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v17, 0, v1, tcr
	ml_addo_u32 {v20, tcr}, s0, v0
	sl_mov_b32 s0, 0xc0
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[16:17], v10, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v21, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	sl_mov_b32 s0, 0x80c0
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[20:21], v11, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s0, v0
	sl_mov_b32 s0, 0x100
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[2:3], v14, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v6, tcr}, s0, v0
	sl_mov_b32 s0, 0x8100
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[4:5], v15, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v7, 0, v1, tcr
	ml_addo_u32 {v8, tcr}, s0, v0
	sl_mov_b32 s0, 0x140
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[6:7], v18, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v9, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	sl_mov_b32 s0, 0x8140
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[8:9], v19, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s0, v0
	sl_mov_b32 s0, 0x180
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[2:3], v22, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v6, tcr}, s0, v0
	sl_mov_b32 s0, 0x8180
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[4:5], v23, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v7, 0, v1, tcr
	ml_addo_u32 {v2, tcr}, s0, v0
	sl_mov_b32 s0, 0x1c0
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[6:7], v26, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v3, 0, v1, tcr
	ml_addo_u32 {v4, tcr}, s0, v0
	.loc	1 59 47                         ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[2:3], v27, kop=0
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	sl_mov_b32 s0, 0x81c0
	.loc	1 61 44 is_stmt 1               ; generated-gqa-page-pipeline.py:61:44
	ml_and_b32 v2, tid, 0x1
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v5, 0, v1, tcr
	ml_addo_u32 {v0, tcr}, s0, v0
	.loc	1 59 47 is_stmt 0               ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[4:5], v30, kop=0
	.loc	1 61 44 is_stmt 1               ; generated-gqa-page-pipeline.py:61:44
	ml_srl_b32 v3, v24, 0x3
	ml_bfe2_b32 v4, tid, 0x22
	.loc	1 59 31                         ; generated-gqa-page-pipeline.py:59:31
	ml_addc_i32 v1, 0, v1, tcr
	.loc	1 59 47 is_stmt 0               ; generated-gqa-page-pipeline.py:59:47
	ml_lsa_store_a64_dword  v[0:1], v31, kop=0
	.loc	1 61 58 is_stmt 1               ; generated-gqa-page-pipeline.py:61:58
	ml_mul_f32 v0, v71, 0x3f317218
	ml_mul_f32 v1, v72, 0x3f317218
	.loc	1 61 44 is_stmt 0               ; generated-gqa-page-pipeline.py:61:44
	ml_cmp_eq_u32 tcr, v2, 0x0
	ml_shl_b32 v2, v61, 0x4
	ml_anyop3_b32 v2, 48, v2, v3, 0xfffffff8
	.loc	1 23 16 is_stmt 1               ; generated-gqa-page-pipeline.py:23:16
	ml_and_b32 v3, tid, 0x8
	.loc	1 61 44                         ; generated-gqa-page-pipeline.py:61:44
	ml_anyop3_b32 v2, v2, v4, v3, 0xfffffffe
	ml_csel_b32 v3, v0, v1, tcr
	ml_slb_shuffle_rtn_b32 v3, v3, v2
	ml_csel_b32 v0, v1, v0, tcr
	.loc	1 62 47                         ; generated-gqa-page-pipeline.py:62:47
	ml_csel_b32 v1, v67, v68, tcr
	.loc	1 61 44                         ; generated-gqa-page-pipeline.py:61:44
	ml_xor_b32 v4, v2, 0x1
	ml_slb_shuffle_rtn_b32 v5, v0, v4
	.loc	1 62 47                         ; generated-gqa-page-pipeline.py:62:47
	ml_csel_b32 v6, v68, v67, tcr
	.loc	1 61 44                         ; generated-gqa-page-pipeline.py:61:44
	ml_and_b32 v0, tid, 0x4
	ml_cmp_eq_u32 tcr, v0, 0x0
	.loc	1 62 47                         ; generated-gqa-page-pipeline.py:62:47
	ml_slb_shuffle_rtn_b32 v0, v1, v2
	.loc	1 61 44                         ; generated-gqa-page-pipeline.py:61:44
	ml_and_b32 v1, tid, 0x38
	.loc	1 60 52                         ; generated-gqa-page-pipeline.py:60:52
	sl_add_i64 s[0:1], s[6:7], s[50:51]
	.loc	1 61 44                         ; generated-gqa-page-pipeline.py:61:44
	sl_mov_b64 s[2:3], tcr
	ml_cmp_eq_u32 tcr, v1, 0x0
	.loc	1 62 47                         ; generated-gqa-page-pipeline.py:62:47
	ml_slb_shuffle_rtn_b32 v1, v6, v4
	.loc	1 16 28                         ; generated-gqa-page-pipeline.py:16:28
	ml_and_b32 v2, tid, 0x7
	ml_shl_b32 v2, v2, 0x6
	.loc	1 61 44                         ; generated-gqa-page-pipeline.py:61:44
	sl_mov_b64 s[4:5], tcr
	sl_mov_b64 tcr, s[2:3]
	sl_shl_b64 {s[0:1], wcr}, s[0:1], 0x2
	sl_add_i64 s[12:13], s[26:27], s[0:1]
	sl_mull_u32 s6, s77, 0x200
	ml_add_i32 v2, s6, v2
	sl_wait lmcnt(2)
	ml_csel_b32 v3, v3, v5, tcr
	sl_and_savetmsk_b64 {s[10:11], wcr}, s[4:5], tmsk
	ml_lsa_store_dword v3, s[12:15], signed v2, noreg, #0, wb
	sl_or_b64 {tmsk, wcr}, tmsk, s[10:11]
	.loc	1 62 47                         ; generated-gqa-page-pipeline.py:62:47
	sl_and_savetmsk_b64 {s[6:7], wcr}, s[4:5], tmsk
	sl_xor_b64 {s[4:5], wcr}, tmsk, s[6:7]
	; mask branch BB0_74
BB0_73:
	.loc	1 0 47 is_stmt 0                ; generated-gqa-page-pipeline.py:0:47
	sl_mov_b64 tcr, s[2:3]
	sl_wait lmcnt(0)
	ml_csel_b32 v0, v0, v1, tcr
	.loc	1 62 47                         ; generated-gqa-page-pipeline.py:62:47
	sl_add_i64 s[12:13], s[28:29], s[0:1]
	ml_lsa_store_dword v0, s[12:15], signed v2, noreg, #0, wb
BB0_74:                                 ; %Flow
	.loc	1 0 47                          ; generated-gqa-page-pipeline.py:0:47
	sl_or_b64 {tmsk, wcr}, tmsk, s[4:5]
BB0_75:                                 ; %common.ret
	sl_eop 
.Ltmp93:
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.globl	_gqa_decode_attention.kd
	.type	_gqa_decode_attention.kd,@object
	.size	_gqa_decode_attention.kd, 64
_gqa_decode_attention.kd:
	.asciz	"\000\000\000"
	.long	0
	.asciz	"\000\000\000\000\000\000\000"
	.quad	_gqa_decode_attention@rel64-_gqa_decode_attention.kd
	.asciz	"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.long	537369
	.asciz	"\003\000\364\006\211\000\000\000\000\000\000"
	.text
.Lfunc_end0:
	.size	_gqa_decode_attention, .Lfunc_end0-_gqa_decode_attention
	.cfi_endproc
                                        ; -- End function
	.section	.Iluvatar.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 12552
; NumSgprs: 99
; NumVgprs: 104
; ScratchSize: 0
; MemoryBound: 0
; FloatMode: 12
; IeeeMode: 1
; SLBByteSize: 0 bytes/workgroup (compile time only)
; SGPRBlocks: 12
; VGPRBlocks: 25
; NumSGPRsForWarpsPerNU: 95
; NumVGPRsForWarpsPerNR: 104
; ReqNTIDx: 0
; MaxNTIDx: 0
; MinCTASm: 0
; ActiveWarp: 2
; WarpLimiterHint : 0
	.section	.debug_abbrev,"",@progbits
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	8                               ; DW_FORM_string
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	16                              ; DW_AT_stmt_list
	.byte	6                               ; DW_FORM_data4
	.byte	27                              ; DW_AT_comp_dir
	.byte	8                               ; DW_FORM_string
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	3                               ; DW_AT_name
	.byte	8                               ; DW_FORM_string
	.byte	32                              ; DW_AT_inline
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	3                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	1                               ; DW_CHILDREN_yes
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	4                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	1                               ; DW_FORM_addr
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	5                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	1                               ; DW_CHILDREN_yes
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	6                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	11                              ; DW_FORM_data1
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	7                               ; Abbreviation Code
	.byte	29                              ; DW_TAG_inlined_subroutine
	.byte	0                               ; DW_CHILDREN_no
	.byte	49                              ; DW_AT_abstract_origin
	.byte	19                              ; DW_FORM_ref4
	.byte	85                              ; DW_AT_ranges
	.byte	6                               ; DW_FORM_data4
	.byte	88                              ; DW_AT_call_file
	.byte	11                              ; DW_FORM_data1
	.byte	89                              ; DW_AT_call_line
	.byte	5                               ; DW_FORM_data2
	.byte	87                              ; DW_AT_call_column
	.byte	11                              ; DW_FORM_data1
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	.debug_info,"",@progbits
	.long	320                             ; Length of Unit
	.short	2                               ; DWARF version number
	.long	.debug_abbrev                   ; Offset Into Abbrev. Section
	.byte	8                               ; Address Size (in bytes)
	.byte	1                               ; Abbrev [1] 0xb:0x139 DW_TAG_compile_unit
	.ascii	"triton"                        ; DW_AT_producer
	.byte	0
	.short	2                               ; DW_AT_language
	.ascii	"generated-gqa-page-pipeline.py" ; DW_AT_name
	.byte	0
	.long	.debug_line                     ; DW_AT_stmt_list
	.ascii	"/workspace/experiments/minicpm-s2/gqa-page-pipeline-s2-query-reuse-v1-20261027" ; DW_AT_comp_dir
	.byte	0
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.byte	2                               ; Abbrev [2] 0x97:0x18 DW_TAG_subprogram
	.ascii	"_gqa_decode_attention"         ; DW_AT_name
	.byte	0
	.byte	1                               ; DW_AT_inline
	.byte	3                               ; Abbrev [3] 0xaf:0x94 DW_TAG_subprogram
	.quad	.Lfunc_begin0                   ; DW_AT_low_pc
	.quad	.Lfunc_end0                     ; DW_AT_high_pc
	.long	151                             ; DW_AT_abstract_origin
	.byte	4                               ; Abbrev [4] 0xc4:0x18 DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.quad	.Ltmp1                          ; DW_AT_low_pc
	.quad	.Ltmp2                          ; DW_AT_high_pc
	.byte	1                               ; DW_AT_call_file
	.byte	11                              ; DW_AT_call_line
	.byte	41                              ; DW_AT_call_column
	.byte	5                               ; Abbrev [5] 0xdc:0x19 DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges0                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	37                              ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0xe8:0xc DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges1                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0xf5:0x1a DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges2                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	40                              ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0x101:0xd DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges3                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x10f:0x19 DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges4                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	52                              ; DW_AT_call_line
	.byte	57                              ; DW_AT_call_column
	.byte	6                               ; Abbrev [6] 0x11b:0xc DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges5                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.byte	213                             ; DW_AT_call_line
	.byte	40                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	5                               ; Abbrev [5] 0x128:0x1a DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges6                 ; DW_AT_ranges
	.byte	1                               ; DW_AT_call_file
	.byte	55                              ; DW_AT_call_line
	.byte	66                              ; DW_AT_call_column
	.byte	7                               ; Abbrev [7] 0x134:0xd DW_TAG_inlined_subroutine
	.long	151                             ; DW_AT_abstract_origin
	.long	.Ldebug_ranges7                 ; DW_AT_ranges
	.byte	2                               ; DW_AT_call_file
	.short	315                             ; DW_AT_call_line
	.byte	36                              ; DW_AT_call_column
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.byte	0                               ; End Of Children Mark
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Ltmp3-.Lfunc_begin0
	.quad	.Ltmp4-.Lfunc_begin0
	.quad	.Ltmp5-.Lfunc_begin0
	.quad	.Ltmp8-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp11-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp16-.Lfunc_begin0
	.quad	.Ltmp17-.Lfunc_begin0
	.quad	.Ltmp19-.Lfunc_begin0
	.quad	.Ltmp20-.Lfunc_begin0
	.quad	.Ltmp22-.Lfunc_begin0
	.quad	.Ltmp23-.Lfunc_begin0
	.quad	.Ltmp24-.Lfunc_begin0
	.quad	.Ltmp25-.Lfunc_begin0
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp6-.Lfunc_begin0
	.quad	.Ltmp7-.Lfunc_begin0
	.quad	.Ltmp9-.Lfunc_begin0
	.quad	.Ltmp10-.Lfunc_begin0
	.quad	.Ltmp12-.Lfunc_begin0
	.quad	.Ltmp13-.Lfunc_begin0
	.quad	.Ltmp14-.Lfunc_begin0
	.quad	.Ltmp15-.Lfunc_begin0
	.quad	.Ltmp17-.Lfunc_begin0
	.quad	.Ltmp18-.Lfunc_begin0
	.quad	.Ltmp20-.Lfunc_begin0
	.quad	.Ltmp21-.Lfunc_begin0
	.quad	.Ltmp23-.Lfunc_begin0
	.quad	.Ltmp24-.Lfunc_begin0
	.quad	.Ltmp25-.Lfunc_begin0
	.quad	.Ltmp26-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Ltmp27-.Lfunc_begin0
	.quad	.Ltmp28-.Lfunc_begin0
	.quad	.Ltmp29-.Lfunc_begin0
	.quad	.Ltmp30-.Lfunc_begin0
	.quad	.Ltmp31-.Lfunc_begin0
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp33-.Lfunc_begin0
	.quad	.Ltmp35-.Lfunc_begin0
	.quad	.Ltmp36-.Lfunc_begin0
	.quad	.Ltmp37-.Lfunc_begin0
	.quad	.Ltmp38-.Lfunc_begin0
	.quad	.Ltmp40-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp43-.Lfunc_begin0
	.quad	.Ltmp44-.Lfunc_begin0
	.quad	.Ltmp49-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges3:
	.quad	.Ltmp31-.Lfunc_begin0
	.quad	.Ltmp32-.Lfunc_begin0
	.quad	.Ltmp33-.Lfunc_begin0
	.quad	.Ltmp34-.Lfunc_begin0
	.quad	.Ltmp38-.Lfunc_begin0
	.quad	.Ltmp39-.Lfunc_begin0
	.quad	.Ltmp41-.Lfunc_begin0
	.quad	.Ltmp42-.Lfunc_begin0
	.quad	.Ltmp44-.Lfunc_begin0
	.quad	.Ltmp45-.Lfunc_begin0
	.quad	.Ltmp46-.Lfunc_begin0
	.quad	.Ltmp47-.Lfunc_begin0
	.quad	.Ltmp48-.Lfunc_begin0
	.quad	.Ltmp49-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges4:
	.quad	.Ltmp50-.Lfunc_begin0
	.quad	.Ltmp51-.Lfunc_begin0
	.quad	.Ltmp52-.Lfunc_begin0
	.quad	.Ltmp66-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp68-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges5:
	.quad	.Ltmp53-.Lfunc_begin0
	.quad	.Ltmp54-.Lfunc_begin0
	.quad	.Ltmp55-.Lfunc_begin0
	.quad	.Ltmp56-.Lfunc_begin0
	.quad	.Ltmp57-.Lfunc_begin0
	.quad	.Ltmp58-.Lfunc_begin0
	.quad	.Ltmp59-.Lfunc_begin0
	.quad	.Ltmp60-.Lfunc_begin0
	.quad	.Ltmp61-.Lfunc_begin0
	.quad	.Ltmp62-.Lfunc_begin0
	.quad	.Ltmp63-.Lfunc_begin0
	.quad	.Ltmp64-.Lfunc_begin0
	.quad	.Ltmp65-.Lfunc_begin0
	.quad	.Ltmp66-.Lfunc_begin0
	.quad	.Ltmp67-.Lfunc_begin0
	.quad	.Ltmp68-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges6:
	.quad	.Ltmp69-.Lfunc_begin0
	.quad	.Ltmp70-.Lfunc_begin0
	.quad	.Ltmp71-.Lfunc_begin0
	.quad	.Ltmp72-.Lfunc_begin0
	.quad	.Ltmp73-.Lfunc_begin0
	.quad	.Ltmp75-.Lfunc_begin0
	.quad	.Ltmp76-.Lfunc_begin0
	.quad	.Ltmp78-.Lfunc_begin0
	.quad	.Ltmp79-.Lfunc_begin0
	.quad	.Ltmp83-.Lfunc_begin0
	.quad	.Ltmp84-.Lfunc_begin0
	.quad	.Ltmp88-.Lfunc_begin0
	.quad	.Ltmp89-.Lfunc_begin0
	.quad	.Ltmp90-.Lfunc_begin0
	.quad	.Ltmp91-.Lfunc_begin0
	.quad	.Ltmp92-.Lfunc_begin0
	.quad	0
	.quad	0
.Ldebug_ranges7:
	.quad	.Ltmp73-.Lfunc_begin0
	.quad	.Ltmp74-.Lfunc_begin0
	.quad	.Ltmp76-.Lfunc_begin0
	.quad	.Ltmp77-.Lfunc_begin0
	.quad	.Ltmp79-.Lfunc_begin0
	.quad	.Ltmp80-.Lfunc_begin0
	.quad	.Ltmp81-.Lfunc_begin0
	.quad	.Ltmp82-.Lfunc_begin0
	.quad	.Ltmp84-.Lfunc_begin0
	.quad	.Ltmp85-.Lfunc_begin0
	.quad	.Ltmp86-.Lfunc_begin0
	.quad	.Ltmp87-.Lfunc_begin0
	.quad	.Ltmp89-.Lfunc_begin0
	.quad	.Ltmp90-.Lfunc_begin0
	.quad	.Ltmp91-.Lfunc_begin0
	.quad	.Ltmp92-.Lfunc_begin0
	.quad	0
	.quad	0
	.section	".note.GNU-stack","",@progbits
	.iluvatar_isa "bi-iluvatar-ilurt--ivcore-1-1-0"
	.iluvatar_hsa_metadata
---
iluvatar.kernels:
  - .args:
      - .address_space:  global
        .name:           KArg_0
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_1
        .offset:         8
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_2
        .offset:         16
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_3
        .offset:         24
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_4
        .offset:         32
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_5
        .offset:         40
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_6
        .offset:         48
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_7
        .offset:         56
        .size:           8
        .value_kind:     global_buffer
      - .name:           KArg_8
        .offset:         64
        .size:           4
        .value_kind:     by_value
      - .name:           KArg_9
        .offset:         72
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_10
        .offset:         80
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_11
        .offset:         88
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_12
        .offset:         96
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_13
        .offset:         104
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_14
        .offset:         112
        .size:           8
        .value_kind:     by_value
      - .name:           KArg_15
        .offset:         120
        .size:           8
        .value_kind:     by_value
      - .address_space:  global
        .name:           KArg_16
        .offset:         128
        .size:           8
        .value_kind:     global_buffer
      - .address_space:  global
        .name:           KArg_17
        .offset:         136
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 0
    .kernarg_segment_align: 8
    .kernarg_segment_size: 144
    .max_flat_workgroup_size: 0
    .name:           _gqa_decode_attention
    .private_segment_fixed_size: 0
    .sgpr_count:     99
    .sgpr_spill_count: 29
    .symbol:         _gqa_decode_attention.kd
    .vgpr_count:     104
    .vgpr_spill_count: 0
    .warp_size:      64
iluvatar.version:
  - 1
  - 0
...

	.end_iluvatar_hsa_metadata
