"""Owned personal-instance startup/request diagnosis. Default is a CPU-only plan."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import urllib.request

ENABLE = 'VLLM_FL_BIV150_KONLY_ENCODED_SERVICE'
HELPER_SHA = '94dbbb0fbc8f3c8837ea239ec18fc0ec4872a2b0049a1843d96a3e6a9701e976'
NATIVE_SHA = '5cbb8853a81a4621efc936fa60b952391bed1b56408db1bad62d0031be573dbe'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def evidence(logs, expected):
    parent_installations = {}
    for marker in ('BIV150_NATIVE_W8A8_INSTALL', 'BIV150_STABLE_SMALL_O_INSTALL',
                   'BIV150_SMALL_OUT_LOWERING_INSTALL', 'BIV150_Q_FRAGMENT_INSTALL',
                   'BIV150_PREFILL_NORMALIZATION_INSTALL', 'BIV150_GQA_DECODE_INSTALL',
                   'BIV150_MIXED_DECODE_INSTALLED', 'BIV150_PREFILL_Q32_INSTALL',
                   'BIV150_PREFILL_MULTI2_INSTALL'):
        values = [ast.literal_eval(line.split(marker + ' ', 1)[1]) for line in logs.splitlines() if marker + ' ' in line]
        if not values or any(value.get('installed') is not True for value in values):
            raise RuntimeError('Existing production installer declined: ' + marker)
        parent_installations[marker] = values
    if any(not value.get('large_linear') for value in parent_installations['BIV150_SMALL_OUT_LOWERING_INSTALL']):
        raise RuntimeError('Existing large-linear production default is inactive')
    fps = [json.loads(line.split('BIV150_COMPILE_SEMANTICS ', 1)[1]) for line in logs.splitlines()
           if 'BIV150_COMPILE_SEMANTICS ' in line]
    if not fps or any(fp != expected for fp in fps):
        raise RuntimeError('Actual worker compile fingerprint differs from the reviewed ON source')
    installs = [ast.literal_eval(line.split('BIV150_KONLY_ENCODED_INSTALL ', 1)[1]) for line in logs.splitlines()
                if 'BIV150_KONLY_ENCODED_INSTALL ' in line]
    digest = expected['konly_encoded']['implementation_sha256']
    if not installs or any(i.get('installed') is not True or i.get('implementation_sha256') != digest for i in installs):
        raise RuntimeError('Actual encoded installer is absent, declined or has another implementation')
    events = [json.loads(line.split('BIV150_KONLY_ENCODED_SELECTED ', 1)[1]) for line in logs.splitlines()
              if 'BIV150_KONLY_ENCODED_SELECTED ' in line]
    if not events or any(not e.get('hash') or e.get('implementation_sha256') != digest for e in events):
        raise RuntimeError('Actual private kernel selection/hash is missing or inconsistent')
    profiles = {e['profile'] for e in events}
    if 'writer83' not in profiles or not profiles.difference({'writer83'}):
        raise RuntimeError('Need both encoded writer and an encoded attention reader')
    if 'BIV150_COMPUTE_ORDER_SCOPE_REJECTED' in logs:
        raise RuntimeError('Existing compute-order scope was rejected')
    return dict(actual_compile_semantics=fps, actual_installs=installs,
                preserved_parent_installations=parent_installations, selected=events,
                host_capture_events_only=True, graph_replays_counted=False)


def run(a):
    if sha(a.helper) != HELPER_SHA:
        raise RuntimeError('The previously verified stdlib owner/protocol helper differs')
    spec = importlib.util.spec_from_file_location('encoded_smoke_owned_helpers', a.helper)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    source, out, snapshot = a.source.resolve(), a.out.resolve(), a.tuning_snapshot.resolve()
    if out.exists() or source == out or source in out.parents or snapshot == out or snapshot in out.parents:
        raise RuntimeError('Need a fresh independent output')
    if subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() != a.commit:
        raise RuntimeError('Source HEAD differs')
    if subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'], text=True).strip():
        raise RuntimeError('Source is not clean')
    subprocess.run(['git', '-C', str(source), 'diff', '--exit-code', a.base, '--', 'csrc'], check=True)
    m.protocol_source(source)
    if sha(a.gate_library) != NATIVE_SHA:
        raise RuntimeError('Native 5c library differs')
    tuning = m.snapshot_inventory(snapshot)
    before_idle = m.idle()
    out.mkdir(parents=True)
    (out / 'idle-before.txt').write_text(before_idle)
    target = out / 'flaggems-cache/config_cache'; target.mkdir(parents=True)
    for item in tuning:
        shutil.copy2(snapshot / item['name'], target / item['name'])
        assert sha(target / item['name']) == item['sha256']
    env = dict(os.environ)
    cleared = []
    for key in list(env):
        if key.startswith(('VLLM_FL_', 'BIV150_')) or key in ('FLAGTUNE', 'USE_C_EXTENSION', 'USE_FLAGGEMS', 'VLLM_BATCH_INVARIANT', 'VLLM_ATTENTION_BACKEND'):
            cleared.append(key); env.pop(key)
    env.update(VLLM_PLUGINS='fl', PYTHONPATH=str(source), PYTHONUNBUFFERED='1',
               VLLM_DISABLE_COMPILE_CACHE='1', TRITON_CACHE_DIR=str(out / 'triton-cache'),
               TORCHINDUCTOR_CACHE_DIR=str(out / 'inductor-cache'), FLAGGEMS_CACHE_DIR=str(out / 'flaggems-cache'),
               BIV150_NATIVE_W8A8_LIBRARY=str(a.gate_library.resolve()), **{ENABLE: '1'})
    resolution = m.package_resolution(env, out)
    assert Path(resolution['origin']).resolve() == source / 'vllm_fl/__init__.py'
    abi = m.abi_probe(dict(env, **{ENABLE: '0'}), out)
    expected = m.expected_fingerprint(source, env, abi)
    off = m.expected_fingerprint(source, dict(env, **{ENABLE: '0'}), abi)
    assert expected != off and expected.get('native_enabled') and expected.get('konly_encoded')
    paths = subprocess.check_output(['git', '-C', str(source), 'ls-files', '--', 'vllm_fl', 'csrc'], text=True).splitlines()
    hashes = {name: sha(source / name) for name in paths}
    manifest = dict(source_commit=a.commit, source=str(source), source_hashes=hashes,
                    helper_sha256=HELPER_SHA, controller_sha256=sha(__file__), native_sha256=NATIVE_SHA,
                    tuning_snapshot=tuning, expected_compile_semantics=expected, off_compile_semantics=off,
                    command=m.SERVICE_COMMAND, actual_resolution=resolution, abi=abi,
                    cleared_switch_names=sorted(cleared), private_enabled=True,
                    official_service_parameters_unchanged=True, smoke_only=not a.math105,
                    formal_throughput_measured=False)
    state = dict(completed=False, smoke_passed=False, model_precision_verified=False,
                 throughput_measured=False, cleanup_complete=False, errors=[])
    m.atomic(out / 'manifest.json', manifest)
    owned = m.Owned(); server = None; log = None
    def save(phase):
        state.update(phase=phase, updated_utc=m.now()); m.atomic(out / 'state.json', state)
    try:
        m.idle()
        log = (out / 'server.log').open('x')
        server = subprocess.Popen(m.SERVICE_COMMAND, cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT,
                                  stdin=subprocess.DEVNULL, start_new_session=True)
        state['server_owner'] = owned.add_launcher(server); save('waiting_service')
        deadline = time.monotonic() + 1200
        while True:
            owned.remember()
            if server.poll() is not None:
                raise RuntimeError('Owned server exited before readiness')
            try:
                with urllib.request.urlopen('http://127.0.0.1:9031/v1/models', timeout=3) as response:
                    json.load(response)
                break
            except Exception:
                if time.monotonic() >= deadline: raise TimeoutError('Service readiness deadline')
                time.sleep(3)
        save('short_request_smoke')
        results = []
        prompts = ['请计算1+1，简短回答。', '请计算1+1，简短回答。', '数列：' + '1 2 3 4 5 ' * 512 + '。请回答最后一个数。']
        for prompt in prompts:
            payload = dict(model='minicpm', messages=[dict(role='user', content=prompt)],
                           max_tokens=16, temperature=0, top_p=1)
            request = urllib.request.Request('http://127.0.0.1:9031/v1/chat/completions',
                data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(request, timeout=180) as response:
                value = json.load(response)
            if len(value.get('choices', [])) != 1 or value.get('usage', {}).get('completion_tokens', 0) <= 0:
                raise RuntimeError('Short diagnostic request produced no generated tokens')
            results.append(dict(request=payload, response=value))
            m.atomic(out / 'smoke-requests.json', results); owned.remember()
        manifest['actual_runtime'] = evidence((out / 'server.log').read_text(), expected)
        m.atomic(out / 'manifest.json', manifest)
        state['smoke_passed'] = True; save('smoke_complete')
        if a.math105:
            client = dict(env, CUDA_VISIBLE_DEVICES='', VLLM_PLUGINS=''); client.pop(ENABLE, None)
            save('Math105')
            m.official_accuracy(source, out, m.EvalAdapter(out, client, owned))
            verdict = json.loads((out / 'accuracy-verdict.json').read_text()); m.validate_verdict(verdict)
            inventory = m.prediction_inventory(out); m.atomic(out / 'prediction-inventory.json', inventory)
            assert inventory['count'] == inventory['unique_question_ids'] == inventory['unique_indices'] == 105
            assert not inventory['failed_rows'] and not inventory['parse_errors']
            state.update(accuracy=verdict, model_precision_verified=True)
            manifest['actual_runtime_after_math'] = evidence((out / 'server.log').read_text(), expected)
        if sha(a.gate_library) != NATIVE_SHA or m.snapshot_inventory(snapshot) != tuning:
            raise RuntimeError('Original library/snapshot changed')
        if any(sha(source / name) != value for name, value in hashes.items()):
            raise RuntimeError('Frozen source changed')
        m.atomic(out / 'manifest.json', manifest)
    except BaseException as error:
        state['errors'].append(dict(type=type(error).__name__, message=str(error)))
        (out / 'error-traceback.txt').write_text(traceback.format_exc())
    finally:
        cleanup = owned.cleanup()
        if server is not None:
            try: server.wait(timeout=5)
            except subprocess.TimeoutExpired: cleanup['complete'] = False
        if log is not None: log.close()
        m.atomic(out / 'owned-cleanup.json', cleanup)
        state['cleanup_complete'] = cleanup['complete']
        state['completed'] = not state['errors'] and state['smoke_passed'] and cleanup['complete']
        save('completed' if state['completed'] else 'failed')
    if not state['completed']: raise RuntimeError('Encoded service diagnostic failed; preserve raw evidence')
    return state


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run-service', action='store_true'); p.add_argument('--math105', action='store_true')
    for name in ('source', 'out', 'helper', 'gate-library', 'tuning-snapshot'):
        p.add_argument('--' + name, type=Path)
    p.add_argument('--commit'); p.add_argument('--base', default='dac1b8fb48e7983e48283032efeee9b592c5fbe5')
    a = p.parse_args()
    if not a.run_service:
        print(json.dumps(dict(cpu_plan=True, gpu_executed=False, fixed_service_CLI=True,
              private_smoke=True, optional_original_math105=True, formal_throughput=False)))
    else:
        if any(getattr(a, name) is None for name in ('source', 'out', 'helper', 'gate_library', 'tuning_snapshot', 'commit')):
            p.error('All pinned source/helper/native/snapshot/output arguments are required')
        print(json.dumps(run(a), indent=2))
